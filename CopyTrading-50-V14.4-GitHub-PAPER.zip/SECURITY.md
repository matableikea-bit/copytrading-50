# Security & responsible execution

- Default is PAPER; no wallet secrets required. Avoid sharing API keys or wallet secrets.
- Live execution is experimental and must NOT be interpreted as independently audited.
- Use a standalone, small-balance Solana wallet only. Keep your primary assets and seed offline.
- Never store secrets in config.json, GitHub Actions logs, issue text, screenshots or this chat.
- No exchange withdrawals; no leverage; no margin; no automated transfers to arbitrary destinations.
- Stop file `STOP_TRADING` disables all trading decisions but does not cancel pending transactions.
- The on-chain filters reject active mint/freeze authority, Token-2022, and top-token-account concentration above 80%. They cannot detect all rug pulls and honeypots.
- A seller may not fill even if the script signals a stop. Network stalls, MEV, RPC outages, liquidity withdrawal and mempool behavior can cause total loss.
- SQLite records order intents before submission. UNKNOWN and CONFIRMED_PENDING_ACCOUNTING intents freeze live mode until manual on-chain reconciliation.
- Holding an unlisted memecoin in a wallet is a risk even if no trade is submitted.
- In PAPER, gas is represented by an assumed USDC deduction per trade; in LIVE, gas is paid separately in SOL and is not yet included in reported USDC P&L.
