import unittest
from bot.performance import summarize

class PerformanceTests(unittest.TestCase):
    def test_empty_session(self):
        state={'mode':'PAPER','starting_usdc':'50','created_at':10,'expires_at':20,
               'positions':{},'trades':[]}
        r=summarize(state,[])
        self.assertEqual(r['positions_fully_closed'],0)
        self.assertIsNone(r['closed_position_win_rate_percent'])
    def test_partial_only_not_closed(self):
        state={'mode':'PAPER','starting_usdc':'50','created_at':10,'expires_at':20,
               'positions':{'M':{}},
               'trades':[{'side':'BUY','mint':'M','paper_network_cost_usdc':'0.1'},
                         {'side':'SELL','mint':'M','position_id':'M:1','source':'COPIER',
                          'realized_pnl_usdc':'1','position_fully_closed':False}]}
        r=summarize(state,[])
        self.assertEqual(r['positions_fully_closed'],0)
        self.assertEqual(r['realized_pnl_usdc'],'1')
    def test_partial_then_final_counts_one_position(self):
        state={'mode':'PAPER','starting_usdc':'50','created_at':10,'expires_at':20,
               'positions':{},'trades':[
                   {'side':'BUY','mint':'M','paper_network_cost_usdc':'0.1'},
                   {'side':'SELL','mint':'M','position_id':'M:1','source':'COPIER','realized_pnl_usdc':'2',
                    'position_fully_closed':False},
                   {'side':'SELL','mint':'M','position_id':'M:1','source':'COPIER','realized_pnl_usdc':'-1',
                    'position_fully_closed':True}]}
        r=summarize(state,[])
        self.assertEqual(r['positions_fully_closed'],1)
        self.assertEqual(r['winning_positions'],1)
        self.assertEqual(r['realized_pnl_usdc'],'1')

if __name__=='__main__':unittest.main()
