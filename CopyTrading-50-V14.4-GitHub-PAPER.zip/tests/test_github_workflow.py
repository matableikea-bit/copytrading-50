"""Check staged GitHub Actions simulation without any network access."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from bot.gh_session import (SESSION_SECONDS, segment_seconds, prepare_config,
                            run_stage, write_performance, append_summary)
from bot.settings import Config


class FakePaperBot:
    """Purely deterministic substitute for provider-heavy market ticks."""
    def __init__(self, cfg, store):
        self.cfg = cfg
        self.store = store
        self.state = store.initialize(cfg, 1730000000)

    def tick(self):
        self.state['fake_tick_count'] = self.state.get('fake_tick_count', 0) + 1
        # A simulated position is never conjured to manufacture gains.
        self.store.put('portfolio', self.state)
        report = self.store.report(self.state, {}, 1730000000, liquidations={})
        report['session_buy_entries'] = 0
        return report


class GitHubSimulationTests(unittest.TestCase):
    def test_three_job_partition(self):
        self.assertEqual(segment_seconds('10h', 1), 200 * 60)
        self.assertEqual(segment_seconds('10h', 3), 200 * 60)
        self.assertEqual(segment_seconds('12h', 2), 240 * 60)
        self.assertEqual(segment_seconds('2min', 1), 120)
        for name, stage in [('2min', 2), ('10h', 0), ('12h', 4), ('other', 1)]:
            with self.subTest(name=name, stage=stage), self.assertRaises(ValueError):
                segment_seconds(name, stage)

    def test_paper_only_rejects_live_and_flags(self):
        with tempfile.TemporaryDirectory() as d:
            config_path = Path(d) / 'config.json'
            config_path.write_text(json.dumps({'mode': 'LIVE', 'live_mint_allowlist': [
                'So11111111111111111111111111111111111111112']}))
            with self.assertRaisesRegex(ValueError, 'PAPER'):
                prepare_config(str(config_path))
            config_path.write_text(json.dumps({'mode': 'PAPER'}))
            with patch.dict(os.environ, {'ENABLE_LIVE_TRADING': 'yes'}):
                with self.assertRaisesRegex(ValueError, 'LIVE flags'):
                    prepare_config(str(config_path))
            with self.assertRaises(ValueError):
                prepare_config(str(config_path), '{"wrong":"shape"}')

    def test_checkpoint_resumes_without_resetting_portfolio(self):
        with tempfile.TemporaryDirectory() as d:
            db = str(Path(d) / 'session.sqlite')
            report = str(Path(d) / 'status.json')
            cfg = Config()
            cfg.session_hours = 10
            for stage in (1, 2, 3):
                got = run_stage(cfg, session='10h', stage=stage,
                                db_path=db, report_path=report, run_id='test-run',
                                bot_factory=FakePaperBot, max_ticks=1)
                self.assertEqual(got['mode'], 'PAPER')
                self.assertTrue(Path(db).is_file())
            from bot.store import Store
            store = Store(db)
            try:
                self.assertEqual(store.get('portfolio')['fake_tick_count'], 3)
                self.assertEqual(store.get('github_session_meta')['last_stage'], 3)
                self.assertEqual(store.get('github_session_meta')['run_id'], 'test-run')
            finally:
                store.close()
            out = str(Path(d) / 'perf.json')
            csv = str(Path(d) / 'trades.csv')
            write_performance(db, out, csv)
            self.assertEqual(json.loads(Path(out).read_text())['buy_executions'], 0)
            self.assertIn('side', Path(csv).read_text())
            with self.assertRaisesRegex(ValueError, 'existing database'):
                run_stage(cfg, session='10h', stage=1, db_path=db, report_path=report,
                          run_id='test-run', bot_factory=FakePaperBot, max_ticks=1)

    def test_reject_missing_and_cross_run_checkpoints(self):
        with tempfile.TemporaryDirectory() as d:
            db = str(Path(d) / 's.sqlite')
            report = str(Path(d) / 'report.json')
            cfg = Config()
            with self.assertRaisesRegex(ValueError, 'missing checkpoint'):
                run_stage(cfg, session='10h', stage=2, db_path=db, report_path=report,
                          run_id='one', bot_factory=FakePaperBot, max_ticks=1)
            run_stage(cfg, session='10h', stage=1, db_path=db, report_path=report,
                      run_id='one', bot_factory=FakePaperBot, max_ticks=1)
            with self.assertRaisesRegex(ValueError, 'another GitHub Actions run'):
                run_stage(cfg, session='10h', stage=2, db_path=db, report_path=report,
                          run_id='two', bot_factory=FakePaperBot, max_ticks=1)
            with self.assertRaisesRegex(ValueError, 'does not match'):
                run_stage(cfg, session='12h', stage=2, db_path=db, report_path=report,
                          run_id='one', bot_factory=FakePaperBot, max_ticks=1)
            with self.assertRaisesRegex(ValueError, 'stage order'):
                run_stage(cfg, session='10h', stage=3, db_path=db, report_path=report,
                          run_id='one', bot_factory=FakePaperBot, max_ticks=1)

    def test_short_session_and_github_summary(self):
        with tempfile.TemporaryDirectory() as d:
            db = str(Path(d) / 's.sqlite')
            report = str(Path(d) / 'report.json')
            summary = str(Path(d) / 'summary.md')
            cfg = Config()
            run_stage(cfg, session='2min', stage=1, db_path=db, report_path=report,
                      run_id='short', bot_factory=FakePaperBot, max_ticks=1,
                      wall_clock=lambda: 1730000000)
            from bot.store import Store
            store = Store(db)
            try:
                self.assertEqual(store.get('portfolio')['expires_at'], 1730000120)
            finally:
                store.close()
            append_summary(json.loads(Path(report).read_text()), 1, '2min', path=summary)
            text = Path(summary).read_text()
            self.assertIn('PAPER uniquement', text)
            self.assertIn('50 USDC', text)


if __name__ == '__main__':
    unittest.main()

class OfflineSnapshotTests(unittest.TestCase):
    def test_snapshot_has_data_without_fetch_or_script_injection(self):
        from bot.snapshot import build_snapshot
        source = Path(__file__).parents[1].joinpath('docs/index.html').read_text()
        data = {'mode': 'PAPER', 'positions': [], 'last_events': [],
                'symbol': '</script><script>alert(1)</script>', 'pnl_estimate_usdc': '0'}
        html = build_snapshot(data, source)
        self.assertIn('SNAPSHOT_REPORT', html)
        self.assertIn('update(SNAPSHOT_REPORT)', html)
        self.assertNotIn('async function refresh()', html)
        self.assertNotIn('</script><script>alert', html)
        self.assertIn('\\u003c/script\\u003e', html)

    def test_snapshot_rejects_non_paper_reports(self):
        from bot.snapshot import main
        with tempfile.TemporaryDirectory() as d:
            report = Path(d) / 'status.json'
            report.write_text('{"mode":"LIVE"}')
            with self.assertRaisesRegex(ValueError, 'non-PAPER'):
                main(['--report', str(report), '--template',
                      str(Path(__file__).parents[1].joinpath('docs/index.html')),
                      '--out', str(Path(d) / 'out.html')])
