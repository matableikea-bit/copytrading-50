"""Regression tests for 10/12h V14.1 BANKER/COPIER risk flow.

All quotes and swaps are deterministic fixtures, not market observations.
"""
from __future__ import annotations
from decimal import Decimal
from pathlib import Path
import json
import tempfile
import unittest
from test_v14 import Setup, Clock, FakeDex, FakeJup, FakeHelius, FakeRPC, MINT, WALLET, NOW
from bot.settings import Config, D
from bot.providers import USDC, parse_helius_swaps
from bot.runner import Bot
from bot.store import Store


def swap(sig,side,ts):
    return {'type':'SWAP','signature':sig,'timestamp':ts,'feePayer':WALLET,
            'events':{'swap':{'tokenInputs':[{'mint':USDC if side=='BUY' else MINT}],
                              'tokenOutputs':[{'mint':MINT if side=='BUY' else USDC}]}}}


class V141Tests(Setup):
    def test_take_profit_partial_banks_cash(self):
        self.buy()
        starting_cash=D(self.bot.state['cash_usdc'])
        self.advance(price='1.50')
        self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'partial_take_profit')
        self.assertGreater(D(self.bot.state['cash_usdc']),starting_cash)
        self.assertTrue(self.bot.state['positions'][MINT]['partial_take_profit_done'])
        self.assertEqual(sum(x['side']=='SELL' for x in self.bot.state['trades']),1)
        self.assertIn(MINT,self.bot.state['positions'])

    def test_take_profit_partial_once_even_after_restart(self):
        self.buy();self.advance(price='1.50');self.bot.tick()
        self.advance(price='1.51');self.bot.tick()
        self.assertEqual(sum(x['reason']=='partial_take_profit' for x in self.bot.state['trades'] if x['side']=='SELL'),1)
        restarted=Bot(self.cfg,self.store,dex=self.dex,helius=FakeHelius(),jupiter=self.jup,
                      rpc=self.rpc,now=self.clock)
        restarted.tick()
        self.assertEqual(sum(x['reason']=='partial_take_profit' for x in restarted.state['trades'] if x['side']=='SELL'),1)

    def test_partial_sale_reduces_peak_reference(self):
        self.buy();self.advance(price='1.50');self.bot.tick()
        p=self.bot.state['positions'][MINT]
        self.assertGreater(D(p['peak_exit_value_usdc']),D('1'))
        self.assertLess(D(p['peak_exit_value_usdc']),D('4'))
        self.advance(price='1.50');self.bot.tick()
        self.assertIn(MINT,self.bot.state['positions'])

    def test_partial_sale_then_trailing_closes_remainder(self):
        self.buy();self.advance(price='1.50');self.bot.tick()
        self.advance(price='1.23');self.bot.tick()
        self.assertNotIn(MINT,self.bot.state['positions'])
        sells=[t for t in self.bot.state['trades'] if t['side']=='SELL']
        self.assertEqual(len(sells),2)
        self.assertEqual(sells[-1]['reason'],'trailing_stop')
        self.assertTrue(sells[-1]['position_fully_closed'])

    def test_missing_dex_quote_can_still_close_position(self):
        self.buy()
        class MissingDex(FakeDex):
            def markets(self,*_args,**_kwargs):return {}
        self.bot.dex=MissingDex(self.clock)
        self.jup.dex.price=D('0.72')
        self.advance(price='0.72')
        self.bot.tick()
        self.assertNotIn(MINT,self.bot.state['positions'])
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'stop_loss')

    def test_missing_dex_quote_reports_jupiter_exit_value(self):
        self.buy()
        self.bot.dex.markets=lambda *_args,**_kwargs:{}
        self.bot._refresh_liquidations()
        self.assertIn(MINT,self.bot.exit_values)
        r=self.bot._report(self.clock(),marks={})
        self.assertIsNotNone(r['positions'][0]['estimated_exit_value_usdc'])
        self.assertIsNone(r['positions'][0]['marked_value_usdc'])
        self.assertIsNotNone(r['equity_estimate_usdc'])

    def test_missing_dex_quote_on_end_of_session_executes_exit(self):
        self.buy()
        self.bot.dex.markets=lambda *_args,**_kwargs:{}
        self.clock.now+=12*3600
        self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'end_of_session')
        self.assertNotIn(MINT,self.bot.state['positions'])

    def test_bootstrap_empty_history_does_not_skip_first_future_buy(self):
        cfg=Config(trader_wallets=[WALLET],scout_enabled=False)
        clock=Clock();dex=FakeDex(clock)
        class SequentialHelius(FakeHelius):
            def __init__(self):self.key='test';self.records=[];self.calls=[]
            def since(self,wallet,cursor):
                self.calls.append(cursor)
                return (self.records,self.records[-1]['signature'] if self.records else None)
        h=SequentialHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()
        self.assertEqual(self.store.get('wallet_cursor:'+WALLET),{'initialized':True,'signature':None,'bootstrap_ts':NOW})
        clock.now+=60;h.records=[swap('new_after_zero','BUY',clock())]
        bot.tick()
        self.assertEqual(len(bot.state['trades']),1)
        self.assertEqual(bot.state['trades'][0]['source'],'COPIER')
        self.assertEqual(h.calls,[None,None])

    def test_delayed_sell_is_processable_but_delayed_buy_is_not(self):
        b=swap('oldbuy','BUY',NOW-1000)
        s=swap('oldsell','SELL',NOW-1000)
        events=parse_helius_swaps([b,s],WALLET,NOW,stale_seconds=90)
        self.assertEqual(len(events),1)
        self.assertEqual(events[0].side,'SELL')
        self.assertEqual(events[0].event_id,'oldsell:'+WALLET)

    def test_outdated_sell_rejected(self):
        s=swap('ancient','SELL',NOW-200000)
        self.assertEqual(parse_helius_swaps([s],WALLET,NOW),[])

    def test_partial_config_invariants(self):
        with self.assertRaises(ValueError):
            Config(partial_take_profit_fraction='0.8').validate()
        with self.assertRaises(ValueError):
            Config(partial_take_profit_sell_fraction='0').validate()

    def test_paper_has_no_fabricated_gain(self):
        self.bot.tick()
        r=self.bot._report(self.clock())
        self.assertEqual(r['pnl_estimate_usdc'],'0')
        self.assertEqual(r['trades'],[])
        self.assertEqual(r['mode'],'PAPER')

if __name__=='__main__':unittest.main()
