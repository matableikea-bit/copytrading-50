from __future__ import annotations
from dataclasses import asdict,replace
from decimal import Decimal
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch

from bot.settings import Config,D
from bot.providers import (Market,USDC,SOL,DataUnavailable,DexScreener,
                           Helius,Jupiter,SolanaRPC,GeckoTerminal,PoolDiscovery,parse_market,parse_helius_swaps)
from bot.risk import scout_score,analyst,risk_budget,exit_reason
from bot.store import Store
from bot.runner import Bot,atoms,write_report
from bot.live import JupiterLive,LiveExecutionDisabled

MINT='A'*43
WALLET='B'*43
NOW=1_790_000_000


def market(now=NOW,price='1',mint=MINT,liquidity='120000',vol='15000',change='5',created=None):
    return Market(mint,'TEST',D(price),D(liquidity),D(vol),D('1000000'),
                  created or now-3600,D(change),50,20,'POOL',now)


def pair(mint=MINT,now=NOW,price='1',chain='solana'):
    return {'chainId':chain,'baseToken':{'address':mint,'symbol':'TEST'},
            'pairAddress':'POOL','priceUsd':price,'liquidity':{'usd':80000},
            'volume':{'m5':12000},'marketCap':1000000,
            'pairCreatedAt':(now-3600)*1000,'priceChange':{'m5':5},
            'txns':{'m5':{'buys':50,'sells':20}}}

class Clock:
    def __init__(self,now=NOW):self.now=now
    def __call__(self):return self.now

class FakeDex:
    def __init__(self,clock):self.clock=clock;self.price=D(1);self.fail=False
    def discover(self,limit=30):
        if self.fail:raise DataUnavailable('unavailable')
        return [MINT]
    def markets(self,mints,now=None):
        if self.fail:raise DataUnavailable('unavailable')
        return {mint:market(now=now,price=str(self.price),mint=mint) for mint in mints}

class FakeRPC:
    def __init__(self):self.bad=False;self.conc=D('0.15')
    def mint_info(self,mint):
        if self.bad:raise DataUnavailable('freeze authority active')
        return 6
    def largest_holders(self,mint):return self.conc

class FakeJup:
    key='test-key'
    def __init__(self,dex):self.dex=dex;self.fail=False;self.fee=100
    def order(self,a,b,amount,taker=None):
        if self.fail:raise DataUnavailable('Jupiter unavailable')
        if a==USDC:
            output=int(D(amount)/self.dex.price*D('0.985'))
        elif b==USDC:output=int(D(amount)*self.dex.price*D('0.985'))
        else:raise AssertionError('unknown direction')
        return {'requestId':'test','outAmount':str(output),'feeBps':self.fee}

class FakeHelius:
    key='test'
    def __init__(self):self.results=[]
    def since(self,wallet,cursor):return self.results,'latest'

class Setup(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.store=Store(Path(self.temp.name)/'state.db')
        self.clock=Clock();self.dex=FakeDex(self.clock);self.rpc=FakeRPC();self.jup=FakeJup(self.dex)
        self.cfg=Config();self.cfg.validate()
        self.bot=Bot(self.cfg,self.store,dex=self.dex,helius=FakeHelius(),jupiter=self.jup,
                     rpc=self.rpc,now=self.clock)
    def tearDown(self):self.store.close();self.temp.cleanup()
    def advance(self,seconds=130,price='1.03'):
        self.clock.now+=seconds;self.dex.price=D(price)
    def buy(self):
        self.bot.tick();self.advance();self.bot.tick()
        return self.bot

class SettingsTests(unittest.TestCase):
    def test_defaults(self):Config().validate()
    def test_negative_cash(self):
        with self.assertRaises(ValueError):Config(starting_usdc='-1').validate()
    def test_non_finite(self):
        with self.assertRaises(ValueError):Config(max_trade_fraction='NaN').validate()
    def test_invalid_mode(self):
        with self.assertRaises(ValueError):Config(mode='ROGUE').validate()
    def test_live_no_allowlist(self):
        with self.assertRaises(ValueError):Config(mode='LIVE').validate()
    def test_unknown_key(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json';p.write_text('{"mode":"PAPER","secrets":"x"}')
            with self.assertRaises(ValueError):Config.load(p)
    def test_fraction_cap(self):
        with self.assertRaises(ValueError):Config(max_trade_fraction='0.9').validate()
    def test_wallet_validation(self):
        with self.assertRaises(ValueError):Config(trader_wallets=['not-a-wallet']).validate()
    def test_positive_atoms(self):
        self.assertEqual(atoms('4.15245899',6),4152458)
    def test_store_mode_isolated(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'db')
            store.initialize(Config(),NOW)
            with self.assertRaises(ValueError):store.initialize(Config(mode='LIVE'),NOW)
            store.close()

class MarketTests(unittest.TestCase):
    def test_parse_pair(self):
        m=parse_market([pair()],MINT,NOW)
        self.assertEqual(m.price_usd,D(1))
    def test_ignores_wrong_chain(self):self.assertIsNone(parse_market([pair(chain='base')],MINT,NOW))
    def test_ignores_wrong_base(self):self.assertIsNone(parse_market([pair()],WALLET,NOW))
    def test_invalid_price(self):self.assertIsNone(parse_market([pair(price='NaN')],MINT,NOW))
    def test_invalid_future_pool(self):self.assertIsNone(parse_market([pair(now=NOW+5000)],MINT,NOW))
    def test_picks_liquid_pair(self):
        less=pair();less['liquidity']={'usd':1}
        m=parse_market([less,pair()],MINT,NOW)
        self.assertEqual(m.liquidity_usd,D(80000))
    def test_dex_discover(self):
        dex=DexScreener(fetch=lambda _: [{'chainId':'solana','tokenAddress':MINT},
                                         {'chainId':'base','tokenAddress':WALLET}])
        self.assertEqual(dex.discover(),[MINT])
    def test_dex_batch(self):
        dex=DexScreener(fetch=lambda _: [pair()])
        self.assertIn(MINT,dex.markets([MINT],now=NOW))
    def test_dex_bad_response(self):
        dex=DexScreener(fetch=lambda _: {})
        with self.assertRaises(DataUnavailable):dex.discover()
    def test_scout_score(self):
        score,_=scout_score(market(),NOW)
        self.assertGreaterEqual(score,78)
    def test_analyst_pass(self):self.assertEqual(analyst(market(),Config(),NOW),[])
    def test_analyst_liquidity(self):
        self.assertIn('low_liquidity',analyst(market(liquidity='1'),Config(),NOW))
    def test_analyst_stale(self):
        self.assertIn('market_data_stale',analyst(market(),Config(),NOW+500))
    def test_analyst_pump(self):
        self.assertIn('price_jump',analyst(market(change='100'),Config(),NOW))
    def test_expired_market(self):
        m=replace(market(),pool_created_at=NOW-400000)
        self.assertIn('pool_age_rejected',analyst(m,Config(),NOW))

class DiscoveryTests(unittest.TestCase):
    def pool(self,reserve='60000',base=MINT,quote=SOL):
        return {'attributes':{'reserve_in_usd':reserve},
                'relationships':{'base_token':{'data':{'id':'solana_'+base}},
                                 'quote_token':{'data':{'id':'solana_'+quote}}}}

    def test_new_pool_mint(self):
        urls=[]
        def fetch(url):
            urls.append(url)
            return {'data':[self.pool()]}
        self.assertEqual(GeckoTerminal(fetch=fetch).discover(),[MINT])
        self.assertIn('page=1',urls[0])

    def test_inverted_pool(self):
        gecko=GeckoTerminal(fetch=lambda _: {'data':[self.pool(base=USDC,quote=MINT)]})
        self.assertEqual(gecko.discover(),[MINT])

    def test_skips_low_liquidity(self):
        gecko=GeckoTerminal(fetch=lambda _: {'data':[self.pool(reserve='300')]})
        self.assertEqual(gecko.discover(),[])

    def test_rejects_malformed_pool_feed(self):
        gecko=GeckoTerminal(fetch=lambda _: {'error':'not working'})
        with self.assertRaises(DataUnavailable):gecko.discover()

    def test_gecko_pagination_and_dedup(self):
        pool=self.pool()
        calls=[]
        def fetch(url):
            calls.append(url)
            return {'data':([pool]*20 if len(calls)==1 else [self.pool(base=WALLET)])}
        gecko=GeckoTerminal(fetch=fetch)
        self.assertEqual(gecko.discover(limit=4),[MINT,WALLET])
        self.assertEqual(len(calls),2)

    def test_discovery_merges_two_sources(self):
        dex=DexScreener(fetch=lambda _: [{'chainId':'solana','tokenAddress':MINT}])
        gecko=GeckoTerminal(fetch=lambda _: {'data':[self.pool(base=WALLET)]})
        pools=PoolDiscovery(dex=dex,gecko=gecko)
        self.assertEqual(pools.discover(),[WALLET,MINT])
        self.assertEqual(pools.last_health,{'geckoterminal':'ok','dexscreener':'ok'})

    def test_discovery_survives_one_source_down(self):
        def broken(_):raise DataUnavailable('Gecko offline')
        gecko=GeckoTerminal(fetch=broken)
        dex=DexScreener(fetch=lambda _: [{'chainId':'solana','tokenAddress':MINT}])
        pools=PoolDiscovery(dex=dex,gecko=gecko)
        self.assertEqual(pools.discover(),[MINT])
        self.assertIn('error',pools.last_health['geckoterminal'])

    def test_discovery_both_fail_closed(self):
        def broken(_):raise DataUnavailable('offline')
        pools=PoolDiscovery(DexScreener(fetch=broken),GeckoTerminal(fetch=broken))
        with self.assertRaises(DataUnavailable):pools.discover()

    def test_gecko_bad_mint_does_not_pass(self):
        gecko=GeckoTerminal(fetch=lambda _: {'data':[self.pool(base='INVALID',quote=USDC)]})
        self.assertEqual(gecko.discover(),[])


class WalletTests(unittest.TestCase):
    def swap(self,inmint=USDC,outmint=MINT,ts=NOW):
        return {'type':'SWAP','signature':'signature1','timestamp':ts,'feePayer':WALLET,
                'events':{'swap':{'tokenInputs':[{'mint':inmint}],
                                  'tokenOutputs':[{'mint':outmint}]}}}
    def test_swaps_buy(self):
        ev=parse_helius_swaps([self.swap()],WALLET,NOW)
        self.assertEqual(ev[0].side,'BUY')
    def test_swaps_sell(self):
        ev=parse_helius_swaps([self.swap(MINT,USDC)],WALLET,NOW)
        self.assertEqual(ev[0].side,'SELL')
    def test_native_sol_buy(self):
        self.assertEqual(parse_helius_swaps([self.swap(SOL,MINT)],WALLET,NOW)[0].side,'BUY')
    def test_native_sol_swap_buy(self):
        tx=self.swap();tx['events']['swap']['tokenInputs']=[]
        tx['events']['swap']['nativeInput']={'amount':10_000_000}
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW)[0].side,'BUY')
    def test_native_sol_swap_sell(self):
        tx=self.swap(MINT,USDC);tx['events']['swap']['tokenOutputs']=[]
        tx['events']['swap']['nativeOutput']={'amount':10_000_000}
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW)[0].side,'SELL')
    def test_token_balance_delta_quantity(self):
        tx=self.swap()
        tx['events']['swap']['tokenOutputs'][0]['rawTokenAmount']={'tokenAmount':'1234567','decimals':6}
        tx['events']['swap']['tokenOutputs'][0]['userAccount']=WALLET
        ev=parse_helius_swaps([tx],WALLET,NOW)
        self.assertEqual(ev[0].source_qty,D('1.234567'))
    def test_reject_other_wallet_output(self):
        tx=self.swap()
        tx['events']['swap']['tokenOutputs'][0]['userAccount']='other'
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW),[])
    def test_ignore_swap_not_paid_by_trader(self):
        tx=self.swap();tx['feePayer']='some_other_wallet'
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW),[])
    def test_ignore_transfer(self):
        tx=self.swap();tx['type']='TRANSFER'
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW),[])
    def test_ignore_stale(self):self.assertEqual(parse_helius_swaps([self.swap(ts=NOW-500)],WALLET,NOW),[])
    def test_ignore_complex(self):
        tx=self.swap();tx['events']['swap']['tokenOutputs'].append({'mint':WALLET})
        self.assertEqual(parse_helius_swaps([tx],WALLET,NOW),[])
    def test_empty_response_error(self):
        with self.assertRaises(DataUnavailable):parse_helius_swaps({'fake':'tx'},WALLET,NOW)
    def test_helius_initial_baseline(self):
        txs=[self.swap()]
        h=Helius(key='f',fetch=lambda _:txs)
        records,cursor=h.since(WALLET,None)
        self.assertEqual(cursor,'signature1')
    def test_helius_cursor_found(self):
        txs=[dict(self.swap(),signature='new'),dict(self.swap(),signature='old')]
        h=Helius(key='f',fetch=lambda _:txs)
        rows,new=h.since(WALLET,'old')
        self.assertEqual([t['signature'] for t in rows],['new'])
        self.assertEqual(new,'new')
    def test_helius_missing_cursor_halts(self):
        h=Helius(key='f',fetch=lambda _:[self.swap()])
        with self.assertRaises(DataUnavailable):h.since(WALLET,'missing')
    def test_jupiter_no_trade_on_invalid_quote(self):
        j=Jupiter(key='x',fetch=lambda *a,**k:{'outAmount':'0','requestId':'id'})
        with self.assertRaises(DataUnavailable):j.order(USDC,MINT,10000)
    def test_jupiter_quote_positive(self):
        j=Jupiter(key='x',fetch=lambda *a,**k:{'outAmount':'500','requestId':'id'})
        self.assertEqual(j.order(USDC,MINT,100)['outAmount'],'500')
    def test_rpc_mint_checks(self):
        rpc=SolanaRPC(fetch=lambda *a,**k:{'result':{'value':{'owner':'BAD'}}})
        with self.assertRaises(DataUnavailable):rpc.mint_info(MINT)
    def test_rpc_freeze_checks(self):
        from bot.providers import TOKEN_PROGRAM
        obj={'value':{'owner':TOKEN_PROGRAM,'data':{'parsed':{'type':'mint','info':{
                'decimals':6,'mintAuthority':None,'freezeAuthority':'BAD'}}}}}
        rpc=SolanaRPC(fetch=lambda *a,**k:{'result':obj})
        with self.assertRaises(DataUnavailable):rpc.mint_info(MINT)

class BotTests(Setup):
    def test_first_snapshot_cannot_trade(self):
        self.bot.tick()
        self.assertEqual(len(self.bot.state['trades']),0)
    def test_second_snapshot_can_trade(self):
        self.buy()
        self.assertEqual(len(self.bot.state['trades']),1)
        self.assertEqual(self.bot.state['trades'][0]['side'],'BUY')
    def test_trade_small_and_fee(self):
        self.buy()
        self.assertLess(D(self.bot.state['cash_usdc']),D('46'))
        self.assertGreater(D(self.bot.state['cash_usdc']),D('45'))
    def test_one_entry_per_token(self):
        self.buy();self.advance(price='1.06');self.bot.tick()
        self.assertEqual(sum(x['side']=='BUY' for x in self.bot.state['trades']),1)
    def test_take_profit(self):
        self.buy();self.advance(price='1.85');self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['side'],'SELL')
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'take_profit')
    def test_trailing_stop(self):
        self.buy();self.advance(price='1.36');self.bot.tick()
        self.advance(price='1.12');self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'trailing_stop')
    def test_stop_loss(self):
        self.buy();self.advance(price='0.79');self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'stop_loss')
    def test_time_stop(self):
        self.buy();self.advance(seconds=5500,price='1.035');self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'time_stop')
    def test_session_end_liquidates(self):
        self.buy();self.advance(seconds=12*3600,price='1.04');self.bot.tick()
        self.assertEqual(self.bot.state['trades'][-1]['reason'],'end_of_session')
        self.assertTrue(self.bot.state['halted'])
    def test_no_trade_bad_token(self):
        self.bot.tick();self.advance();self.rpc.bad=True;self.bot.tick()
        self.assertEqual(len(self.bot.state['trades']),0)
    def test_no_trade_concentration(self):
        self.bot.tick();self.advance();self.rpc.conc=D('.95');self.bot.tick()
        self.assertEqual(len(self.bot.state['trades']),0)
    def test_no_trade_high_round_trip(self):
        self.bot.tick();self.advance()
        old=self.cfg.max_round_trip_loss_fraction;self.cfg.max_round_trip_loss_fraction='0.001'
        self.bot.tick();self.assertEqual(len(self.bot.state['trades']),0)
        self.cfg.max_round_trip_loss_fraction=old
    def test_no_trade_jupiter_offline(self):
        self.bot.tick();self.advance();self.jup.fail=True;self.bot.tick()
        self.assertEqual(len(self.bot.state['trades']),0)
    def test_no_trade_excess_fee(self):
        self.bot.tick();self.advance();self.jup.fee=400;self.bot.tick()
        self.assertEqual(len(self.bot.state['trades']),0)
    def test_market_outage_pauses_scout_then_recovers(self):
        self.dex.fail=True
        for _ in range(3):self.clock.now+=1;report=self.bot.tick()
        self.assertFalse(self.bot.state['halted'])
        self.assertTrue(report['scout_paused'])
        self.assertEqual(report['consecutive_discovery_failures'],3)
        self.dex.fail=False
        self.clock.now+=1
        report=self.bot.tick()
        self.assertFalse(report['scout_paused'])
        self.assertEqual(report['consecutive_discovery_failures'],0)
    def test_restart_persists_position(self):
        self.buy()
        bot2=Bot(self.cfg,self.store,dex=self.dex,helius=FakeHelius(),jupiter=self.jup,
                 rpc=self.rpc,now=self.clock)
        self.assertIn(MINT,bot2.state['positions'])
    def test_restart_never_duplicates(self):
        self.buy();self.advance();self.bot.tick()
        bot2=Bot(self.cfg,self.store,dex=self.dex,helius=FakeHelius(),jupiter=self.jup,
                 rpc=self.rpc,now=self.clock)
        bot2.tick();self.assertEqual(sum(t['side']=='BUY' for t in bot2.state['trades']),1)
    def test_stop_file_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'STOP_TRADING'
            with patch('bot.runner.Path',side_effect=lambda x: path if str(x)=='STOP_TRADING' else Path(x)):
                path.touch();self.bot.tick()
        self.assertTrue(self.bot.state['halted'])
    def test_report_uses_net_executable_exit_not_dex_mark(self):
        self.buy()
        report=self.bot._report(self.clock())
        self.assertTrue(report['equity_uses_jupiter_liquidation_quotes'])
        self.assertIsNotNone(report['equity_estimate_usdc'])
        self.assertLess(D(report['equity_estimate_usdc']),
                        D(report['dex_mark_equity_usdc']))

    def test_failed_liquidation_quote_blocks_new_buys_and_unknown_pnl(self):
        self.buy();self.advance()
        self.jup.fail=True
        report=self.bot.tick()
        self.assertFalse(report['halted'])
        self.assertFalse(report['quote_data_ready'])
        self.assertTrue(report['buying_paused'])
        self.assertIsNone(report['equity_estimate_usdc'])
        self.assertIsNotNone(report['dex_mark_equity_usdc'])
        self.assertEqual(len(self.bot.state['trades']),1)

    def test_report_no_fabrication_on_missing_quote(self):
        self.buy()
        report=self.store.report(self.bot.state,{},self.clock())
        self.assertIsNone(report['equity_estimate_usdc'])
        self.assertEqual(report['stale_positions'],[MINT])
    def test_json_export(self):
        report=self.bot.tick();path=Path(self.temp.name)/'docs/status.json'
        write_report(report,path)
        self.assertEqual(json.loads(path.read_text())['version'],'14.3')
    def test_unresolved_order_blocks_restart(self):
        self.store.prepare_intent('id','BUY',MINT,123,self.clock())
        self.assertIsNotNone(self.store.unresolved())
        self.store.intent_status('id','CONFIRMED_PENDING_ACCOUNTING')
        self.assertIsNotNone(self.store.unresolved())
        self.store.intent_status('id','APPLIED')
        self.assertIsNone(self.store.unresolved())
    def test_live_requires_manual_gate(self):
        cfg=Config(mode='LIVE',live_mint_allowlist=[MINT]);cfg.validate()
        with patch.dict('os.environ',{},clear=True):
            with self.assertRaises(LiveExecutionDisabled):JupiterLive(cfg,self.store)
    def test_wallet_bootstrap_doesnt_copy_history(self):
        cfg=Config(trader_wallets=[WALLET])
        cfg.validate()
        clock=Clock();dex=FakeDex(clock);h=FakeHelius()
        # make separate db so config does not matter on old paper state
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()
        self.assertEqual(bot.state['trades'],[])
        self.assertEqual(self.store.get('wallet_cursor:'+WALLET),{'initialized':True,'signature':'latest','bootstrap_ts':NOW})
    def test_wallet_copy_without_scout(self):
        cfg=Config(trader_wallets=[WALLET],scout_enabled=False);clock=Clock();dex=FakeDex(clock);h=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick();clock.now+=65
        tx={'type':'SWAP','signature':'onchain','timestamp':clock(),'feePayer':WALLET,
            'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                              'tokenOutputs':[{'mint':MINT}]}}}
        h.results=[tx];bot.tick()
        self.assertEqual(bot.state['trades'][0]['source'],'COPIER')
    def test_wallet_copies_partial_sell(self):
        cfg=Config(trader_wallets=[WALLET],scout_enabled=False);clock=Clock();dex=FakeDex(clock);h=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick();clock.now+=65
        buy={'type':'SWAP','signature':'first','timestamp':clock(),'feePayer':WALLET,
            'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                              'tokenOutputs':[{'mint':MINT,'rawTokenAmount':{'tokenAmount':'100000000','decimals':6}}]}}}
        h.results=[buy];bot.tick()
        self.assertEqual(len(bot.state['trades']),1)
        clock.now+=65
        sell={'type':'SWAP','signature':'second','timestamp':clock(),'feePayer':WALLET,
            'events':{'swap':{'tokenInputs':[{'mint':MINT,'rawTokenAmount':{'tokenAmount':'-20000000','decimals':6}}],
                              'tokenOutputs':[{'mint':USDC}]}}}
        h.results=[sell];bot.tick()
        self.assertEqual(len(bot.state['trades']),2)
        self.assertIn(MINT,bot.state['positions'])
        self.assertAlmostEqual(float(bot.state['trades'][-1]['fraction_sold']),.2,places=5)
    def test_wallet_copy_buy(self):
        cfg=Config(trader_wallets=[WALLET]);clock=Clock();dex=FakeDex(clock);h=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick();clock.now+=130;dex.price=D('1.03')
        from bot.providers import WalletSwap
        tx={'type':'SWAP','signature':'ok','timestamp':clock(),'feePayer':WALLET,
            'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                              'tokenOutputs':[{'mint':MINT}]}}}
        h.results=[tx];bot.tick()
        self.assertEqual(bot.state['trades'][0]['source'],'COPIER')
    def test_wallet_feed_gap_retries_without_permanent_halt(self):
        cfg=Config(trader_wallets=[WALLET]);clock=Clock();dex=FakeDex(clock);h=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=h,jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()
        h.since=lambda *_:(_ for _ in ()).throw(DataUnavailable('cursor not found'))
        bot.tick();self.assertFalse(bot.state['halted'])
        self.assertIn('wallet_data_failure',[x['reason'] for x in self.store.last_events()])

if __name__=='__main__':unittest.main()
