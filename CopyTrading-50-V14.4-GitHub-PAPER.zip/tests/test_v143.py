"""V14.3: profitable-opportunity prioritization and recoverable data outages.

Deterministic fixtures, not a profitability backtest.
"""
from __future__ import annotations
from dataclasses import replace
from datetime import datetime, timezone
from decimal import Decimal
import unittest

from test_v14 import Setup, Clock, FakeDex, FakeHelius, FakeJup, FakeRPC, MINT, WALLET, NOW, market
from bot.providers import DataUnavailable, USDC
from bot.runner import Bot
from bot.settings import Config,D
from bot.risk import risk_budget
from bot.strategy import source_gate

LOW='C'*43
HIGH='D'*43


class RecoverableOutages(Setup):
    def test_liquidation_quote_recovery_unblocks_without_restarting(self):
        self.buy()
        self.advance()
        self.jup.fail=True
        report=self.bot.tick()
        self.assertFalse(report['quote_data_ready'])
        self.assertFalse(report['halted'])
        self.jup.fail=False
        self.advance(price='1.03')
        report=self.bot.tick()
        self.assertTrue(report['quote_data_ready'])
        self.assertFalse(report['buying_paused'])
        self.assertIsNotNone(report['equity_estimate_usdc'])

    def test_discovery_outage_does_not_prevent_copy_from_independent_feed(self):
        class FailingDiscovery:
            def discover(self,limit=40):
                raise DataUnavailable('pool discovery service unavailable')

        cfg=Config(trader_wallets=[WALLET]);cfg.validate()
        clock=Clock();dex=FakeDex(clock);hel=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,discoverer=FailingDiscovery(),helius=hel,
                jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        first=bot.tick()
        self.assertTrue(first['scout_paused'])
        clock.now+=60
        hel.results=[{'type':'SWAP','signature':'good_wallet_buy','timestamp':clock(),
                      'feePayer':WALLET,'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                                                       'tokenOutputs':[{'mint':MINT}]}}}]
        result=bot.tick()
        self.assertTrue(result['scout_paused'])
        self.assertEqual(len(bot.state['trades']),1)
        self.assertEqual(bot.state['trades'][0]['source'],'COPIER')
        self.assertEqual(len(bot.state['positions']),1)

    def test_same_batch_buy_then_sell_is_not_copied_late(self):
        cfg=Config(trader_wallets=[WALLET]);cfg.validate()
        clock=Clock();dex=FakeDex(clock);hel=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=hel,jupiter=FakeJup(dex),
                rpc=FakeRPC(),now=clock)
        bot.tick()  # establish cursor, never copy initial history
        clock.now+=60
        def swap(sig,side,ts):
            return {'type':'SWAP','signature':sig,'timestamp':ts,'feePayer':WALLET,
                    'events':{'swap':{'tokenInputs':[{'mint':USDC if side=='BUY' else MINT}],
                                      'tokenOutputs':[{'mint':MINT if side=='BUY' else USDC}]}}}
        hel.results=[swap('same_batch_sell','SELL',clock()),
                     swap('same_batch_buy','BUY',clock()-2)]
        bot.tick()
        self.assertEqual(bot.state['trades'],[])
        self.assertIn('source_sold_before_copy_cycle',
                      [x['reason'] for x in self.store.last_events()])

    def test_missing_discovery_data_never_creates_fake_scout_trade(self):
        self.dex.fail=True
        for _ in range(4):
            self.clock.now+=60
            r=self.bot.tick()
        self.assertTrue(r['scout_paused'])
        self.assertEqual(self.bot.state['trades'],[])
        self.assertEqual(self.bot.state['cash_usdc'],'50')


class CandidateRanking(Setup):
    def test_best_score_is_selected_before_first_discovered(self):
        class SeveralDex(FakeDex):
            def discover(self,limit=30):return [LOW,HIGH]
            def markets(self,mints,now=None):
                results={}
                for mint in mints:
                    candidate=market(now=now,mint=mint,price=str(self.price))
                    if mint==LOW:
                        candidate=replace(candidate,liquidity_usd=D('35000'),buys_5m=12,sells_5m=9,
                                          volume_5m_usd=D('4000'))
                    if mint==HIGH:
                        candidate=replace(candidate,liquidity_usd=D('120000'),buys_5m=80,sells_5m=10,
                                          volume_5m_usd=D('20000'))
                    results[mint]=candidate
                return results

        cfg=Config(max_open_positions=1);cfg.validate()
        clock=Clock();dex=SeveralDex(clock)
        bot=Bot(cfg,self.store,dex=dex,helius=FakeHelius(),
                jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()
        clock.now+=130;dex.price=D('1.03');bot.tick()
        self.assertEqual(len(bot.state['trades']),1)
        self.assertEqual(bot.state['trades'][0]['mint'],HIGH)
        self.assertEqual(bot.scout_candidates[0]['mint'],HIGH)

    def test_selling_does_not_consume_new_entry_quota(self):
        cfg=Config(max_trades_per_session=2);cfg.validate()
        state={'halted':False,'positions':{},'cash_usdc':'50',
               'trades':[{'side':'BUY'}]+[{'side':'SELL'}]*12,
               'peak_equity_usdc':'50','day_start_equity_usdc':'50'}
        budget,reason=risk_budget(state,cfg,{})
        self.assertGreater(budget,D(0))
        self.assertEqual(reason,'pass')
        state['trades'].append({'side':'BUY'})
        budget,reason=risk_budget(state,cfg,{})
        self.assertEqual(budget,D(0))
        self.assertEqual(reason,'session_entry_limit')


class AdaptiveRecovery(unittest.TestCase):
    @staticmethod
    def closing_trade(pnl,idx,minute):
        return {'side':'SELL','position_id':f'M:{idx}','source':'SCOUT',
                'mint':'M','position_fully_closed':True,
                'realized_pnl_usdc':str(pnl),
                'time':datetime.fromtimestamp(NOW+60*minute,timezone.utc).isoformat()}

    def test_losing_strategy_recovers_only_after_cooldown(self):
        trades=[self.closing_trade('-0.1',i,i) for i in range(5)]
        last_close=NOW+4*60
        enabled,reason=source_gate(trades,'SCOUT',None,now=last_close+120,cooldown_seconds=1800)
        self.assertFalse(enabled)
        self.assertIn('cooldown',reason)
        enabled,reason=source_gate(trades,'SCOUT',None,now=last_close+1801,cooldown_seconds=1800)
        self.assertTrue(enabled)
        self.assertEqual(reason,'strategy_cooldown_elapsed_retest_allowed')
        trades.append(self.closing_trade('-0.1',5,40))
        enabled,_=source_gate(trades,'SCOUT',None,now=NOW+41*60,cooldown_seconds=1800)
        self.assertFalse(enabled)

    def test_no_timestamp_cannot_implicitly_bypass_gate(self):
        trades=[{'side':'SELL','position_id':f'M:{i}','mint':'M','source':'SCOUT',
                 'realized_pnl_usdc':'-1','position_fully_closed':True} for i in range(5)]
        enabled,_=source_gate(trades,'SCOUT',None,now=NOW+500000)
        self.assertFalse(enabled)


if __name__=='__main__':unittest.main()


class WalletPollingCases(Setup):
    """Fast on-chain flips must not be replayed as imaginary profitable trades."""
    def test_buy_and_sell_in_same_batch_are_not_copied_late(self):
        cfg=Config(trader_wallets=[WALLET],scout_enabled=False);cfg.validate()
        clock=Clock();dex=FakeDex(clock);hel=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=hel,
                jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()  # Helius cursor bootstrap: do not copy history
        clock.now+=60
        buy={'type':'SWAP','signature':'fast_buy','timestamp':clock.now-4,
             'feePayer':WALLET,'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                                                     'tokenOutputs':[{'mint':MINT}]}}}
        sell={'type':'SWAP','signature':'fast_sell','timestamp':clock.now-2,
              'feePayer':WALLET,'events':{'swap':{'tokenInputs':[{'mint':MINT}],
                                                      'tokenOutputs':[{'mint':USDC}]}}}
        hel.results=[buy,sell]
        bot.tick()
        self.assertEqual(bot.state['trades'],[])
        self.assertEqual(bot.state['positions'],{})
        stats=bot.state['wallet_profiles'][WALLET]
        self.assertEqual(stats['completed_roundtrips'],1)
        self.assertEqual(stats['quick_sells'],1)
        self.assertTrue(any(e['reason']=='source_sold_before_copy_cycle'
                            for e in self.store.last_events()))

    def test_later_buy_after_earlier_sell_is_not_suppressed(self):
        cfg=Config(trader_wallets=[WALLET],scout_enabled=False);cfg.validate()
        clock=Clock();dex=FakeDex(clock);hel=FakeHelius()
        bot=Bot(cfg,self.store,dex=dex,helius=hel,
                jupiter=FakeJup(dex),rpc=FakeRPC(),now=clock)
        bot.tick()
        clock.now+=60
        old_sell={'type':'SWAP','signature':'earlier_sell','timestamp':clock.now-15,
                  'feePayer':WALLET,'events':{'swap':{'tokenInputs':[{'mint':MINT}],
                                                          'tokenOutputs':[{'mint':USDC}]}}}
        new_buy={'type':'SWAP','signature':'later_buy','timestamp':clock.now-1,
                 'feePayer':WALLET,'events':{'swap':{'tokenInputs':[{'mint':USDC}],
                                                        'tokenOutputs':[{'mint':MINT}]}}}
        hel.results=[old_sell,new_buy]
        bot.tick()
        self.assertEqual(len(bot.state['trades']),1)
        self.assertEqual(bot.state['trades'][0]['side'],'BUY')
