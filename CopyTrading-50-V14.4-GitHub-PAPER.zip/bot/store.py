"""Crash-resistant SQLite state, dedup and order-submission journal."""
from __future__ import annotations
from datetime import datetime,timezone
from decimal import Decimal
import json
from pathlib import Path
import sqlite3
import time
from .settings import Config,D


class Store:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(str(self.path),timeout=20,isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS observations(
            id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL, ts INTEGER NOT NULL,
            price TEXT NOT NULL, liquidity TEXT NOT NULL, score INTEGER NOT NULL);
          CREATE INDEX IF NOT EXISTS observations_mint ON observations(mint,ts);
          CREATE TABLE IF NOT EXISTS events(
            event_id TEXT PRIMARY KEY, ts INTEGER NOT NULL, kind TEXT NOT NULL,
            decision TEXT NOT NULL, reason TEXT NOT NULL, details TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS intents(
            id TEXT PRIMARY KEY, created INTEGER NOT NULL, status TEXT NOT NULL,
            side TEXT NOT NULL, mint TEXT NOT NULL, amount INTEGER NOT NULL,
            signature TEXT, result TEXT);
        ''')
    def close(self):self.db.close()
    def get(self,key,default=None):
        row=self.db.execute('SELECT v FROM kv WHERE k=?',(key,)).fetchone()
        return json.loads(row[0]) if row else default
    def put(self,key,value):
        with self.db:self.db.execute('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',
                                     (key,json.dumps(value,separators=(',',':'),default=str)))
    def initialize(self,cfg:Config,now:int):
        state=self.get('portfolio')
        if state is None:
            state={'created_at':now,'expires_at':now+cfg.session_hours*3600,
                   'starting_usdc':cfg.starting_usdc,'cash_usdc':cfg.starting_usdc,
                   'positions':{},'trades':[], 'wallet_profiles':{},
                   'peak_equity_usdc':cfg.starting_usdc,
                   'day':datetime.fromtimestamp(now,timezone.utc).strftime('%Y-%m-%d'),
                   'day_start_equity_usdc':cfg.starting_usdc,'halted':False,
                   'halt_reason':'','last_market_update':0,'last_checked':0,'mode':cfg.mode}
            self.put('portfolio',state)
        elif state.get('mode')!=cfg.mode:
            raise ValueError('Cannot switch PAPER/LIVE mode on existing database. Use a different db.')
        return state
    def seen(self,event_id):
        return self.db.execute('SELECT 1 FROM events WHERE event_id=?',(event_id,)).fetchone() is not None
    def decision(self,state,event_id,kind,decision,reason,details=None,ts=None):
        ts=int(time.time()) if ts is None else int(ts)
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO events VALUES(?,?,?,?,?,?)',
                            (event_id,ts,kind,decision,reason,json.dumps(details or {},default=str)))
            self.db.execute('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',
                            ('portfolio',json.dumps(state,default=str,separators=(',',':'))))
    def observe(self,m,score):
        self.db.execute('INSERT INTO observations(mint,ts,price,liquidity,score) VALUES(?,?,?,?,?)',
                        (m.mint,m.observed_at,str(m.price_usd),str(m.liquidity_usd),score))
        self.db.execute('DELETE FROM observations WHERE id IN (SELECT id FROM observations ORDER BY id DESC LIMIT -1 OFFSET 20000)')
    def earlier(self,mint,now,wait=120):
        row=self.db.execute('SELECT ts,price,score,liquidity FROM observations WHERE mint=? AND ts<=? ORDER BY ts DESC LIMIT 1',
                            (mint,now-wait)).fetchone()
        return {'ts':row[0],'price':D(row[1]),'score':row[2],
                'liquidity':D(row[3])} if row else None
    def stats(self):
        rows=self.db.execute('SELECT decision,reason,count(*) FROM events GROUP BY decision,reason ORDER BY count(*) DESC').fetchall()
        return [{'decision':a,'reason':b,'count':n} for a,b,n in rows]
    def last_events(self,limit=100):
        rows=self.db.execute('SELECT ts,kind,decision,reason,details FROM events ORDER BY rowid DESC LIMIT ?',
                            (limit,)).fetchall()
        return [{'ts':ts,'kind':k,'decision':d,'reason':r,'details':json.loads(info)} for ts,k,d,r,info in rows]
    def unresolved(self):
        return self.db.execute("SELECT id,status,side,mint FROM intents WHERE status!='APPLIED' AND status!='CANCELLED' LIMIT 1").fetchone()
    def prepare_intent(self,ident,side,mint,amount,now):
        with self.db:self.db.execute('INSERT INTO intents(id,created,status,side,mint,amount) VALUES(?,?,?,?,?,?)',
                                   (ident,now,'PREPARED',side,mint,amount))
    def intent_status(self,ident,status,signature=None,result=None):
        with self.db:self.db.execute('UPDATE intents SET status=?, signature=COALESCE(?,signature),result=? WHERE id=?',
                       (status,signature,json.dumps(result,default=str) if result is not None else None,ident))
    def report(self,state,marks,now,liquidations=None):
        exposure=D(0);pos=[];stale=[]
        for mint,p in state['positions'].items():
            m=marks.get(mint)
            # Never pass stale holdings off as zero-value or priced at the entry mark.
            if m is None:stale.append(mint);value=None
            else:value=D(p['qty'])*m.price_usd;exposure+=value
            exit_value=(str(D(liquidations[mint])) if liquidations is not None and mint in liquidations else None)
            pos.append({'mint':mint,'symbol':p['symbol'],'qty':p['qty'],
                        'estimated_exit_value_usdc':exit_value,
                        'partial_take_profit_done':p.get('partial_take_profit_done',False),
                        'entry_price_usd':p['entry_price_usd'],
                        'marked_value_usdc':str(value) if value is not None else None,
                        'peak_price_usd':p['peak_price_usd'],'opened_at':p['opened_at']})
        cash=D(state['cash_usdc']);mark_equity=cash+exposure if not stale else None
        # liquidation values are net executable quote estimates. If a quote is
        # missing, do not replace it with a DexScreener mid-market assumption.
        if liquidations is None:
            equity=mark_equity  # direct legacy calls without Jupiter context
        else:
            equity=(cash+sum((D(liquidations[k]) for k in state['positions']),D(0))
                    if all(k in liquidations for k in state['positions']) else None)
        completed_ids={x['position_id'] for x in state['trades']
                       if x['side']=='SELL' and x.get('position_fully_closed',True)}
        realized_by_id={}
        for x in state['trades']:
            if x['side']=='SELL':
                pid=x.get('position_id',x['mint'])
                realized_by_id[pid]=realized_by_id.get(pid,D(0))+D(x['realized_pnl_usdc'])
        closed=[realized_by_id[k] for k in completed_ids]
        all_realized=sum(realized_by_id.values(),D(0))
        won=sum(p>0 for p in closed);lost=sum(p<0 for p in closed)
        max_dd=D(0);high=None
        for item in state.get('equity_history',[]):
            val=D(item['value']);high=max(val,high) if high is not None else val
            if high>0:max_dd=max(max_dd,(high-val)/high)
        return {'version':'14.3','mode':state['mode'],'timestamp_utc':datetime.fromtimestamp(now,timezone.utc).isoformat(),
                'session_start':state['created_at'],'session_end':state['expires_at'],
                'starting_balance_usdc':state['starting_usdc'],'cash_usdc':str(cash),
                'equity_estimate_usdc':str(equity) if equity is not None else None,
                'dex_mark_equity_usdc':str(mark_equity) if mark_equity is not None else None,
                'equity_uses_jupiter_liquidation_quotes':liquidations is not None,
                'pnl_estimate_usdc':str(equity-D(state['starting_usdc'])) if equity is not None else None,
                'estimated_only':True,
                'closed_positions':len(closed), 'winning_positions':won,'losing_positions':lost,
                'win_rate_percent':str(D(won)*100/D(len(closed))) if closed else None,
                'realized_pnl_usdc':str(all_realized),
                'max_observed_drawdown_percent':str(max_dd*100),
                'equity_history':state.get('equity_history',[]),
                'stale_positions':stale,'halted':state['halted'],
                'halt_reason':state['halt_reason'],'positions':pos,'trades':state['trades'],
                'event_stats':self.stats(),'last_events':self.last_events(),
                'disclaimer':'PAPER and live profits not guaranteed. Indicative Jupiter exits can change before settlement; LIVE excludes SOL gas and rent.'}
