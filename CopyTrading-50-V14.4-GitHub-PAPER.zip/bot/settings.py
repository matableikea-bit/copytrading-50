"""Validate every risk setting; no API keys in configuration files."""
from __future__ import annotations
from dataclasses import dataclass, field, fields
from decimal import Decimal, InvalidOperation
from pathlib import Path
import json


def D(x):
    try:
        n=Decimal(str(x))
        if not n.is_finite(): raise ValueError('non-finite')
        return n
    except (InvalidOperation, TypeError) as exc:
        raise ValueError('invalid decimal') from exc


@dataclass
class Config:
    mode: str = 'PAPER'
    starting_usdc: str = '50'
    poll_seconds: int = 60
    session_hours: int = 12
    max_trade_fraction: str = '0.08'
    max_total_exposure_fraction: str = '0.24'
    max_single_token_fraction: str = '0.08'
    max_daily_loss_fraction: str = '0.05'
    max_drawdown_fraction: str = '0.10'
    max_trades_per_session: int = 12
    max_open_positions: int = 3
    stop_loss_fraction: str = '0.10'
    take_profit_fraction: str = '0.60'
    partial_take_profit_fraction: str = '0.25'
    partial_take_profit_sell_fraction: str = '0.50'
    trailing_activation_fraction: str = '0.15'
    trailing_gap_fraction: str = '0.08'
    max_hold_minutes: int = 90
    min_liquidity_usd: str = '30000'
    min_volume_5m_usd: str = '3000'
    max_fdv_usd: str = '20000000'
    min_pool_age_seconds: int = 600
    max_pool_age_seconds: int = 259200
    max_quote_age_seconds: int = 120
    max_signal_age_seconds: int = 90
    max_5m_price_jump_percent: str = '25'
    max_round_trip_loss_fraction: str = '0.08'
    max_all_in_round_trip_loss_fraction: str = '0.10'
    max_jupiter_fee_bps: int = 300
    max_execution_slippage_bps: int = 200
    max_requote_deterioration_fraction: str = '0.03'
    paper_network_cost_usdc: str = '0.10'
    paper_extra_slippage_fraction: str = '0.005'
    reserve_sol: str = '0.02'
    min_trade_usdc: str = '2'
    scout_enabled: bool = True
    scout_signal_threshold: int = 78
    min_strategy_history: int = 5
    max_consecutive_strategy_losses: int = 3
    strategy_cooldown_seconds: int = 1800
    min_wallet_roundtrips: int = 3
    max_wallet_quick_sell_fraction: str = '0.67'
    wallet_flipper_seconds: int = 180
    max_liquidity_drop_fraction: str = '0.50'
    trader_wallets: list[str] = field(default_factory=list)
    live_mint_allowlist: list[str] = field(default_factory=list)
    helius_required_for_copy: bool = True

    @classmethod
    def load(cls, path):
        raw=json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(raw,dict): raise ValueError('configuration must be a JSON object')
        names={x.name for x in fields(cls)}
        unknown=set(raw)-names
        if unknown: raise ValueError('unknown config keys: '+', '.join(sorted(unknown)))
        cfg=cls(**raw)
        cfg.validate()
        return cfg

    def validate(self):
        if self.mode not in ('PAPER','LIVE'): raise ValueError('mode must be PAPER or LIVE')
        for k in ('starting_usdc','min_liquidity_usd','min_volume_5m_usd','max_fdv_usd',
                  'reserve_sol','min_trade_usdc'):
            if D(getattr(self,k)) <= 0: raise ValueError(k+' must be positive')
        for k in ('max_trade_fraction','max_total_exposure_fraction','max_single_token_fraction',
                  'max_daily_loss_fraction','max_drawdown_fraction','stop_loss_fraction',
                  'take_profit_fraction','partial_take_profit_fraction',
                  'partial_take_profit_sell_fraction','trailing_activation_fraction','trailing_gap_fraction',
                  'max_round_trip_loss_fraction','max_all_in_round_trip_loss_fraction','paper_extra_slippage_fraction',
                  'max_requote_deterioration_fraction', 'max_wallet_quick_sell_fraction',
                  'max_liquidity_drop_fraction'):
            if not D('0') <= D(getattr(self,k)) < D('1'): raise ValueError('invalid '+k)
        if D(self.partial_take_profit_sell_fraction)<=0:
            raise ValueError('partial_take_profit_sell_fraction must be positive')
        if D(self.partial_take_profit_fraction)>=D(self.take_profit_fraction):
            raise ValueError('partial take profit must precede full take profit')
        if D(self.max_single_token_fraction)>D(self.max_total_exposure_fraction):
            raise ValueError('single-token exposure cannot exceed total exposure')
        if D(self.max_trade_fraction)>D(self.max_total_exposure_fraction):
            raise ValueError('trade fraction cannot exceed total exposure')
        if D(self.paper_network_cost_usdc)<0: raise ValueError('negative network cost')
        if not 10<=self.poll_seconds<=3600: raise ValueError('invalid polling interval')
        if not 1<=self.session_hours<=72: raise ValueError('invalid session duration')
        if not 1<=self.max_open_positions<=20 or not 1<=self.max_trades_per_session<=100:
            raise ValueError('invalid trade limits')
        if not 1<=self.max_hold_minutes<=24*60: raise ValueError('invalid hold time')
        if not 1<=self.max_quote_age_seconds<=600 or not 1<=self.max_signal_age_seconds<=600:
            raise ValueError('invalid freshness')
        if not 60<=self.min_pool_age_seconds<self.max_pool_age_seconds:
            raise ValueError('invalid pool age range')
        if not 0<=self.max_jupiter_fee_bps<=1000: raise ValueError('invalid Jupiter fee')
        if not 1<=self.max_execution_slippage_bps<=500:raise ValueError('invalid execution slippage')
        if not 0<=self.scout_signal_threshold<=100: raise ValueError('invalid scout threshold')
        if not 300<=self.strategy_cooldown_seconds<=86400: raise ValueError('invalid strategy cooldown')
        if not 3<=self.min_strategy_history<=100 or not 2<=self.max_consecutive_strategy_losses<=10:
            raise ValueError('invalid adaptive strategy gate')
        if not 2<=self.min_wallet_roundtrips<=100 or not 30<=self.wallet_flipper_seconds<=3600:
            raise ValueError('invalid fair play gate')
        if not isinstance(self.trader_wallets,list) or not isinstance(self.live_mint_allowlist,list):
            raise ValueError('wallets/allowlist must be lists')
        for addr in self.trader_wallets+self.live_mint_allowlist:
            if not isinstance(addr,str) or not 32<=len(addr)<=44 or any(ch not in '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz' for ch in addr):
                raise ValueError('invalid base58 address in config')
        if len(set(self.trader_wallets))!=len(self.trader_wallets): raise ValueError('duplicate tracked wallet')
        if self.mode=='LIVE' and not self.live_mint_allowlist:
            raise ValueError('LIVE requires explicit token mint allowlist')
