"""Autonomous V14 pipeline. PAPER by default. See README for limitations."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime,timezone
from decimal import Decimal,ROUND_DOWN
import fcntl
import json
import os
from pathlib import Path
import signal
import sys
import time
from .settings import Config,D
from .providers import DexScreener,PoolDiscovery,Helius,Jupiter,SolanaRPC,USDC,DataUnavailable,parse_helius_swaps
from .risk import scout_score,analyst,risk_budget,exit_reason
from .strategy import source_gate, source_health
from .fairplay import observe_swap, wallet_gate, summary as wallet_fairplay_summary
from .store import Store
from .live import JupiterLive,LiveExecutionDisabled


def atoms(value,decimals):
    x=D(value)*D(10)**decimals
    return int(x.to_integral_value(rounding=ROUND_DOWN))


def stamp(now):return datetime.fromtimestamp(now,timezone.utc).isoformat()


@contextmanager
def singleton(path):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,'a+',encoding='utf-8') as lock:
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as e:raise RuntimeError('another copy of the bot is already running') from e
        yield


class Bot:
    def __init__(self,cfg:Config,store:Store,*,dex=None,discoverer=None,helius=None,jupiter=None,rpc=None,now=None):
        self.cfg=cfg;self.store=store;self.dex=dex or DexScreener()
        self.discoverer=discoverer or (PoolDiscovery(dex=self.dex) if dex is None else self.dex)
        self.helius=helius or Helius();self.jupiter=jupiter or Jupiter();self.rpc=rpc or SolanaRPC()
        self.clock=now or (lambda:int(time.time()))
        self.state=self.store.initialize(cfg,self.clock())
        if self.state.get('starting_usdc')!=cfg.starting_usdc:
            raise ValueError('Cannot change starting capital on existing database')
        self.live=JupiterLive(cfg,store,self.jupiter,self.rpc) if cfg.mode=='LIVE' else None
        if self.live and not self.state['trades'] and not self.state['positions']:
            initial_units,_=self.rpc.token_balance(self.live.wallet,USDC)
            if D(initial_units)/D(1_000_000)<D(self.cfg.starting_usdc):
                raise LiveExecutionDisabled('Initial USDC wallet balance below configured capital')
        self.marks={};self.exit_values={};self.failed_ticks=0;self.scout_candidates=[]
        self.entry_data_ready=True
        self.entry_pause_reasons=[]
        self.quote_data_ready=True

    def log(self,kind,decision,reason,details=None,event_id=None):
        event_id=event_id or f'{kind}:{reason}:{self.clock()}:{len(self.state["trades"])}'
        if not self.store.seen(event_id):
            self.store.decision(self.state,event_id,kind,decision,reason,details,ts=self.clock())

    def equity(self):
        """Value positions at indicative executable Jupiter exits, not display prices."""
        if any(mint not in self.exit_values for mint in self.state['positions']):return None
        return D(self.state['cash_usdc'])+sum((self.exit_values[mint]
                                               for mint in self.state['positions']),D(0))

    def _refresh_liquidations(self):
        """Get fresh executable sell quotes. Missing quotes make P&L unknown.

        Quotes can fail or deteriorate before execution; this is still only
        an ESTIMATE, not a promise that the swap will settle at this value.
        """
        values={}
        for mint,p in self.state['positions'].items():
            # An executable Jupiter exit quote is independent of DexScreener: always
            # try to value a holding even when its market listing has disappeared.
            try:
                raw=int(p['raw_qty'])
                if raw<=0:raise DataUnavailable('invalid stored token balance')
                q=self.jupiter.order(mint,USDC,raw)
                if int(q.get('feeBps') or 0)>self.cfg.max_jupiter_fee_bps:
                    raise DataUnavailable('liquidation quote fees exceed cap')
                value=D(q['outAmount'])/D(1_000_000)
                if self.cfg.mode=='PAPER':
                    value=value*(1-D(self.cfg.paper_extra_slippage_fraction))
                    value-=D(self.cfg.paper_network_cost_usdc)
                if value<=0:raise DataUnavailable('liquidation proceeds nonpositive')
                values[mint]=value
                if not self.jupiter.key:time.sleep(2.1)
            except (DataUnavailable,ValueError,KeyError,TypeError) as exc:
                self.log('RISK','ERROR','cannot_value_executable_exit',
                         {'mint':mint,'reason':str(exc)[:100]})
        self.exit_values=values

    def update_risk(self,now):
        equity=self.equity()
        if equity is None:
            # A temporary quote outage must not permanently brick the bot.
            # Unknown exposure already blocks new buys in risk_budget; the
            # next cycle keeps trying to price/sell held positions.
            self.quote_data_ready=False
            self.entry_pause_reasons.append('position_quote_missing')
            return
        self.quote_data_ready=True
        if equity>D(self.state['peak_equity_usdc']):self.state['peak_equity_usdc']=str(equity)
        day=datetime.fromtimestamp(now,timezone.utc).strftime('%Y-%m-%d')
        if day!=self.state['day']:
            self.state['day']=day;self.state['day_start_equity_usdc']=str(equity)
        if equity<=D(self.state['peak_equity_usdc'])*(1-D(self.cfg.max_drawdown_fraction)):
            self.state['halted']=True;self.state['halt_reason']='drawdown'
        if equity<=D(self.state['day_start_equity_usdc'])*(1-D(self.cfg.max_daily_loss_fraction)):
            self.state['halted']=True;self.state['halt_reason']='daily_loss'
        self.state['equity_history']=self.state.get('equity_history',[])[-500:]+[
            {'ts':now,'value':str(equity)}]

    def check_token(self,mint):
        # Cache immutable mint-authority checks only for this process. Holder concentration can change.
        try:
            decimals=self.rpc.mint_info(mint)
            concentration=self.rpc.largest_holders(mint)
            if concentration>D('0.80'):
                raise DataUnavailable('top_ten_token_accounts_over_80pct_of_supply')
            return decimals
        except DataUnavailable:
            raise
        except Exception as exc:
            raise DataUnavailable('onchain_token_checks_unavailable') from exc

    def _roundtrip(self,mint,amount_usdc,decimals):
        raw=atoms(amount_usdc,6)
        if raw<=0:raise DataUnavailable('notional too small')
        buy=self.jupiter.order(USDC,mint,raw)
        received=int(D(buy['outAmount'])*(1-D(self.cfg.paper_extra_slippage_fraction)))
        if received<=0:raise DataUnavailable('zero token output')
        # Limit requests: Jupiter keyless may throttle above 0.5 RPS.
        if not self.jupiter.key:time.sleep(2.1)
        reverse=self.jupiter.order(mint,USDC,received)
        if max(int(buy.get('feeBps') or 0),int(reverse.get('feeBps') or 0))>self.cfg.max_jupiter_fee_bps:
            raise DataUnavailable('swap_fees_too_high')
        back=D(reverse['outAmount'])/D(1_000_000)
        loss=1-back/amount_usdc
        if loss>D(self.cfg.max_round_trip_loss_fraction):
            raise DataUnavailable('roundtrip_slippage_or_fee_too_high')
        # Conservative full-cycle cost including BOTH assumed paper network
        # charges and another sell-side quote deterioration.  Small tickets
        # should not be accepted when friction eats a material share of capital.
        gas=D(self.cfg.paper_network_cost_usdc)
        total_paid=amount_usdc+gas
        net_liquidation=back*(1-D(self.cfg.paper_extra_slippage_fraction))-gas
        all_in_loss=(total_paid-net_liquidation)/total_paid
        if net_liquidation<=0 or all_in_loss>D(self.cfg.max_all_in_round_trip_loss_fraction):
            raise DataUnavailable('all_in_roundtrip_cost_too_high')
        return received,buy,reverse

    def _buy(self,mint,kind,event_id,details=None):
        now=self.clock()
        if self.store.seen(event_id):return
        # SCOUT requires a healthy discovery cycle, but COPIER can still act
        # on a fresh independently verified wallet signal and token market
        # quote when the unrelated token-discovery service is down.
        if kind=='SCOUT' and not self.entry_data_ready:
            self.log(kind,'REJECT','scout_discovery_unavailable',details,event_id);return
        if self.state['halted'] or Path('STOP_TRADING').exists() or Path('PAUSE_BUYS').exists():
            self.log(kind,'REJECT','halted_or_paused',details,event_id);return
        source_id=(details or {}).get('wallet') if kind=='COPIER' else None
        if kind=='COPIER' and source_id:
            fair, fair_reason=wallet_gate(self.state.get('wallet_profiles',{}),source_id,
                              minimum_roundtrips=self.cfg.min_wallet_roundtrips,
                              max_quick_sell_fraction=self.cfg.max_wallet_quick_sell_fraction)
            if not fair:
                self.log(kind,'REJECT',fair_reason,{'source_wallet':source_id},event_id);return
        allowed,gating_reason=source_gate(self.state['trades'],kind,source_id,
                                          self.cfg.min_strategy_history,
                                          self.cfg.max_consecutive_strategy_losses,
                                          now=now,cooldown_seconds=self.cfg.strategy_cooldown_seconds)
        if not allowed:
            self.log(kind,'REJECT',gating_reason,{'source_wallet':source_id},event_id);return
        if now>=self.state['expires_at']:
            self.log(kind,'REJECT','session_expired',details,event_id);return
        m=self.marks.get(mint)
        if not m:
            self.log(kind,'REJECT','no_qualified_market_quote',details,event_id);return
        reasons=analyst(m,self.cfg,now)
        prior=self.store.earlier(mint,now,120)
        if prior and prior['liquidity']>0 and m.liquidity_usd<prior['liquidity']*(1-D(self.cfg.max_liquidity_drop_fraction)):
            reasons.append('liquidity_collapse_on_recent_observations')
        if reasons:
            self.log(kind,'REJECT',','.join(reasons),details,event_id);return
        if mint in self.state['positions']:
            self.log(kind,'REJECT','already_owned',details,event_id);return
        if self.cfg.mode=='LIVE' and mint not in self.cfg.live_mint_allowlist:
            self.log(kind,'REJECT','mint_not_live_allowlisted',details,event_id);return
        budget,reason=risk_budget(self.state,self.cfg,self.marks,self.exit_values)
        budget=min(budget,D(self.state['cash_usdc'])-D(self.cfg.paper_network_cost_usdc))
        if budget<D(self.cfg.min_trade_usdc):
            self.log(kind,'REJECT',reason if reason!='pass' else 'insufficient_gas_budget',details,event_id);return
        try:
            decimals=self.check_token(mint)
            token_amount,buy,reverse=self._roundtrip(mint,budget,decimals)
        except (DataUnavailable,ValueError,TypeError) as exc:
            self.log(kind,'REJECT','preflight_'+str(exc)[:100],details,event_id);return
        if self.cfg.mode=='LIVE':
            # Actual spent and acquired token amounts are from Jupiter's confirmed execution response.
            try:
                exec_result=self.live.swap('BUY',mint,atoms(budget,6),decimals,
                                           expected_out_units=token_amount)
                token_amount=int(exec_result['totalOutputAmount'])
                spent=D(exec_result['totalInputAmount'])/D(1_000_000)
                if token_amount<=0 or spent<=0:raise LiveExecutionDisabled('invalid confirmed fill')
            except LiveExecutionDisabled as exc:
                self.state['halted']=True;self.state['halt_reason']='live_execution_error'
                self.log(kind,'ERROR','live_order_blocked_or_unknown',{'error':str(exc)},event_id)
                return
            extra=D(0) # SOL priority/gas not included in these USDC figures.
        else:
            spent=budget;extra=D(self.cfg.paper_network_cost_usdc)
        qty=D(token_amount)/(D(10)**decimals)
        if qty<=0:return
        current=D(self.state['cash_usdc'])
        if current<spent+extra:
            self.state['halted']=True;self.state['halt_reason']='accounting_inconsistency'
            self.log(kind,'ERROR','insufficient_internal_cash_after_order',details,event_id);return
        entry=spent/qty
        self.state['cash_usdc']=str(current-spent-extra)
        # Preflight reverse quote gives an immediate approximate exit value for PAPER.
        # LIVE fills can differ: require a new live liquidation quote.
        if self.cfg.mode=='PAPER':
            self.exit_values[mint]=max(D(0),D(reverse['outAmount'])/D(1_000_000)*
                                        (1-D(self.cfg.paper_extra_slippage_fraction))-
                                        D(self.cfg.paper_network_cost_usdc))
        else:self.exit_values.pop(mint,None)
        self.state['positions'][mint]={'symbol':m.symbol,'qty':str(qty),'raw_qty':str(token_amount),
                                      'decimals':decimals,'cost_usdc':str(spent+extra),
                                      'entry_price_usd':str(entry),
                                      'peak_price_usd':str(m.price_usd),
                                      'peak_exit_value_usdc':str(self.exit_values.get(mint,spent+extra)),
                                      'partial_take_profit_done':False,
                                      'opened_at':now,
                                      'source':kind,'source_wallet':(details or {}).get('wallet'),
                                      'source_wallet_remaining':(details or {}).get('source_quantity'),
                                      'event_id':event_id}
        trade={'time':stamp(now),'side':'BUY','mint':mint,'symbol':m.symbol,'source':kind,
               'source_wallet':(details or {}).get('wallet'),
               'position_id':f'{mint}:{now}',
               'spent_usdc':str(spent),'qty':str(qty),'paper_network_cost_usdc':str(extra),
               'price_usd_market_reference':str(m.price_usd),'mode':self.cfg.mode,
               'chain_tx_signature':exec_result.get('signature') if self.cfg.mode=='LIVE' else None}
        self.state['trades'].append(trade)
        self.log(kind,'FILLED' if self.cfg.mode=='LIVE' else 'PAPER_FILL','buy',trade,event_id)
        if self.cfg.mode=='LIVE':self.store.intent_status(exec_result['_intent_id'],'APPLIED')

    def _sell(self,mint,reason,event_id=None,fraction=D(1),source_quantity=None):
        now=self.clock();eid=event_id or f'exit:{mint}:{self.state["positions"].get(mint,{}).get("opened_at",0)}'
        if self.store.seen(eid) or mint not in self.state['positions']:return True
        if Path('STOP_TRADING').exists():return False
        # For a protective exit the only essential price is a fresh executable
        # Jupiter quote. Missing DexScreener data must not strand the holding.
        p=self.state['positions'][mint]
        fraction=D(fraction)
        if fraction<=0 or fraction>1:raise ValueError('invalid sale fraction')
        raw_total=int(p['raw_qty']);amount=int(D(raw_total)*fraction)
        if amount<=0:
            self.log('BANKER','REJECT','sale_size_below_raw_token_unit',{'mint':mint})
            return False
        try:
            quote=self.jupiter.order(mint,USDC,amount)
            if int(quote.get('feeBps') or 0)>self.cfg.max_jupiter_fee_bps:
                raise DataUnavailable('exit_quote_fee_exceeds_cap')
            proceeds=D(quote['outAmount'])/D(1_000_000)
            if self.cfg.mode=='LIVE':
                result=self.live.swap('SELL',mint,amount,int(p['decimals']),expected_usdc=proceeds)
                proceeds=D(result['totalOutputAmount'])/D(1_000_000)
                extra=D(0)
            else:
                proceeds=proceeds*(1-D(self.cfg.paper_extra_slippage_fraction))
                extra=D(self.cfg.paper_network_cost_usdc)
            if proceeds<0:raise DataUnavailable('negative sell proceeds')
        except (DataUnavailable,LiveExecutionDisabled,ValueError,TypeError) as exc:
            if self.cfg.mode=='LIVE':
                self.state['halted']=True;self.state['halt_reason']='live_sell_unknown_or_rejected'
            self.log('BANKER','ERROR','exit_not_confirmed',{'mint':mint,'error':str(exc),'reason':reason})
            return False
        sold_fraction=D(amount)/D(raw_total)
        basis=D(p['cost_usdc'])*sold_fraction
        profit=proceeds-extra-basis
        self.state['cash_usdc']=str(D(self.state['cash_usdc'])+proceeds-extra)
        remaining=raw_total-amount
        # A partial exit invalidates the old full-position executable quote.
        self.exit_values.pop(mint,None)
        if remaining==0:
            del self.state['positions'][mint]
        else:
            p['raw_qty']=str(remaining)
            p['qty']=str(D(remaining)/(D(10)**int(p['decimals'])))
            p['cost_usdc']=str(D(p['cost_usdc'])-basis)
            # The reference peak is for the *remaining* position, not the old
            # full quantity. Otherwise a partial sale triggers a false trailing stop.
            p['peak_exit_value_usdc']=str(D(p.get('peak_exit_value_usdc',0))*(1-sold_fraction))
            if source_quantity is not None and p.get('source_wallet_remaining') is not None:
                p['source_wallet_remaining']=str(max(D(0),D(p['source_wallet_remaining'])-D(source_quantity)))
        trade={'time':stamp(now),'side':'SELL','mint':mint,'symbol':p['symbol'],
               'source':p['source'],'source_wallet':p.get('source_wallet'),
               'position_id':f'{mint}:{p["opened_at"]}', 'position_fully_closed':remaining==0,
               'proceeds_usdc':str(proceeds-extra),'realized_pnl_usdc':str(profit),
               'fraction_sold':str(sold_fraction),
               'partial_take_profit_done':bool(p.get('partial_take_profit_done',False)),
               'reason':reason,'mode':self.cfg.mode,
               'chain_tx_signature':result.get('signature') if self.cfg.mode=='LIVE' else None}
        self.state['trades'].append(trade)
        self.log('BANKER','FILLED' if self.cfg.mode=='LIVE' else 'PAPER_FILL',reason,trade,eid)
        if self.cfg.mode=='LIVE':self.store.intent_status(result['_intent_id'],'APPLIED')
        return True

    def _copy_trades(self,now):
        if not self.cfg.trader_wallets:return
        if not self.helius.key:
            raise DataUnavailable('tracked wallets configured but HELIUS_API_KEY missing')
        for wallet in self.cfg.trader_wallets:
            key='wallet_cursor:'+wallet
            checkpoint=self.store.get(key)
            # A single atomic checkpoint distinguishes an empty initial history
            # from a wallet which has *never* been bootstrapped. Older string
            # cursor values remain readable when upgrading an existing database.
            initialized=isinstance(checkpoint,dict) and checkpoint.get('initialized',False)
            cursor=checkpoint.get('signature') if isinstance(checkpoint,dict) else checkpoint
            initialized=initialized or (checkpoint is not None and not isinstance(checkpoint,dict))
            if not initialized:
                # Establish the exact most-recent signature; never duplicate a
                # historical position when a tracked wallet is first enabled.
                if hasattr(self.helius,'latest_signature'):
                    newest=self.helius.latest_signature(wallet)
                else:  # Dependency-injected older test/provider adapters
                    _,newest=self.helius.since(wallet,None)
                self.store.put(key,{'initialized':True,'signature':newest,
                                    'bootstrap_ts':now})
                self.log('COPIER','BOOTSTRAP','skip_historical_trades',{'wallet':wallet})
                continue
            bootstrap_ts=checkpoint.get('bootstrap_ts') if isinstance(checkpoint,dict) else None
            if cursor is None and bootstrap_ts is not None and hasattr(self.helius,'since_bootstrap'):
                txs,newest=self.helius.since_bootstrap(wallet,int(bootstrap_ts))
            else:
                txs,newest=self.helius.since(wallet,cursor)
            events=parse_helius_swaps(txs,wallet,now,self.cfg.max_signal_age_seconds)
            # In the video many wallets sell after 2-4 seconds. Polling every
            # 60s must NOT copy an already reversed trade (buy high, sell low).
            newest_sells={}
            for e in events:
                if e.side=='SELL':
                    newest_sells[e.mint]=max(newest_sells.get(e.mint,-1),e.timestamp)
            for ev in events:
                if self.store.seen(ev.event_id):continue
                # Record confirmed behavior even when an already-reversed BUY
                # is intentionally not copied. This keeps wallet observations
                # faithful instead of making fast flip activity invisible.
                profiles=self.state.setdefault('wallet_profiles',{})
                observe_swap(profiles,wallet,ev.mint,ev.side,ev.timestamp,
                             flipper_seconds=self.cfg.wallet_flipper_seconds)
                if ev.side=='BUY' and newest_sells.get(ev.mint,-1)>=ev.timestamp:
                    self.log('COPIER','SKIP','source_sold_before_copy_cycle',
                             {'wallet':wallet,'mint':ev.mint},ev.event_id)
                    continue
                if ev.side=='BUY':
                    if ev.mint not in self.marks:
                        # Independent feed: no dependency on new-pool discovery.
                        self.marks.update(self.dex.markets([ev.mint],now=now))
                    self._buy(ev.mint,'COPIER',ev.event_id,{'wallet':wallet,'tx':ev.event_id,
                                                            'source_quantity':str(ev.source_qty) if ev.source_qty is not None else None})
                elif ev.mint in self.state['positions'] and self.state['positions'][ev.mint].get('source_wallet')==wallet:
                    p=self.state['positions'][ev.mint]
                    remaining=p.get('source_wallet_remaining')
                    fraction=min(D(1),ev.source_qty/D(remaining)) if (ev.source_qty is not None and remaining is not None and D(remaining)>0) else D(1)
                    if not self._sell(ev.mint,'source_wallet_sell',ev.event_id,fraction,ev.source_qty):
                        # Do not advance the Helius cursor past a failed source
                        # sale. Replay it after the next reconnect; event dedup
                        # makes already completed trades safe to revisit.
                        raise DataUnavailable('source_wallet_sale_not_confirmed_replay_required')
                else:self.log('COPIER','SKIP','sell_without_copied_position',{'wallet':wallet},ev.event_id)
            # Persist cursor only after processing all events. If crash occurs earlier, event dedup works.
            self.store.put(key,{'initialized':True,'signature':newest,'bootstrap_ts':bootstrap_ts})

    def _scout(self,now):
        if not self.cfg.scout_enabled:return
        self.scout_candidates=[]
        eligible=[]
        for mint,m in list(self.marks.items()):
            if mint in self.state['positions']:continue
            score,notes=scout_score(m,now)
            earlier=self.store.earlier(mint,now,120)
            # Momentum is an observation, not an expected-return forecast.
            gain=(m.price_usd/earlier['price']-1) if earlier and earlier['price']>0 else None
            filters=analyst(m,self.cfg,now)+notes
            self.scout_candidates.append({'mint':mint,'symbol':m.symbol,'score':score,
                                          'price_usd':str(m.price_usd),
                                          'liquidity_usd':str(m.liquidity_usd),
                                          'volume_5m_usd':str(m.volume_5m_usd),
                                          'change_5m_pct':str(m.price_change_5m),
                                          'observed_momentum':str(gain) if gain is not None else None,
                                          'filters':filters})
            if (score>=self.cfg.scout_signal_threshold and gain is not None and
                D('0.01')<=gain<=D('0.12')):
                eid=f'scout:{mint}:{now//300}'
                already_bought=any(t['side']=='BUY' and t['source']=='SCOUT' and t['mint']==mint
                                   for t in self.state['trades'])
                if not already_bought and not self.store.seen(eid):
                    eligible.append((score,gain,mint,eid,notes))
            self.store.observe(m,score)
        # The previous implementation bought in arbitrary API response order.
        # Check better scored setups first, subject to exactly the same safety
        # checks, round-trip quote constraints and portfolio limits.
        eligible.sort(key=lambda x:(-x[0],-x[1],x[2]))
        for score,gain,mint,eid,notes in eligible:
            self._buy(mint,'SCOUT',eid,{'score':score,'momentum_since_baseline':str(gain),
                                        'notes':notes})
        self.scout_candidates.sort(key=lambda x:(-x['score'],
                                    -D(x['observed_momentum'] or '-1')))
        self.scout_candidates=self.scout_candidates[:15]

    def _report(self,now,marks=None):
        report=self.store.report(self.state,self.marks if marks is None else marks,now,
                                 liquidations=self.exit_values)
        report['scout_candidates']=self.scout_candidates
        report['session_buy_entries']=sum(t.get('side')=='BUY' for t in self.state['trades'])
        report['session_entry_limit']=self.cfg.max_trades_per_session
        report['strategies']=source_health(self.state['trades'],self.cfg.min_strategy_history,
                                             self.cfg.max_consecutive_strategy_losses,
                                             now=now,cooldown_seconds=self.cfg.strategy_cooldown_seconds)
        report['wallet_fairplay']=wallet_fairplay_summary(self.state.get('wallet_profiles',{}),
                                 self.cfg.min_wallet_roundtrips,self.cfg.max_wallet_quick_sell_fraction)
        report['flattening']=Path('FLATTEN_POSITIONS').exists()
        report['buying_paused']=(Path('PAUSE_BUYS').exists() or self.state['halted'] or
                                 not self.quote_data_ready)
        report['entry_pause_reasons']=list(dict.fromkeys(self.entry_pause_reasons))
        report['scout_paused']=not self.entry_data_ready
        report['quote_data_ready']=self.quote_data_ready
        report['watching_wallets']=len(self.cfg.trader_wallets)
        report['scout_provider']='GeckoTerminal new pools + DexScreener profiles, normalized on DexScreener'
        report['discovery_health']=getattr(self.discoverer,'last_health',{})
        report['execution_provider']='Jupiter V2; '+self.cfg.mode
        report['entry_data_ready']=self.entry_data_ready
        report['consecutive_discovery_failures']=self.failed_ticks
        return report

    def tick(self):
        now=self.clock()
        if Path('STOP_TRADING').exists():
            self.state['halted']=True;self.state['halt_reason']='emergency_stop_file'
            self.store.put('portfolio',self.state)
            return self._report(now)
        # New-entry discovery is optional for managing positions ALREADY held.
        # An outage must NEVER prevent the Jupiter liquidation check, stop-loss,
        # session close or following an existing wallet's SELL signal.
        candidates=[];self.entry_data_ready=False
        self.entry_pause_reasons=[]
        try:
            candidates=self.discoverer.discover(limit=40) if self.cfg.scout_enabled else []
            self.marks=self.dex.markets(list(dict.fromkeys(candidates+list(self.state['positions']))),now=now)
            self.entry_data_ready=True
            self.failed_ticks=0
            self.state['last_market_update']=now
        except DataUnavailable as exc:
            self.failed_ticks+=1
            self.log('SYSTEM','ERROR','market_data_unavailable',{'error':str(exc)})
            # The secondary request is best-effort only: Jupiter can still
            # quote and liquidate a holding after DexScreener has gone down.
            self.marks={}
            if self.state['positions']:
                try:
                    self.marks=self.dex.markets(list(self.state['positions']),now=now)
                except DataUnavailable:
                    pass
            self.entry_pause_reasons.append('discovery_temporarily_unavailable')
            # Transient discovery outages are recoverable. No permanent halt.
        self.scout_candidates=[]
        # With open positions, do not calculate returns from DexScreener mid prices.
        self._refresh_liquidations()
        self.update_risk(now)
        flattening=Path('FLATTEN_POSITIONS').exists()
        if flattening:
            self.state['halted']=True;self.state['halt_reason']='operator_flatten_positions'
        elif now>=self.state['expires_at']:
            self.state['halted']=True;self.state['halt_reason']='session_complete'
        # Exits first: never wait for next scout cycle to take protective action.
        for mint,p in list(self.state['positions'].items()):
            m=self.marks.get(mint)
            if m:
                p['peak_price_usd']=str(max(D(p['peak_price_usd']),m.price_usd))
            net=self.exit_values.get(mint)
            if net is not None:
                p['peak_exit_value_usdc']=str(max(D(p.get('peak_exit_value_usdc',net)),D(net)))
            # Do not use DexScreener mid-prices as executable stop triggers.
            reason=exit_reason(p,m,now,self.cfg,net) if net is not None else None
            prior=self.store.earlier(mint,now,120)
            if m and prior and prior['liquidity']>0 and m.liquidity_usd<prior['liquidity']*(1-D(self.cfg.max_liquidity_drop_fraction)):
                reason='liquidity_collapse'
            if now>=self.state['expires_at']:reason='end_of_session'
            if flattening:reason='operator_flatten_positions'
            if reason:
                self._sell(mint,reason)
            elif net is not None and not p.get('partial_take_profit_done',False):
                # Bank a portion of a winning position based on the *net*
                # liquidation quote. Urgent full exits always take priority.
                cost=D(p['cost_usdc'])
                if cost>0 and D(net)>=cost*(1+D(self.cfg.partial_take_profit_fraction)):
                    eid=f'banker:tp1:{mint}:{p["opened_at"]}'
                    if self._sell(mint,'partial_take_profit',eid,
                                  D(self.cfg.partial_take_profit_sell_fraction)):
                        if mint in self.state['positions']:
                            self.state['positions'][mint]['partial_take_profit_done']=True
        # Continue tracking *sells* from copied wallets even after a buying
        # circuit breaker. A failed sell prevents cursor advancement.
        try:self._copy_trades(now)
        except DataUnavailable as exc:
            # Cursor is NOT advanced on failure; retry on the next cycle.
            # Live uncertain execution can still set the persistent hard halt
            # inside _sell and is never silently cleared here.
            self.entry_pause_reasons.append('wallet_data_temporarily_unavailable')
            self.log('COPIER','ERROR','wallet_data_failure',{'error':str(exc)})
        if not self.state['halted'] and self.entry_data_ready and self.quote_data_ready:
            self._scout(now)
        # If this cycle changed the holdings, requote the new residual balance.
        if any(mint not in self.exit_values for mint in self.state['positions']):
            self._refresh_liquidations()
        self.state['last_checked']=now
        self.store.put('portfolio',self.state)
        return self._report(now)


def write_report(report,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)


def main(argv=None):
    p=argparse.ArgumentParser(description='V14 Scout/Analyst/Copier/Risk/Banker, Solana memecoins')
    p.add_argument('--config',default='config.json');p.add_argument('--db',default='runtime/v14.sqlite')
    p.add_argument('--report',default='docs/status.json');p.add_argument('--once',action='store_true')
    args=p.parse_args(argv)
    cfg=Config.load(args.config)
    try:
        with singleton(args.db+'.lock'):
            store=Store(args.db)
            bot=Bot(cfg,store)
            while True:
                try:
                    report=bot.tick();write_report(report,args.report)
                    print(json.dumps({'mode':report['mode'],'timestamp':report['timestamp_utc'],
                                      'equity_usdc':report['equity_estimate_usdc'],
                                      'pnl_usdc':report['pnl_estimate_usdc'],
                                      'positions':len(report['positions']),
                                      'halted':report['halted'],'reason':report['halt_reason']}),flush=True)
                except (DataUnavailable,LiveExecutionDisabled,ValueError) as exc:
                    print(json.dumps({'status':'FAIL_CLOSED','error':str(exc)}),file=sys.stderr,flush=True)
                    bot.state['halted']=True;bot.state['halt_reason']='unhandled_data_or_execution_error'
                    store.put('portfolio',bot.state)
                if args.once or (bot.state['halt_reason']=='session_complete' and not bot.state['positions']):break
                time.sleep(cfg.poll_seconds)
            store.close()
    except (RuntimeError,ValueError,LiveExecutionDisabled) as exc:
        p.exit(2,f'FAIL_CLOSED: {exc}\n')


if __name__=='__main__': main()
