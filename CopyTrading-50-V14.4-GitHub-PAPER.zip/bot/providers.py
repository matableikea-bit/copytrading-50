"""Live public market data, Helius wallet swaps, Jupiter executable quotes.

No fake source trades. Unknown API fields fail closed; never turn a transfer into a swap.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
import json
import os
import time
from urllib.request import Request, urlopen
from urllib.parse import urlencode, quote
from urllib.error import HTTPError, URLError
from .settings import D

USDC='EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'
SOL='So11111111111111111111111111111111111111112'
TOKEN_PROGRAM='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'


class DataUnavailable(RuntimeError): pass


def request_json(url, *, method='GET', data=None, headers=None, attempts=3, timeout=12):
    if not url.startswith('https://'):
        raise DataUnavailable('HTTPS required')
    body=json.dumps(data,separators=(',',':')).encode() if data is not None else None
    head={'Accept':'application/json','User-Agent':'CopyTrading50-V14/1.0'}
    if body:head['Content-Type']='application/json'
    head.update(headers or {})
    for index in range(attempts):
        try:
            req=Request(url,data=body,headers=head,method=method)
            with urlopen(req,timeout=timeout) as response:
                if response.status!=200: raise DataUnavailable('bad HTTP status')
                content=response.read(2_000_001)
                if len(content)>2_000_000: raise DataUnavailable('response too large')
            return json.loads(content)
        except (HTTPError,URLError,TimeoutError,ValueError,OSError) as exc:
            if isinstance(exc,HTTPError) and 400<=exc.code<500 and exc.code!=429:
                raise DataUnavailable(f'HTTP {exc.code}') from exc
            if index==attempts-1: raise DataUnavailable(f'data fetch failed: {type(exc).__name__}') from exc
            time.sleep(min(6,2**index))
    raise DataUnavailable('request failed')


@dataclass(frozen=True)
class Market:
    mint: str
    symbol: str
    price_usd: Decimal
    liquidity_usd: Decimal
    volume_5m_usd: Decimal
    market_cap_usd: Decimal
    pool_created_at: int
    price_change_5m: Decimal
    buys_5m: int
    sells_5m: int
    pair: str
    observed_at: int
    chain: str = 'solana'


def parse_market(pairs, mint, now):
    if not isinstance(pairs,list): return None
    eligible=[]
    for p in pairs:
        try:
            if p['chainId']!='solana' or p['baseToken']['address']!=mint:continue
            price=D(p['priceUsd']); liq=D(p['liquidity']['usd']); volume=D(p['volume']['m5'])
            cap=D(p.get('marketCap') or p.get('fdv'))
            created=int(p['pairCreatedAt'])//1000
            change=D((p.get('priceChange') or {}).get('m5',0))
            buys=int((p.get('txns') or {}).get('m5',{}).get('buys',0))
            sells=int((p.get('txns') or {}).get('m5',{}).get('sells',0))
            pair=str(p['pairAddress'])
            if min(price,liq,volume,cap)<=0 or created<=0 or created>now or buys<0 or sells<0:
                continue
            eligible.append(Market(mint,str(p['baseToken'].get('symbol','?'))[:24],
                                   price,liq,volume,cap,created,change,buys,sells,pair,now))
        except (KeyError,ValueError,TypeError,OverflowError): continue
    return max(eligible,key=lambda m:m.liquidity_usd) if eligible else None


class DexScreener:
    BASE='https://api.dexscreener.com'
    def __init__(self,fetch=request_json):self.fetch=fetch
    def discover(self,limit=25):
        # NOTE: token-profiles != all pairs. Only publicly published profiles.
        data=self.fetch(self.BASE+'/token-profiles/latest/v1')
        if not isinstance(data,list):raise DataUnavailable('malformed profiles')
        result=[];seen=set()
        for p in data:
            if isinstance(p,dict) and p.get('chainId')=='solana':
                mint=p.get('tokenAddress')
                if isinstance(mint,str) and 32<=len(mint)<=44 and mint not in seen:
                    seen.add(mint);result.append(mint)
            if len(result)>=limit:break
        return result
    def markets(self,mints,now=None):
        now=int(time.time() if now is None else now)
        result={}
        uniq=list(dict.fromkeys(mints))
        for i in range(0,len(uniq),30):
            batch=uniq[i:i+30]
            if not batch:continue
            data=self.fetch(self.BASE+'/tokens/v1/solana/'+','.join(quote(m,safe='') for m in batch))
            if not isinstance(data,list):raise DataUnavailable('invalid token market batch')
            for mint in batch:
                market=parse_market(data,mint,now)
                if market: result[mint]=market
        return result


class GeckoTerminal:
    """Solana newly created pool discovery, separate from sponsored token profiles.

    Discovering a pool is not endorsement. Each returned mint must still pass
    DexScreener normalization, RPC checks and a Jupiter executable round-trip.
    """
    BASE='https://api.geckoterminal.com/api/v2/networks/solana/new_pools'
    def __init__(self,fetch=request_json):self.fetch=fetch

    @staticmethod
    def _mint(link):
        if not isinstance(link,dict):return None
        obj=link.get('data') or {}
        if not isinstance(obj,dict):return None
        ident=obj.get('id')
        if not isinstance(ident,str) or not ident.startswith('solana_'):return None
        mint=ident[len('solana_'):]
        chars='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
        if not 32<=len(mint)<=44 or any(c not in chars for c in mint):return None
        return mint

    def discover(self,limit=25,pages=2,min_pool_liquidity_usd='10000'):
        if not 1<=pages<=5 or not 1<=limit<=100:raise ValueError('discovery bounds invalid')
        result=[];seen=set()
        for page in range(1,pages+1):
            data=self.fetch(self.BASE+'?'+urlencode({'page':page,'include':'base_token,quote_token'}))
            if not isinstance(data,dict) or not isinstance(data.get('data'),list):
                raise DataUnavailable('malformed GeckoTerminal pool response')
            for pool in data['data']:
                if not isinstance(pool,dict):continue
                attrs=pool.get('attributes') or {}
                try:reserve=D(attrs['reserve_in_usd'])
                except (TypeError,KeyError,ValueError):continue
                if reserve<D(min_pool_liquidity_usd):continue
                links=pool.get('relationships') or {}
                if not isinstance(links,dict):continue
                base=self._mint(links.get('base_token'))
                other=self._mint(links.get('quote_token'))
                # A pool can reverse the base/quote ordering, so consider both.
                for mint in (base,other):
                    if mint is None or mint in (SOL,USDC) or mint in seen:continue
                    seen.add(mint);result.append(mint)
                    if len(result)>=limit:return result
            if len(data['data'])<20:break
        return result


class PoolDiscovery:
    """Independent discovery feeds; one failure is survivable, both fail closed."""
    def __init__(self,dex=None,gecko=None):
        self.dex=dex or DexScreener()
        self.gecko=gecko or GeckoTerminal()
        self.last_health={}
    def discover(self,limit=40):
        feeds=(('geckoterminal',self.gecko),('dexscreener',self.dex))
        candidates=[];seen=set();healthy=0;health={}
        for name,source in feeds:
            try:
                mints=source.discover(limit=limit)
                if not isinstance(mints,list):raise DataUnavailable('unexpected discovery payload')
                healthy+=1;health[name]='ok'
                for mint in mints:
                    if mint not in seen:
                        seen.add(mint);candidates.append(mint)
            except (DataUnavailable,ValueError,TypeError) as exc:
                health[name]='error: '+str(exc)[:80]
        self.last_health=health
        if healthy==0:raise DataUnavailable('all independent pool discovery feeds failed')
        return candidates[:limit]


@dataclass(frozen=True)
class WalletSwap:
    event_id: str
    wallet: str
    timestamp: int
    mint: str
    side: str
    source_qty: Decimal | None = None


def parse_helius_swaps(txs,wallet,now,stale_seconds=90,max_sell_age_seconds=86400):
    """Accept only unambiguous Enhanced Transactions swaps involving USDC/SOL.

    Only BUY signals must be very fresh: a delayed source SELL can still reduce an
    existing copied holding after a temporary outage. No historical buys are chased.
    """
    result=[]
    if not isinstance(txs,list):raise DataUnavailable('malformed transaction history')
    for tx in txs:
        if not isinstance(tx,dict):continue
        try:
            # The followed wallet must actually pay/sign for this swap. Mere account
            # involvement is insufficient and can be spoofed by token dusting.
            if tx.get('transactionError') or tx.get('type')!='SWAP' or tx.get('feePayer')!=wallet:continue
            sig=tx['signature'];ts=int(tx['timestamp'])
            if not isinstance(sig,str) or not sig or not -3<=now-ts<=max_sell_age_seconds:continue
            swap=(tx.get('events') or {}).get('swap') or {}
            ins=swap.get('tokenInputs') or [];outs=swap.get('tokenOutputs') or []
            native_in=swap.get('nativeInput') or {}
            native_out=swap.get('nativeOutput') or {}
            if len(ins)==1 and len(outs)==1:
                inm=ins[0].get('mint');outm=outs[0].get('mint')
                if not isinstance(inm,str) or not isinstance(outm,str):continue
                if inm in (USDC,SOL) and outm not in (USDC,SOL):
                    side='BUY';mint=outm
                elif outm in (USDC,SOL) and inm not in (USDC,SOL):
                    side='SELL';mint=inm
                else:continue
            elif len(ins)==0 and len(outs)==1 and D(native_in.get('amount') or 0)>0:
                mint=outs[0].get('mint');side='BUY'
            elif len(ins)==1 and len(outs)==0 and D(native_out.get('amount') or 0)>0:
                mint=ins[0].get('mint');side='SELL'
            else:continue
            if side=='BUY' and now-ts>stale_seconds:continue
            if mint in (USDC,SOL) or not isinstance(mint,str):continue
            if len(mint)<32 or len(mint)>44:continue
            token_change=outs[0] if side=='BUY' else ins[0]
            owner=token_change.get('userAccount')
            if owner is not None and owner!=wallet:continue
            raw=token_change.get('rawTokenAmount') or {}
            source_qty=None
            if raw:
                decimals=int(raw['decimals'])
                if decimals<0 or decimals>18:continue
                source_qty=abs(D(raw['tokenAmount']))/(D(10)**decimals)
                if source_qty<=0:continue
            result.append(WalletSwap(sig+':'+wallet,wallet,ts,mint,side,source_qty))
        except (KeyError,ValueError,TypeError): continue
    return sorted(result,key=lambda x:(x.timestamp,x.event_id))


class Helius:
    BASE='https://api.helius.xyz/v0/addresses/'
    def __init__(self,key=None,fetch=request_json):
        self.key=key if key is not None else os.getenv('HELIUS_API_KEY','')
        self.fetch=fetch
    def page(self,wallet,before=None,limit=100):
        if not self.key:raise DataUnavailable('HELIUS_API_KEY missing')
        params={'api-key':self.key,'limit':min(100,max(1,limit))}
        if before:params['before-signature']=before
        params['type']='SWAP'
        params['token-accounts']='balanceChanged'
        data=self.fetch(self.BASE+quote(wallet,safe='')+'/transactions?'+urlencode(params))
        if not isinstance(data,list):raise DataUnavailable('invalid Helius response')
        return data
    def latest_signature(self,wallet):
        """Bootstrap with one latest signature, without replaying old trades."""
        page=self.page(wallet,limit=1)
        if page:
            signature=page[0].get('signature')
            if not isinstance(signature,str) or not signature:
                raise DataUnavailable('Helius bootstrap signature missing')
            return signature
        return None

    def since_bootstrap(self,wallet,bootstrap_ts,max_pages=5):
        """Catch up from a wallet which had NO swaps at initial subscription.

        Pagination continues until strictly older data is reached. Never treat
        the newest page as a complete history if it could hide more pages.
        An event stamped in the initial bootstrap second is conservatively
        excluded (order within that second is unknowable).
        """
        before=None;collected=[];found_boundary=False
        for _ in range(max_pages):
            page=self.page(wallet,before=before)
            if not page:
                found_boundary=True;break
            for tx in page:
                try:ts=int(tx['timestamp'])
                except (TypeError,ValueError,KeyError) as exc:
                    raise DataUnavailable('timestamp missing in Helius catchup') from exc
                if ts<=bootstrap_ts:
                    found_boundary=True;break
                collected.append(tx)
            if found_boundary or len(page)<100:
                found_boundary=True;break
            last=page[-1].get('signature')
            if not isinstance(last,str) or not last or last==before:
                raise DataUnavailable('Helius pagination stalled on empty baseline')
            before=last
        if not found_boundary:
            raise DataUnavailable('Helius no-cursor catchup exceeded page limit; refuse gaps')
        newest=collected[0].get('signature') if collected else None
        if newest is not None and (not isinstance(newest,str) or not newest):
            raise DataUnavailable('invalid Helius latest signature')
        return list(reversed(collected)),newest

    def since(self,wallet,cursor,max_pages=5):
        """Paginate newest -> older, never silently skip a page; cursor = last seen signature.
        If cursor has fallen outside lookback window, block all new copy trades.
        """
        before=None; collected=[]; found=cursor is None
        for page_num in range(max_pages):
            page=self.page(wallet,before=before)
            if not page:break
            for tx in page:
                if tx.get('signature')==cursor:
                    found=True;break
                collected.append(tx)
            if found or len(page)<100:break
            last=page[-1].get('signature')
            if not last or last==before:raise DataUnavailable('pagination stalled')
            before=last
        if cursor is not None and not found:
            raise DataUnavailable('wallet history gap: cursor not found; fail closed')
        newest=collected[0].get('signature') if collected else cursor
        return list(reversed(collected)),newest


class SolanaRPC:
    def __init__(self,url=None,fetch=request_json):
        self.url=url or os.getenv('SOLANA_RPC_URL','https://api.mainnet-beta.solana.com')
        self.fetch=fetch
    def call(self,method,params):
        data=self.fetch(self.url,method='POST',data={'jsonrpc':'2.0','id':1,'method':method,'params':params})
        if not isinstance(data,dict):
            raise DataUnavailable('malformed Solana RPC response')
        if data.get('error') is not None:
            raise DataUnavailable('Solana RPC error '+str(data.get('error'))[:100])
        if 'result' not in data:
            raise DataUnavailable('Solana RPC missing result')
        return data['result']
    def mint_info(self,mint):
        data=self.call('getAccountInfo',[mint,{'encoding':'jsonParsed','commitment':'confirmed'}])
        value=data.get('value')
        if not value or value.get('owner')!=TOKEN_PROGRAM: raise DataUnavailable('non-standard token program')
        parsed=value['data']['parsed']
        if parsed['type']!='mint':raise DataUnavailable('not a mint')
        info=parsed['info']
        if info.get('mintAuthority') is not None or info.get('freezeAuthority') is not None:
            raise DataUnavailable('mint or freeze authority active')
        decimals=int(info['decimals'])
        if not 0<=decimals<=12:raise DataUnavailable('unexpected decimals')
        return decimals
    def largest_holders(self,mint):
        data=self.call('getTokenLargestAccounts',[mint,{'commitment':'confirmed'}]);rows=data['value']
        supply=D(self.call('getTokenSupply',[mint])['value']['amount'])
        if supply<=0:raise DataUnavailable('zero supply')
        concentration=sum((D(x['amount']) for x in rows[:10]),D(0))/supply
        return concentration
    def token_balance(self,owner,mint):
        result=self.call('getTokenAccountsByOwner',[owner,{'mint':mint},{'encoding':'jsonParsed','commitment':'confirmed'}])
        bal=0;decimals=None
        for row in result.get('value',[]):
            info=row['account']['data']['parsed']['info']['tokenAmount']
            dec=int(info['decimals'])
            if decimals is not None and dec!=decimals: raise DataUnavailable('inconsistent token decimals')
            decimals=dec;bal+=int(info['amount'])
        return bal,decimals
    def sol_balance(self,owner):
        return D(self.call('getBalance',[owner,{'commitment':'confirmed'}])['value'])/D(1_000_000_000)
    def signature_confirmed(self,signature):
        res=self.call('getSignatureStatuses',[[signature],{'searchTransactionHistory':True}])
        data=(res.get('value') or [None])[0]
        return bool(data and data.get('err') is None and
                    data.get('confirmationStatus') in ('confirmed','finalized'))


class Jupiter:
    BASE='https://api.jup.ag/swap/v2/'
    def __init__(self,key=None,fetch=request_json):
        self.key=key if key is not None else os.getenv('JUPITER_API_KEY','')
        self.fetch=fetch
    def _headers(self):return {'x-api-key':self.key} if self.key else {}
    def order(self,input_mint,output_mint,amount,taker=None,slippage_bps=None):
        if not isinstance(amount,int) or amount<=0:raise DataUnavailable('invalid amount')
        params={'inputMint':input_mint,'outputMint':output_mint,'amount':str(amount)}
        if taker:params['taker']=taker
        if slippage_bps is not None:
            if not isinstance(slippage_bps,int) or not 1<=slippage_bps<=500:
                raise DataUnavailable('invalid slippage bound')
            params['slippageBps']=str(slippage_bps)
        data=self.fetch(self.BASE+'order?'+urlencode(params),headers=self._headers())
        if not isinstance(data,dict) or data.get('errorCode') or not data.get('requestId'):
            raise DataUnavailable('Jupiter quote error')
        try:
            output=int(data['outAmount'])
            fee=int(data.get('feeBps') or 0)
        except (KeyError,ValueError,TypeError) as exc:
            raise DataUnavailable('Jupiter quote missing valid output/fee') from exc
        if output<=0 or fee<0:raise DataUnavailable('invalid Jupiter quote')
        if taker and not data.get('transaction'):raise DataUnavailable('Jupiter transaction unavailable')
        return data
    def execute(self,signed_b64,request_id):
        data=self.fetch(self.BASE+'execute',method='POST',
                        data={'signedTransaction':signed_b64,'requestId':request_id},
                        headers=self._headers())
        if not isinstance(data,dict):raise DataUnavailable('Jupiter execution response invalid')
        if data.get('status')!='Success' or data.get('code')!=0 or not data.get('signature'):
            raise DataUnavailable('Jupiter execution not confirmed; reconcile before retry')
        return data
