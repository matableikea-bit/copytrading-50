"""Deterministic SCOUT -> ANALYST -> RISK decisions.

Checks are screening heuristics, NOT proof that a memecoin is safe.
"""
from __future__ import annotations
from decimal import Decimal
from .settings import D, Config
from .providers import Market


def scout_score(m: Market, now: int) -> tuple[int,list[str]]:
    notes=[];score=0
    age=now-m.pool_created_at
    if 600<=age<=86400:score+=15
    else:notes.append('pool_age_not_ideal')
    if m.liquidity_usd>=D('50000'):score+=20
    elif m.liquidity_usd>=D('30000'):score+=12
    else:notes.append('shallow_liquidity')
    if m.volume_5m_usd>=D('10000'):score+=15
    elif m.volume_5m_usd>=D('3000'):score+=8
    else:notes.append('low_volume')
    if m.buys_5m>=12 and m.buys_5m>=m.sells_5m*D('1.5'):score+=15
    elif m.buys_5m>=6 and m.buys_5m>=m.sells_5m:score+=7
    else:notes.append('weak_buy_pressure')
    if D('2')<=m.price_change_5m<=D('12'):score+=20
    elif D('0.5')<=m.price_change_5m<=D('20'):score+=10
    else:notes.append('weak_or_overheated_price')
    if m.market_cap_usd>=D('100000') and m.market_cap_usd<=D('5000000'):score+=15
    elif m.market_cap_usd<=D('20000000'):score+=7
    else:notes.append('extreme_valuation')
    return score,notes


def analyst(m: Market, cfg: Config, now:int) -> list[str]:
    bad=[]
    if m.chain!='solana':bad.append('unsupported_chain')
    if now-m.observed_at>cfg.max_quote_age_seconds or m.observed_at>now+3:
        bad.append('market_data_stale')
    age=now-m.pool_created_at
    if age<cfg.min_pool_age_seconds or age>cfg.max_pool_age_seconds:bad.append('pool_age_rejected')
    if m.liquidity_usd<D(cfg.min_liquidity_usd):bad.append('low_liquidity')
    if m.volume_5m_usd<D(cfg.min_volume_5m_usd):bad.append('low_volume')
    if m.market_cap_usd>D(cfg.max_fdv_usd):bad.append('fdv_too_large')
    if abs(m.price_change_5m)>D(cfg.max_5m_price_jump_percent):bad.append('price_jump')
    if m.buys_5m<5 or m.buys_5m<m.sells_5m:bad.append('weak_demand')
    return bad


def risk_budget(state:dict,cfg:Config,marks:dict[str,Market],liquidations=None) -> tuple[Decimal,str]:
    if state['halted']:return D(0),'circuit_breaker'
    pos=state['positions'];cash=D(state['cash_usdc'])
    if liquidations is not None:
        # A missing executable exit quote must never silently become a zero exposure.
        if any(mint not in liquidations for mint in pos):return D(0),'unknown_liquidation_value'
        if any(mint not in marks for mint in pos):return D(0),'unknown_market_value'
        liquid_equity=sum((D(liquidations[mint]) for mint in pos),D(0))
        # Exposure limits use the larger of indicative mark and liquidation
        # value to avoid undercounting an illiquid or wide-spread holding.
        exposure=sum((max(D(p['qty'])*marks[mint].price_usd,D(liquidations[mint]))
                      for mint,p in pos.items()),D(0))
    else:
        # Kept for deterministic standalone risk tests; runner passes Jupiter valuations.
        if any(mint not in marks for mint in pos):return D(0),'unknown_market_value'
        exposure=sum((D(p['qty'])*marks[mint].price_usd for mint,p in pos.items()),D(0))
    if len(pos)>=cfg.max_open_positions:return D(0),'too_many_positions'
    if sum(t.get('side')=='BUY' for t in state['trades'])>=cfg.max_trades_per_session:return D(0),'session_entry_limit'
    equity=cash+(liquid_equity if liquidations is not None else exposure)
    peak=max(D(state['peak_equity_usdc']),equity)
    if equity<peak*(1-D(cfg.max_drawdown_fraction)):return D(0),'max_drawdown'
    if equity<D(state['day_start_equity_usdc'])*(1-D(cfg.max_daily_loss_fraction)):
        return D(0),'daily_loss_limit'
    budget=min(equity*D(cfg.max_trade_fraction),
               equity*D(cfg.max_single_token_fraction),
               equity*D(cfg.max_total_exposure_fraction)-exposure,
               cash)
    if budget<D(cfg.min_trade_usdc):return D(0),'budget_below_minimum'
    return max(D(0),budget),'pass'


def exit_reason(position:dict,m:Market,now:int,cfg:Config,net_exit_value=None) -> str|None:
    """Stops use Jupiter executable liquidation values when supplied by the runner.

    `net_exit_value` is an *estimate*: execution can slip or fail. A missing
    value never turns into an invented mid-price exit in autonomous mode.
    """
    if net_exit_value is not None:
        value=D(net_exit_value)
        cost=D(position['cost_usdc'])
        high=max(value,D(position.get('peak_exit_value_usdc',cost)))
        if cost<=0:return 'corrupt_entry'
        if value<=cost*(1-D(cfg.stop_loss_fraction)):return 'stop_loss'
        if value>=cost*(1+D(cfg.take_profit_fraction)):return 'take_profit'
        if high>=cost*(1+D(cfg.trailing_activation_fraction)) and value<=high*(1-D(cfg.trailing_gap_fraction)):
            return 'trailing_stop'
    else:
        # Legacy policy for direct independent use; production runner supplies
        # net Jupiter quotes and skips price stops when they are unavailable.
        price=m.price_usd
        entry=D(position['entry_price_usd'])
        peak=max(price,D(position['peak_price_usd']))
        if entry<=0:return 'corrupt_entry'
        if price<=entry*(1-D(cfg.stop_loss_fraction)):return 'stop_loss'
        if price>=entry*(1+D(cfg.take_profit_fraction)):return 'take_profit'
        if peak>=entry*(1+D(cfg.trailing_activation_fraction)) and price<=peak*(1-D(cfg.trailing_gap_fraction)):
            return 'trailing_stop'
    if now-int(position['opened_at'])>=cfg.max_hold_minutes*60:return 'time_stop'
    return None
