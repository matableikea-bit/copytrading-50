"""Opt-in Jupiter LIVE venue. Never load wallet secret from checked-in files.

Two-phase order journal: ambiguous network outcomes stop trading until reconciled.
The bot only signs Jupiter-returned transactions; use a dedicated low-balance wallet.
"""
from __future__ import annotations
import base64
import os
from pathlib import Path
import time
from .providers import Jupiter, SolanaRPC, USDC,DataUnavailable
from .settings import D


class LiveExecutionDisabled(RuntimeError):pass


class JupiterLive:
    def __init__(self,cfg,store,jupiter=None,rpc=None):
        if cfg.mode!='LIVE':raise LiveExecutionDisabled('PAPER configuration')
        if os.getenv('ENABLE_LIVE_TRADING')!='I_ACCEPT_THE_RISK_OF_LOSS':
            raise LiveExecutionDisabled('ENABLE_LIVE_TRADING gate absent')
        if os.getenv('LIVE_TRADING_CONFIRMATION')!='MY_FUNDS_CAN_BE_LOST':
            raise LiveExecutionDisabled('second live gate absent')
        if Path('STOP_TRADING').exists():raise LiveExecutionDisabled('emergency STOP_TRADING file exists')
        secret=os.getenv('SOLANA_PRIVATE_KEY_BASE58','')
        if not secret:raise LiveExecutionDisabled('missing wallet key (provide locally only)')
        try:
            from solders.keypair import Keypair
            self.keypair=Keypair.from_base58_string(secret)
        except ImportError as exc:raise LiveExecutionDisabled('pip install -r requirements-live.txt') from exc
        self.wallet=str(self.keypair.pubkey());self.cfg=cfg;self.store=store
        self.jupiter=jupiter or Jupiter();self.rpc=rpc or SolanaRPC()
        self.check_ready()

    def check_ready(self):
        if Path('STOP_TRADING').exists():raise LiveExecutionDisabled('kill switch active')
        if self.store.unresolved():raise LiveExecutionDisabled('unresolved order intent: manual reconciliation required')
        if self.rpc.sol_balance(self.wallet)<D(self.cfg.reserve_sol):
            raise LiveExecutionDisabled('insufficient SOL gas reserve')

    def swap(self,side,mint,input_amount,decimals,expected_usdc=None,expected_out_units=None):
        self.check_ready()
        if mint not in self.cfg.live_mint_allowlist:
            raise LiveExecutionDisabled('mint not explicitly allowlisted')
        if not isinstance(input_amount,int) or input_amount<=0:raise ValueError('invalid amount')
        input_mint=USDC if side=='BUY' else mint
        output_mint=mint if side=='BUY' else USDC
        available,actual_dec=self.rpc.token_balance(self.wallet,input_mint)
        if available<input_amount:raise LiveExecutionDisabled('on-chain balance insufficient')
        if actual_dec is not None and actual_dec!=(6 if side=='BUY' else decimals):
            raise LiveExecutionDisabled('on-chain decimal mismatch')
        # At most one in-flight order; fail closed after any unknown outcome.
        ident=f'jup:{int(time.time()*1_000_000)}:{side}:{mint}'
        self.store.prepare_intent(ident,side,mint,input_amount,int(time.time()))
        try:
            order=self.jupiter.order(input_mint,output_mint,input_amount,taker=self.wallet,
                                     slippage_bps=self.cfg.max_execution_slippage_bps)
            if int(order.get('feeBps') or 0)>self.cfg.max_jupiter_fee_bps:
                self.store.intent_status(ident,'CANCELLED',result={'reason':'fee_cap'})
                raise LiveExecutionDisabled('Jupiter fee cap exceeded')
            if expected_out_units is not None and side=='BUY':
                if int(order['outAmount']) < D(expected_out_units)*(1-D(self.cfg.max_requote_deterioration_fraction)):
                    self.store.intent_status(ident,'CANCELLED',result={'reason':'buy_price_moved'})
                    raise LiveExecutionDisabled('Buy price deteriorated since preflight')
            if expected_usdc is not None and side=='SELL':
                actual=D(order['outAmount'])/D(1_000_000)
                if actual < D(expected_usdc)*(1-D(self.cfg.max_requote_deterioration_fraction)):
                    self.store.intent_status(ident,'CANCELLED',result={'reason':'price_moved'})
                    raise LiveExecutionDisabled('Sell requote deteriorated; review position')
            from solders.transaction import VersionedTransaction
            tx=VersionedTransaction.from_bytes(base64.b64decode(order['transaction']))
            # A dedicated wallet must be the only required signer.  Refuse
            # unexpected multisignature/fee-payer requests rather than sign
            # a transaction with unfamiliar required keys.
            if tx.message.header.num_required_signatures!=1 or str(tx.message.account_keys[0])!=self.wallet:
                self.store.intent_status(ident,'CANCELLED',result={'reason':'unexpected_signer'})
                raise LiveExecutionDisabled('Unexpected transaction signer; refusal to sign')
            # Solders signs the compiled message and reconstructs transaction.
            signed=VersionedTransaction(tx.message,[self.keypair])
            encoded=base64.b64encode(bytes(signed)).decode()
        except LiveExecutionDisabled:
            raise
        except Exception as exc:
            # If the prepared transaction never reached submission it can be cancelled.
            self.store.intent_status(ident,'CANCELLED',result={'error':type(exc).__name__})
            raise LiveExecutionDisabled('could not prepare/safely sign swap') from exc
        self.store.intent_status(ident,'SUBMITTING')
        try:
            result=self.jupiter.execute(encoded,order['requestId'])
            if not self.rpc.signature_confirmed(result['signature']):
                raise LiveExecutionDisabled('RPC has not independently confirmed transaction')
            self.store.intent_status(ident,'CONFIRMED_PENDING_ACCOUNTING',signature=result['signature'],result=result)
            return {**result, '_intent_id':ident}
        except Exception as exc:
            self.store.intent_status(ident,'UNKNOWN',result={'error':type(exc).__name__})
            raise LiveExecutionDisabled('UNKNOWN execution status; STOP. Reconcile chain before another order.') from exc
