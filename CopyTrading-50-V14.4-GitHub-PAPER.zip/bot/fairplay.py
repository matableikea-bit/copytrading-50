"""Observational flags for wallets that rapidly sell their own purchases.

These flags are descriptive; they do not establish manipulation, trading skill,
or a profitable source.  Only confirmed observations received AFTER subscription
contribute to a wallet score.  Never promote the flags as a vetted leaderboard.
"""
from __future__ import annotations
from .settings import D


def observe_swap(profiles: dict, wallet: str, mint: str, side: str, timestamp: int,
                 *, flipper_seconds: int = 180, max_age_seconds: int = 86400):
    """Mutate a serializable profile after a decoded on-chain swap."""
    profile=profiles.setdefault(wallet, {'swaps_seen':0, 'completed_roundtrips':0,
                                         'quick_sells':0, 'last_buy':{}, 'last_seen':0})
    timestamp=int(timestamp)
    # Ignore duplicates/reordered observations at the same timestamp for a mint/side
    # only if callers have already de-duplicated signature ids (see runner).
    profile['swaps_seen']+=1
    profile['last_seen']=max(int(profile.get('last_seen',0)),timestamp)
    last=profile.setdefault('last_buy',{})
    if side=='BUY':
        # First purchase defines the local holding-time observation.
        last.setdefault(mint,timestamp)
    elif side=='SELL':
        opened=last.pop(mint,None)
        if opened is not None and 0<=timestamp-opened<=max_age_seconds:
            profile['completed_roundtrips']+=1
            if timestamp-opened<flipper_seconds:
                profile['quick_sells']+=1
    # Bound memory; mints that never sell should not grow state forever.
    cutoff=timestamp-max_age_seconds
    profile['last_buy']={k:v for k,v in last.items() if int(v)>=cutoff}
    if len(profile['last_buy'])>200:
        keep=sorted(profile['last_buy'].items(), key=lambda pair:pair[1],reverse=True)[:200]
        profile['last_buy']=dict(keep)
    return profile


def wallet_gate(profiles:dict,wallet:str,*,minimum_roundtrips:int=3,
                max_quick_sell_fraction='0.67'):
    """Conservatively block repeat fast flipping; never infer insider fraud."""
    p=profiles.get(wallet) or {}
    count=int(p.get('completed_roundtrips',0))
    if count<minimum_roundtrips:return True,'not_enough_observations'
    fraction=D(p.get('quick_sells',0))/D(count)
    if fraction>=D(max_quick_sell_fraction):return False,'observed_rapid_resales'
    return True,'behavior_gate_passed_not_proof_of_profit'


def summary(profiles:dict,minimum_roundtrips=3,max_quick_sell_fraction='0.67'):
    result=[]
    for wallet,p in sorted(profiles.items()):
        enabled,reason=wallet_gate(profiles,wallet,
                                   minimum_roundtrips=minimum_roundtrips,
                                   max_quick_sell_fraction=max_quick_sell_fraction)
        n=int(p.get('completed_roundtrips',0))
        result.append({'wallet':wallet,'swaps_observed':int(p.get('swaps_seen',0)),
                       'completed_roundtrips_observed':n,
                       'quick_sells_observed':int(p.get('quick_sells',0)),
                       'buy_signals_enabled':enabled,'reason':reason,
                       'note':'Behavior after subscription only; not a profitability ranking'})
    return result
