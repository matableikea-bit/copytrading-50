"""Audit net outcomes by source; apply a *defensive* kill gate.

This never promotes past profitability to a claim of future profitability.
Past winning streaks do not loosen position size or risk limits.
"""
from __future__ import annotations
from .settings import D
from datetime import datetime


def completed_positions(trades):
    """One result per fully closed position, including all partial sells."""
    pnl={}
    finalized=set()
    chronology=[]
    for trade in trades:
        if trade.get('side')!='SELL':continue
        pid=trade.get('position_id') or trade.get('mint')
        if not pid:continue
        item=pnl.setdefault(pid,{'source':trade.get('source','UNKNOWN'),
                                   'wallet':trade.get('source_wallet'),
                                   'pnl':D(0)})
        item['pnl']+=D(trade.get('realized_pnl_usdc') or 0)
        if trade.get('position_fully_closed',True) and pid not in finalized:
            finalized.add(pid)
            item['closed_at']=trade.get('time')
            chronology.append(pid)
    return [pnl[pid] for pid in chronology]


def _most_recent_close_time(trades, source, wallet):
    # Closures, not partial exits, start the suspension window.
    for trade in reversed(trades):
        if (trade.get('side')!='SELL' or
            not trade.get('position_fully_closed',True) or
            trade.get('source','UNKNOWN')!=source or
            (source=='COPIER' and trade.get('source_wallet')!=wallet)):
            continue
        try:
            return int(datetime.fromisoformat(trade['time'].replace('Z','+00:00')).timestamp())
        except (KeyError,TypeError,ValueError,OverflowError):
            return None
    return None


def source_gate(trades, source, wallet, min_history=5, max_consecutive_losses=3,
                *, now=None, cooldown_seconds=1800):
    """Temporary, source-specific cooldown following observed net losses.

    This does NOT assert negative past PnL predicts future losses. A pause is
    allowed to expire; subsequent candidate trades may be simulated again.
    All loss calculations use COMPLETELY CLOSED positions after paper costs.
    """
    history=[t['pnl'] for t in completed_positions(trades)
             if t['source']==source and (source!='COPIER' or t['wallet']==wallet)]
    if len(history)<min_history:return True,'insufficient_sample'
    window=history[-min_history:]
    reason=None
    if len(window)>=max_consecutive_losses and all(x<0 for x in window[-max_consecutive_losses:]):
        reason='consecutive_losses_strategy_cooldown'
    elif sum(window,D(0))<0:
        reason='negative_net_strategy_cooldown'
    if reason is None:return True,'historical_gate_passed_not_profit_guarantee'
    if now is not None:
        close_time=_most_recent_close_time(trades,source,wallet)
        if close_time is not None and now>=close_time+cooldown_seconds:
            return True,'strategy_cooldown_elapsed_retest_allowed'
    return False,reason


def source_health(trades, min_history=5, max_consecutive_losses=3,
                  *, now=None, cooldown_seconds=1800):
    positions=completed_positions(trades)
    names={(p['source'],p['wallet'] if p['source']=='COPIER' else None)
           for p in positions}
    result=[]
    for source,wallet in sorted(names,key=lambda x:(x[0],x[1] or '')):
        history=[p['pnl'] for p in positions if p['source']==source and
                 (source!='COPIER' or p['wallet']==wallet)]
        enabled,reason=source_gate(trades,source,wallet,min_history,max_consecutive_losses,
                                   now=now,cooldown_seconds=cooldown_seconds)
        result.append({'source':source,'wallet':wallet,'closed_positions':len(history),
                       'realized_net_usdc':str(sum(history,D(0))),
                       'latest_window_net_usdc':str(sum(history[-min_history:],D(0))),
                       'buys_enabled':enabled,'reason':reason,
                       'note':'No proof of future profitability'})
    return result
