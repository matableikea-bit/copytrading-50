"""Secondary read-only market context. No automatic cross-chain trade routing."""
from __future__ import annotations
import time
from .providers import request_json,DataUnavailable
from .settings import D


def monitor_cex(fetch=request_json):
    out={}
    urls={
      'Kraken BTC/EUR':'https://api.kraken.com/0/public/Ticker?pair=XBTEUR',
      'Coinbase BTC/EUR':'https://api.coinbase.com/v2/prices/BTC-EUR/spot',
      'Binance BTC/EUR':'https://api.binance.com/api/v3/ticker/price?symbol=BTCEUR'
    }
    for market,url in urls.items():
        try:
            data=fetch(url)
            if market.startswith('Kraken'):
                if data.get('error'):raise ValueError('Kraken API error')
                price=D(next(iter(data['result'].values()))['c'][0])
            elif market.startswith('Coinbase'):price=D(data['data']['amount'])
            else:price=D(data['price'])
            if price<=0:raise ValueError('invalid price')
            out[market]={'price_eur':str(price),'status':'OK'}
        except (DataUnavailable,ValueError,KeyError,TypeError,StopIteration) as exc:
            out[market]={'status':'UNAVAILABLE','error':type(exc).__name__}
    return {'observed_at':int(time.time()),'market_type':'READ_ONLY','venues':out}


def monitor_base(mints,fetch=request_json):
    """Only report explicitly configured Base contract addresses; no invented signals."""
    if not mints:return {'mode':'READ_ONLY','tokens':[]}
    if len(mints)>30:raise ValueError('max 30 base tokens')
    from urllib.parse import quote
    data=fetch('https://api.dexscreener.com/tokens/v1/base/'+','.join(quote(m,safe='') for m in mints))
    if not isinstance(data,list):raise DataUnavailable('Base prices unavailable')
    out=[]
    for mint in mints:
        pairs=[p for p in data if p.get('chainId')=='base' and p.get('baseToken',{}).get('address','').lower()==mint.lower()]
        if not pairs:out.append({'address':mint,'status':'UNAVAILABLE'});continue
        p=max(pairs,key=lambda p:D((p.get('liquidity') or {}).get('usd') or 0))
        out.append({'address':mint,'price_usd':p.get('priceUsd'),'symbol':p['baseToken'].get('symbol'),
                    'liquidity_usd':(p.get('liquidity') or {}).get('usd'),'status':'OK'})
    return {'mode':'READ_ONLY','tokens':out}


def main(argv=None):
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser();p.add_argument('--out',default='docs/other-markets.json')
    args=p.parse_args(argv)
    out=monitor_cex()
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
