# Lancer CopyTrading 50 V14.4 dans GitHub Actions (PAPER)

## Méthode A — la plus simple si le dépôt contient encore V12 : UN SEUL FICHIER YAML

Un workflow **autonome** `Copier-Dans-GitHub-V14.4-AUTONOME.yml` est fourni séparément. Il embarque la version source dans une archive encodée, vérifie les tests, puis lance les étapes de simulation. **Ce n'est pas la version conseillée pour les futures modifications de code** : le ZIP du projet, avec le code lisible, est préférable pour maintenir le logiciel.

1. Ouvrir **ton dépôt GitHub** et aller dans **Add file → Create new file**.
2. Nommer le fichier exactement `.github/workflows/copytrading-paper-autonome.yml`.
3. Coller le **contenu** du fichier `Copier-Dans-GitHub-V14.4-AUTONOME.yml` (pas le ZIP lui-même) puis **Commit changes** sur la branche par défaut.
4. Aller dans **Actions → CopyTrading 50 V14.4 AUTONOME → Run workflow**.
5. Choisir `2min` pour un essai, puis `10h` ou `12h`. Démarrer avec le bouton vert.
6. Pendant la simulation, ouvrir le job `Étape 1`, `Étape 2`, puis `Étape 3` pour suivre les relevés. À la fin, télécharger l'artifact `checkpoint-stage-3-final` (`checkpoint-stage-1` pour `2min`). Ouvrir `docs/resultats.html` pour voir les résultats hors ligne.

**Ne pas copier les deux workflows** dans le même dépôt, sinon tu auras deux boutons Actions presque identiques.

## Méthode B — version propre et maintenable (tout le code dans le dépôt)

Décompresser `CopyTrading-50-V14.4-GitHub-PAPER.zip`, puis placer **le contenu à la racine du dépôt** : `.github/workflows/copytrading-paper.yml`, `bot/`, `tests/`, `config.json`, `docs/`, `examples/`, etc.

Exemple en utilisant Git sur un ordinateur :

```bash
git clone https://github.com/OWNER/REPO.git
cd REPO
# Copier ici le CONTENU décompressé de CopyTrading-50-V14.4-GitHub-PAPER.zip
git add .github/workflows/copytrading-paper.yml bot tests config.json docs examples GITHUB_INSTALL.md README.md
# Ajouter aussi les autres fichiers utiles si souhaité
git commit -m "Add V14.4 GitHub PAPER simulation"
git push
```

Ensuite **Actions → CopyTrading 50 V14.4 — Simulation 2min / 10h / 12h → Run workflow**.

## Durée et continuité

GitHub limite un job hébergé à six heures. Pour 10 h et 12 h, ce workflow utilise **trois jobs successifs** (3 h 20 × 3 ou 4 h × 3). La base SQLite est transmise entre les jobs via `actions/upload-artifact@v4` et `actions/download-artifact@v4`. Les changements de machine créent de **courtes interruptions** ; il ne s'agit donc pas d'un serveur à faible latence.

Les résultats sont disponibles en direct **dans les logs Actions**, puis dans les artifacts **en fin de chaque job**. **Il n'y a pas de publication GitHub Pages en temps réel** dans cette version.

Une session `2min` valide le démarrage et les appels API, mais la logique de SCOUT demande au moins deux observations espacées de 120 secondes ; il est normal qu'elle ne passe pas d'ordre pendant ce test rapide.

La GitHub Action n'envoie **aucun ordre réel**. Elle refuse toute configuration `LIVE`. L'argent du compte Kraken n'est jamais utilisé. Le capital initial est **50 USDC simulés**, pas 50 EUR et pas un dépôt réel.

## Activer la copie de wallets (facultatif)

Pour obtenir des signaux COPIER, il faut les **véritables adresses Solana** des traders suivis, pas leurs pseudonymes. Dans le dépôt GitHub :

- **Settings → Secrets and variables → Actions → Secrets** : créer `HELIUS_API_KEY` (facultatif si tu ne copies pas de wallets) et, si disponible, `JUPITER_API_KEY`.
- **Settings → Secrets and variables → Actions → Variables** : créer `SIM_WALLETS_JSON`, avec par exemple `[]` au départ ou une liste JSON de vraies adresses Solana vérifiées indépendamment.

**Ne mets jamais dans GitHub Actions une clé privée ou une seed phrase pour cette simulation.** Aucune clé de Kraken n'est nécessaire.

## Les fichiers récupérables dans l'artifact

- `docs/resultats.html` — tableau de bord consultable directement dans un navigateur après extraction de l'artifact.
- `docs/status.json` — portefeuille et décisions du dernier cycle.
- `docs/performance.json` — performance réalisée et autres indicateurs calculés.
- `docs/trades.csv` — opérations simulées, sans gains inventés.
- `runtime/github-session.sqlite` — base SQLite reprise entre étapes, utile pour audit et reprise manuelle.

Les résultats peuvent être nuls ou négatifs. Les fournisseurs de données peuvent limiter/mettre en erreur les appels depuis GitHub Actions. Un rapport avec `equity_estimate_usdc: null` signifie que le bot ne dispose pas d'une valorisation de liquidation fiable — **ce n'est pas zéro euro de gain ni la preuve d'une position perdue**.

## Coût et contraintes

Des sessions GitHub Actions de 10/12 h consomment des minutes de runner (facturation/quotas selon le forfait, le type et la visibilité du dépôt). L'archive de résultats utilise aussi du stockage GitHub. Les clés API publiques peuvent exiger des quotas ou des abonnements. Vérifier les limites de son compte avant de lancer des sessions répétées.

Le code et les tests sont vérifiés **localement**, mais ce workflow n'a pas encore été exécuté sur ton dépôt GitHub et ses accès aux API ne sont pas validés en production.
