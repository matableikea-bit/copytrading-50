#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
exec python3 -m bot --config examples/config-10h.json --db runtime/session-10h.sqlite --report docs/status.json
