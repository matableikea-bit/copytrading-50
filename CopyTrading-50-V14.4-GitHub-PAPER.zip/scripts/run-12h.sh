#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
exec python3 -m bot --config config.json --db runtime/v14.sqlite --report docs/status.json
