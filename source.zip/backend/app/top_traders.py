"""Auditable leaderboard. Never claim that historical leaders will win next.

Only DEMO_FIXTURE historical trades are used for synthetic demonstrations;
USER_SUPPLIED_UNVERIFIED records are displayed as provisional, not real-time proof.
This module contains no broker connectivity.
"""
import csv
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from sqlalchemy import select
from .models import TraderHistory
from .engine import D

# Synthetic completed trades dating back well before the demo simulation.
DEMO_PROFILES = {
    'atlas_demo': ('Atlas (fictif)', ['2.1','-0.9','1.7','1.1','-1.5','2.5','0.8','1.2','-0.4','1.6','0.7','1.3']),
    'nova_demo': ('Nova (fictif)', ['6.2','-5.4','4.1','-4.7','7.0','-3.5','5.3','-6.0','4.1','-2.0','6.0','-1.8']),
    'zen_demo': ('Zen (fictif)', ['0.4','0.2','-0.1','0.5','0.4','0.3','0.2','-0.2','0.3','0.5','0.3','0.2']),
}


def seed_demo_history(db, experiment_id, *, started_at=None):
    """Create fictional historical trades; they predate demo start, never backfill PnL."""
    reference=(started_at or datetime.now(timezone.utc))
    if reference.tzinfo is None: reference=reference.replace(tzinfo=timezone.utc)
    n=0
    for tid,(name,returns) in DEMO_PROFILES.items():
        for i,pct in enumerate(returns):
            trade_id=f'fixture-{i:02d}'
            existing=db.scalars(select(TraderHistory).where(TraderHistory.experiment_id==experiment_id, TraderHistory.trader_id==tid, TraderHistory.trade_id==trade_id)).first()
            if existing: continue
            db.add(TraderHistory(experiment_id=experiment_id,trader_id=tid,display_name=name,trade_id=trade_id,
                return_pct=D(pct),closed_at=reference-timedelta(days=120-i*8),
                proof_url=None,provenance='DEMO_FIXTURE'))
            n+=1
    db.commit()
    return n


def import_history_csv(db, experiment_id, path, *, as_of=None):
    """Manually supplied records, ALWAYS labelled unverified; never treated as authoritative.
    CSV: trader_id,display_name,trade_id,return_pct,closed_at,proof_url
    """
    path=Path(path)
    if not path.is_file(): raise ValueError('Fichier historique absent')
    now=as_of or datetime.now(timezone.utc)
    n=0
    with path.open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if len(rows)>10000: raise ValueError('Fichier trop volumineux')
    for row in rows:
        if not all(row.get(k) for k in ('trader_id','display_name','trade_id','return_pct','closed_at')):
            raise ValueError('Colonnes de suivi incomplètes')
        tid=row['trader_id'].strip()[:80]
        track=row['trade_id'].strip()[:150]
        if not tid or not track: raise ValueError('Identifiant vide')
        closed=datetime.fromisoformat(row['closed_at'].replace('Z','+00:00'))
        if closed.tzinfo is None: raise ValueError('Horodatage UTC ou avec offset obligatoire')
        if closed>now: raise ValueError('Historique futur interdit')
        pct=D(row['return_pct'])
        if not pct.is_finite() or not D('-100')<=pct<=D('1000'):
            raise ValueError('Rendement invalide')
        old=db.scalars(select(TraderHistory).where(TraderHistory.experiment_id==experiment_id,TraderHistory.trader_id==tid,TraderHistory.trade_id==track)).first()
        if old: continue
        db.add(TraderHistory(experiment_id=experiment_id,trader_id=tid,display_name=row['display_name'].strip()[:100],trade_id=track,
            return_pct=pct,closed_at=closed,proof_url=row.get('proof_url','')[:1000],provenance='USER_SUPPLIED_UNVERIFIED'))
        n+=1
    db.commit()
    return n


def ranked_traders(db, experiment_id, *, as_of=None, min_closed=10, min_days=30):
    """Metrics use only trades CLOSED strictly before as_of. Returns never predict next trade."""
    now=as_of or datetime.now(timezone.utc)
    if now.tzinfo is None: now=now.replace(tzinfo=timezone.utc)
    tracks=defaultdict(list)
    for t in db.scalars(select(TraderHistory).where(TraderHistory.experiment_id==experiment_id)).all():
        closed=t.closed_at.replace(tzinfo=timezone.utc) if t.closed_at.tzinfo is None else t.closed_at.astimezone(timezone.utc)
        if closed<=now: tracks[t.trader_id].append((closed,t))
    result=[]
    for tid, trades in tracks.items():
        trades.sort(key=lambda r:(r[0],r[1].trade_id))
        returns=[D(t.return_pct) for _,t in trades]
        winners=sum(r>0 for r in returns)
        age=(trades[-1][0]-trades[0][0]).days
        equity=Decimal('1'); peak=Decimal('1'); max_dd=Decimal('0')
        for r in returns:
            equity*=Decimal('1')+r/100
            peak=max(peak,equity)
            if peak>0: max_dd=max(max_dd,(peak-equity)/peak*100)
        eligible=len(trades)>=min_closed and age>=min_days and max_dd<=D('35')
        # Bounded scoring; high historic return cannot fully hide severe drawdowns.
        total_pct=(equity-1)*100
        score=max(D('-100'),min(D('100'),total_pct))-max_dd*D('1.5') + D(winners)/len(trades)*D('10')
        provenances={t.provenance for _,t in trades}
        provenance='DEMO_FIXTURE' if provenances=={'DEMO_FIXTURE'} else 'USER_SUPPLIED_UNVERIFIED'
        result.append({'trader_id':tid,'display_name':trades[-1][1].display_name,'closed_trades':len(trades),
            'history_days':age,'win_rate_pct':round(winners*100/len(trades),2),
            'historical_return_pct':str(total_pct.quantize(D('0.01'))),
            'max_drawdown_pct':str(max_dd.quantize(D('0.01'))),
            'score':str(score.quantize(D('0.01'))),'eligible':bool(eligible),
            'provenance':provenance,'verification':'FICTIF' if provenance=='DEMO_FIXTURE' else 'NON_VÉRIFIÉ',
            'copy_available':False})
    result.sort(key=lambda x:(x['eligible'],D(x['score'])),reverse=True)
    return result
