"""Optional indicative close-price integration (educational, delayed prices).
Use with caution: no intraday execution realism, HTTP availability not guaranteed.
"""
import csv
import io
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
import httpx
from sqlalchemy import select
from .models import Quote
from .engine import quote_upsert


def fetch_stooq_us_eod_eur(symbol: str):
    """Last US closing price from Stooq and ECB EUR/USD rate; indicative only.
    Raises if source is blocked, stale or unavailable. Should not represent real fill.
    """
    if not symbol.isascii() or not symbol.replace('.','').isalpha() or len(symbol)>10:
        raise ValueError('Symbole US non pris en charge')
    ticker=symbol.lower()
    if not ticker.endswith('.us'):
        ticker += '.us'
    r=httpx.get('https://stooq.com/q/d/l/',params={'s':ticker,'i':'d','d1':(date.today()-timedelta(days=8)).strftime('%Y%m%d')},timeout=15)
    r.raise_for_status()
    rows=list(csv.DictReader(io.StringIO(r.text)))
    if not rows or not all('Close' in row and 'Date' in row for row in rows):
        raise ValueError('Cotation Stooq inaccessible / limite de requêtes')
    row=max(rows,key=lambda r:r['Date'])
    price=Decimal(row['Close'])
    quoted_date=date.fromisoformat(row['Date'])
    if (date.today()-quoted_date).days>4:
        raise ValueError('Dernier prix journalier trop ancien')
    # Official ECB XML reference rates, USD quoted per EUR.
    x=httpx.get('https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml',timeout=15)
    x.raise_for_status()
    import xml.etree.ElementTree as ET
    root=ET.fromstring(x.text)
    usd=[]
    for element in root.iter():
        if element.attrib.get('currency')=='USD':
            usd.append(Decimal(element.attrib['rate']))
    if not usd or usd[0]<=0 or price<=0:
        raise ValueError('Taux ECB / cotation invalides')
    return price/usd[0], quoted_date


def refresh_us_stock(db, experiment_id, symbol):
    price, market_date=fetch_stooq_us_eod_eur(symbol)
    q=quote_upsert(db,experiment_id,symbol.upper(),price,source='Stooq EOD + ECB FX',quality='INDICATIVE_DELAYED_CLOSE')
    # Quote's timestamp is the data's actual day, not ingestion time.
    q.quoted_at=datetime.combine(market_date,datetime.min.time(),tzinfo=timezone.utc)+timedelta(hours=21)
    db.commit()
    return q
