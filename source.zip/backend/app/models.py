"""Paper-only data model. Decimal NUMERIC columns are canonical, never binary floats."""
from datetime import datetime, timezone
from sqlalchemy import String, ForeignKey, DateTime, Numeric, Integer, Text, UniqueConstraint, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def utcnow():
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Experiment(Base):
    __tablename__ = 'experiments'
    id: Mapped[int] = mapped_column(primary_key=True)
    mode: Mapped[str] = mapped_column(String(30), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default='RUNNING')
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Portfolio(Base):
    __tablename__ = 'portfolios'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'), index=True)
    slug: Mapped[str] = mapped_column(String(30))
    label: Mapped[str] = mapped_column(String(80))
    initial_eur: Mapped[object] = mapped_column(Numeric(20, 8), default=10)
    cash_eur: Mapped[object] = mapped_column(Numeric(20, 8), default=10)
    __table_args__ = (UniqueConstraint('experiment_id', 'slug'),)


class Position(Base):
    __tablename__ = 'positions'
    id: Mapped[int] = mapped_column(primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey('portfolios.id'), index=True)
    symbol: Mapped[str] = mapped_column(String(100))
    quantity: Mapped[object] = mapped_column(Numeric(24, 10), default=0)
    cost_eur: Mapped[object] = mapped_column(Numeric(20, 8), default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint('portfolio_id', 'symbol'),)


class Quote(Base):
    __tablename__ = 'quotes'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'), index=True)
    symbol: Mapped[str] = mapped_column(String(100))
    price_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    source: Mapped[str] = mapped_column(String(80))
    quality: Mapped[str] = mapped_column(String(60), default='DEMO_FIXTURE')
    quoted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint('experiment_id', 'symbol'),)


class Signal(Base):
    __tablename__ = 'signals'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'), index=True)
    strategy: Mapped[str] = mapped_column(String(30))
    external_id: Mapped[str] = mapped_column(String(300))
    symbol: Mapped[str] = mapped_column(String(100))
    action: Mapped[str] = mapped_column(String(10))
    source: Mapped[str] = mapped_column(String(150))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    raw_json: Mapped[str] = mapped_column(Text, default='{}')
    reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default='RECEIVED')
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    __table_args__ = (UniqueConstraint('experiment_id', 'strategy', 'external_id'),)


class Order(Base):
    __tablename__ = 'orders'
    id: Mapped[int] = mapped_column(primary_key=True)
    signal_id: Mapped[int] = mapped_column(ForeignKey('signals.id'), unique=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey('portfolios.id'))
    symbol: Mapped[str] = mapped_column(String(100))
    action: Mapped[str] = mapped_column(String(10))
    quantity: Mapped[object] = mapped_column(Numeric(24, 10))
    price_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    notional_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    fee_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    status: Mapped[str] = mapped_column(String(20), default='FILLED')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Ledger(Base):
    __tablename__ = 'ledger'
    id: Mapped[int] = mapped_column(primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey('portfolios.id'))
    order_id: Mapped[int | None] = mapped_column(ForeignKey('orders.id'), nullable=True)
    kind: Mapped[str] = mapped_column(String(24))
    amount_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Snapshot(Base):
    __tablename__ = 'snapshots'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'))
    portfolio_id: Mapped[int] = mapped_column(ForeignKey('portfolios.id'))
    equity_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ConnectorState(Base):
    __tablename__ = 'connector_states'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'))
    strategy: Mapped[str] = mapped_column(String(30))
    status: Mapped[str] = mapped_column(String(40), default='NOT_CONFIGURED')
    cursor: Mapped[str | None] = mapped_column(Text, nullable=True)
    message: Mapped[str] = mapped_column(Text, default='')
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__ = (UniqueConstraint('experiment_id', 'strategy'),)

class TraderHistory(Base):
    """Closed trades used only to rank candidates; origin and quality are explicit."""
    __tablename__ = 'trader_history'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'), index=True)
    trader_id: Mapped[str] = mapped_column(String(80), index=True)
    display_name: Mapped[str] = mapped_column(String(100))
    trade_id: Mapped[str] = mapped_column(String(150))
    return_pct: Mapped[object] = mapped_column(Numeric(16, 6))
    closed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    proof_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    provenance: Mapped[str] = mapped_column(String(50))  # DEMO_FIXTURE or USER_SUPPLIED_UNVERIFIED
    __table_args__ = (UniqueConstraint('experiment_id', 'trader_id', 'trade_id'),)


class HourRun(Base):
    """One-hour paper demonstration; 12 distinct five-minute checkpoints."""
    __tablename__ = 'hour_runs'
    id: Mapped[int] = mapped_column(primary_key=True)
    experiment_id: Mapped[int] = mapped_column(ForeignKey('experiments.id'), index=True)
    mode: Mapped[str] = mapped_column(String(20))  # REALTIME or ACCELERATED
    status: Mapped[str] = mapped_column(String(20), default='RUNNING')
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    tick: Mapped[int] = mapped_column(Integer, default=0)
    initial_equity_eur: Mapped[object] = mapped_column(Numeric(20, 8), default=50)


class HourCheckpoint(Base):
    __tablename__ = 'hour_checkpoints'
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey('hour_runs.id'), index=True)
    tick: Mapped[int] = mapped_column(Integer)
    minute: Mapped[int] = mapped_column(Integer)
    virtual_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    equity_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    pnl_eur: Mapped[object] = mapped_column(Numeric(20, 8))
    portfolios_json: Mapped[str] = mapped_column(Text)
    events_json: Mapped[str] = mapped_column(Text)
    leader_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    __table_args__ = (UniqueConstraint('run_id', 'tick'),)
