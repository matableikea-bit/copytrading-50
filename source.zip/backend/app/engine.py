"""Deterministic, long-only, paper-only execution with per-signal idempotency.

All quotes represent EUR prices. Real quote adapters must perform FX conversion
and never return stale, unverified source prices as executable quotes.
"""
import json
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from .models import Experiment, Portfolio, Position, Quote, Signal, Order, Ledger, Snapshot, ConnectorState, utcnow
from .config import STRATEGIES

D = lambda v: Decimal(str(v))
MONEY = Decimal('0.00000001')
QTY = Decimal('0.0000000001')


def money(n):
    return D(n).quantize(MONEY)


def now_aware(dt):
    if dt is None:
        return None
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def current_experiment(db):
    return db.scalars(select(Experiment).order_by(Experiment.id.desc()).limit(1)).first()


def start_experiment(db, mode: str):
    if mode not in ('DEMO', 'PAPER_LIVE_DATA'):
        raise ValueError('Mode non autorisé : DEMO ou PAPER_LIVE_DATA seulement')
    active = current_experiment(db)
    if active and active.status in ('RUNNING', 'PAUSED'):
        raise ValueError('Une expérience existe déjà ; terminez-la avant de recommencer')
    e = Experiment(mode=mode, status='RUNNING')
    db.add(e)
    db.flush()
    for slug, label in STRATEGIES.items():
        p = Portfolio(experiment_id=e.id, slug=slug, label=label, initial_eur=D('10'), cash_eur=D('10'))
        db.add(p)
        db.flush()
        db.add(Ledger(portfolio_id=p.id, kind='INITIAL', amount_eur=D('10')))
        db.add(Snapshot(experiment_id=e.id, portfolio_id=p.id, equity_eur=D('10')))
        db.add(ConnectorState(experiment_id=e.id, strategy=slug, status='DEMO_READY' if mode == 'DEMO' else 'NOT_CONFIGURED'))
    db.commit()
    return e


def quote_upsert(db, experiment_id, symbol, price, *, source, quality):
    if D(price) <= 0:
        raise ValueError('Prix invalide')
    q = db.scalars(select(Quote).where(Quote.experiment_id==experiment_id, Quote.symbol==symbol)).first()
    if not q:
        q = Quote(experiment_id=experiment_id, symbol=symbol, price_eur=money(price), source=source, quality=quality)
        db.add(q)
    else:
        q.price_eur = money(price)
        q.source = source
        q.quality = quality
        q.quoted_at = utcnow()
    db.flush()
    return q


def get_quote(db, experiment_id, symbol):
    return db.scalars(select(Quote).where(Quote.experiment_id==experiment_id, Quote.symbol==symbol)).first()


def value_portfolio(db, p):
    value = D(p.cash_eur)
    unknown = []
    positions=[]
    for pos in db.scalars(select(Position).where(Position.portfolio_id==p.id, Position.quantity>0)).all():
        q = get_quote(db, p.experiment_id, pos.symbol)
        if q is None:
            unknown.append(pos.symbol)
            mkt = D(pos.cost_eur)
        else:
            mkt = D(pos.quantity) * D(q.price_eur)
        value += mkt
        positions.append({'symbol':pos.symbol,'quantity':str(pos.quantity),'cost_eur':str(money(pos.cost_eur)), 'market_value_eur':str(money(mkt)), 'quote_quality':q.quality if q else 'UNKNOWN'})
    return {'id':p.id, 'slug':p.slug,'label':p.label,'initial_eur':str(money(p.initial_eur)), 'cash_eur':str(money(p.cash_eur)), 'equity_eur':str(money(value)), 'pnl_eur':str(money(value-D(p.initial_eur))), 'return_pct':str(money((value/D(p.initial_eur)-1)*100)), 'positions':positions,'valuation_warnings':unknown}


def snapshot_all(db, experiment_id):
    for p in db.scalars(select(Portfolio).where(Portfolio.experiment_id==experiment_id)).all():
        info = value_portfolio(db,p)
        db.add(Snapshot(experiment_id=experiment_id,portfolio_id=p.id,equity_eur=D(info['equity_eur'])))
    db.commit()


def process_signal(db, experiment, strategy: str, external_id: str, symbol: str, action: str,
                   *, source: str, raw: dict | None = None, published_at=None,
                   reference=None, fee_rate='0.001', spread_rate='0.001', max_age_hours=168):
    """Return the signal and its outcome. Duplicate attempts never create another fill.

    BUY spends min(50% current equity, available cash) INCLUDING estimated fees.
    SELL closes the paper position; no short sales. All quantities in simulator
    are fractional, an optimistic simulation assumption displayed in UI.
    """
    strategy = strategy.lower().strip()
    symbol = symbol.upper().strip()
    action = action.upper().strip()
    if strategy not in STRATEGIES or not external_id or not symbol:
        raise ValueError('Stratégie, identifiant ou instrument incorrect')
    if action not in ('BUY', 'SELL'):
        raise ValueError('Actions acceptées : BUY ou SELL')
    old = db.scalars(select(Signal).where(Signal.experiment_id==experiment.id, Signal.strategy==strategy, Signal.external_id==external_id)).first()
    if old:
        return old, True
    s = Signal(experiment_id=experiment.id, strategy=strategy, external_id=external_id,
               symbol=symbol, action=action, source=source, raw_json=json.dumps(raw or {},ensure_ascii=False,default=str)[:60000],
               published_at=now_aware(published_at), reference=reference)
    db.add(s)
    db.flush()
    def reject(reason, status='REJECTED'):
        s.status=status
        s.reason=reason
        db.commit()
        return s, False
    if experiment.status!='RUNNING':
        return reject('Expérience en pause ou terminée')
    if s.published_at is not None:
        age=(utcnow()-now_aware(s.published_at)).total_seconds()
        if age > max_age_hours*3600:
            return reject('Signal trop ancien pour être copié', 'STALE')
        if age < -300:
            return reject('Date de publication future')
    portfolio = db.scalars(select(Portfolio).where(Portfolio.experiment_id==experiment.id, Portfolio.slug==strategy)).first()
    q = get_quote(db, experiment.id, symbol)
    if q is None:
        return reject('Aucune cotation EUR indépendante disponible')
    if experiment.mode=='PAPER_LIVE_DATA' and q.quality=='DEMO_FIXTURE':
        return reject('Prix fictif interdit dans PAPER_LIVE_DATA')
    # Don't fill from price bars older than 3 days (incl. weekend). No market-hours guarantee for indicative quotes.
    if experiment.mode=='PAPER_LIVE_DATA':
        quoted=now_aware(q.quoted_at)
        if (utcnow()-quoted).total_seconds()>72*3600:
            return reject('Cotation trop ancienne')
    price = D(q.price_eur)
    if price<=0:
        return reject('Cotation non positive')
    fee_pct = D(fee_rate)
    spread_pct = D(spread_rate)
    if not (D('0')<=fee_pct<=D('0.05') and D('0')<=spread_pct<=D('0.1')):
        return reject('Paramètres de frais invalides')
    pos = db.scalars(select(Position).where(Position.portfolio_id==portfolio.id, Position.symbol==symbol)).first()
    if action=='BUY':
        max_cost=min(D(portfolio.cash_eur), D(value_portfolio(db,portfolio)['equity_eur'])*D('0.5'))
        execution_price = price * (1+spread_pct/2)
        qty = (max_cost / (execution_price*(1+fee_pct))).quantize(QTY,rounding=ROUND_DOWN)
        notional=money(qty*execution_price)
        fee=money(notional*fee_pct)
        if qty<=0 or notional+fee>D(portfolio.cash_eur) or notional<=0:
            return reject('Cash insuffisant pour une quantité positive')
        if not pos:
            pos=Position(portfolio_id=portfolio.id,symbol=symbol,quantity=D('0'),cost_eur=D('0'))
            db.add(pos)
        pos.quantity=D(pos.quantity)+qty
        pos.cost_eur=money(D(pos.cost_eur)+notional+fee)
        portfolio.cash_eur=money(D(portfolio.cash_eur)-notional-fee)
        cash_delta=-(notional+fee)
    else:
        if not pos or D(pos.quantity)<=0:
            return reject('Aucune position à vendre (vente à découvert interdite)')
        qty=D(pos.quantity)
        execution_price=price*(1-spread_pct/2)
        notional=money(qty*execution_price)
        fee=money(notional*fee_pct)
        portfolio.cash_eur=money(D(portfolio.cash_eur)+notional-fee)
        pos.quantity=D('0')
        pos.cost_eur=D('0')
        cash_delta=notional-fee
    if D(portfolio.cash_eur)<0:
        db.rollback()
        raise AssertionError('Invariant : cash négatif')
    order=Order(signal_id=s.id, portfolio_id=portfolio.id, symbol=symbol,
                action=action, quantity=qty, price_eur=money(execution_price),
                notional_eur=notional, fee_eur=fee,status='FILLED')
    db.add(order)
    db.flush()
    db.add(Ledger(portfolio_id=portfolio.id, order_id=order.id, kind=action, amount_eur=money(cash_delta)))
    s.status='EXECUTED_IN_PAPER'
    s.reason='Cotation '+q.quality+' ; fractions autorisées uniquement dans le simulateur'
    db.flush()
    db.add(Snapshot(experiment_id=experiment.id, portfolio_id=portfolio.id, equity_eur=D(value_portfolio(db,portfolio)['equity_eur'])))
    db.commit()
    return s, False
