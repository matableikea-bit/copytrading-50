"""CopyTrading 50 educational, simulated trading platform."""
