"""Local paper-only settings. Never accept trading credentials or live order endpoints."""
from dataclasses import dataclass
import os
from dotenv import load_dotenv
load_dotenv()

STRATEGIES = {
    'pelosi': 'Nancy Pelosi',
    'telegram': 'Trader Telegram',
    'professional': 'Trader professionnel',
    'institutional': 'Fonds d’investissement',
    'polymarket': 'Polymarket (observation)',
}

@dataclass(frozen=True)
class Settings:
    db_url: str = os.getenv('DATABASE_URL', 'sqlite:///./copytrading.sqlite3')
    admin_token: str = os.getenv('ADMIN_TOKEN', '')
    telegram_token: str = os.getenv('TELEGRAM_BOT_TOKEN', '')
    telegram_channel: str = os.getenv('TELEGRAM_CHANNEL_ID', '')
    webhook_token: str = os.getenv('SOURCE_WEBHOOK_TOKEN', '')
    pelosi_csv_url: str = os.getenv('PELOSI_CSV_URL', '')
    top_traders_history_csv: str = os.getenv('TOP_TRADERS_HISTORY_CSV', '')
    top_traders_approved_ids: str = os.getenv('TOP_TRADERS_APPROVED_IDS', '')
    institutional_csv_path: str = os.getenv('INSTITUTIONAL_CSV_PATH', '')
    demo_seed_enabled: bool = os.getenv('DEMO_SEED_ENABLED', 'true').lower() == 'true'
    enable_scheduler: bool = os.getenv('ENABLE_SCHEDULER', 'true').lower() == 'true'
    poll_seconds: int = max(60, int(os.getenv('POLL_SECONDS', '600')))
    max_signal_age_hours: int = max(1, int(os.getenv('MAX_SIGNAL_AGE_HOURS', '168')))
    fee_rate: str = os.getenv('PAPER_FEE_RATE', '0.001')
    spread_rate: str = os.getenv('PAPER_SPREAD_RATE', '0.001')
