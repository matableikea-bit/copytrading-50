"""Optional read-only adapters. No trade placement, no scraping of private data."""
import csv
import hashlib
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path
import httpx
from sqlalchemy import select
from .config import Settings, STRATEGIES
from .models import ConnectorState, utcnow
from .engine import process_signal


SIGNAL_RE = re.compile(r'\b(BUY|SELL)\s+([A-Z][A-Z0-9._:/-]{1,22})\b', re.I)


def parse_telegram(text):
    m=SIGNAL_RE.search(text.upper())
    if not m:
        return None
    return {'action':m.group(1).upper(), 'symbol':m.group(2).upper()}


def _state(db, exp, strategy):
    return db.scalars(select(ConnectorState).where(ConnectorState.experiment_id==exp.id,ConnectorState.strategy==strategy)).one()


def _record(db, exp, strategy, status, message, cursor=None):
    s=_state(db, exp, strategy)
    s.status=status
    s.message=str(message)[:700]
    s.last_sync_at=utcnow()
    if cursor is not None:
        s.cursor=str(cursor)
    db.commit()


def do_signal(db, exp, cfg, strategy, external_id, symbol, action, source, published_at, reference, raw):
    return process_signal(db,exp,strategy,external_id,symbol,action,
        source=source,published_at=published_at, reference=reference,raw=raw,
        fee_rate=cfg.fee_rate,spread_rate=cfg.spread_rate,max_age_hours=cfg.max_signal_age_hours)


def sync_pelosi(db, exp, cfg):
    """Third-party public congressional CSV, NOT an official House Clerk API.
    Baselines first polling: never backfill historic disclosures as new live signals.
    """
    if not cfg.pelosi_csv_url:
        _record(db,exp,'pelosi','NOT_CONFIGURED','Configure PELOSI_CSV_URL (CSV tiers)')
        return 0
    if not cfg.pelosi_csv_url.startswith('https://'):
        raise ValueError('PELOSI_CSV_URL doit utiliser HTTPS')
    r=httpx.get(cfg.pelosi_csv_url,timeout=20,follow_redirects=False)
    r.raise_for_status()
    reader=csv.DictReader(io.StringIO(r.text))
    rows=[x for x in reader if 'pelosi' in x.get('filer_name','').lower()]
    state=_state(db,exp,'pelosi')
    # At first sync we baseline what exists, to avoid buying archival records.
    if not state.cursor:
        _record(db,exp,'pelosi','OBSERVING',f'{len(rows)} déclarations historiques initialisées, futures publications surveillées',cursor=utcnow().isoformat())
        return 0
    count=0
    baseline=datetime.fromisoformat(state.cursor)
    for item in rows:
        date_str=item.get('filing_date','')
        try:
            pub=datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc)
        except (ValueError,TypeError):
            continue
        if pub.date()<=baseline.date():
            continue
        if item.get('security_type','').strip().lower() not in ('stock','equity','etf'):
            continue
        raw_action=item.get('transaction_type','').lower()
        action='BUY' if 'purchase' in raw_action else ('SELL' if 'sale' in raw_action else None)
        symbol=item.get('ticker','').strip().upper()
        if not action or not re.fullmatch(r'[A-Z][A-Z0-9.]{0,9}',symbol):
            continue
        key=hashlib.sha256(json.dumps(item,sort_keys=True).encode()).hexdigest()
        do_signal(db, exp,cfg,'pelosi',key,symbol,action,'CapitolStockWatch (republication de déclarations)',pub,item.get('filing_url'),item)
        count+=1
    _record(db,exp,'pelosi','OBSERVING',f'{count} nouveau(x) signal(aux) traité(s)',cursor=utcnow().isoformat())
    return count


def sync_telegram(db, exp, cfg):
    if not cfg.telegram_token or not cfg.telegram_channel:
        _record(db,exp,'telegram','NOT_CONFIGURED','Configurer TELEGRAM_BOT_TOKEN et TELEGRAM_CHANNEL_ID')
        return 0
    state=_state(db,exp,'telegram')
    offset=int(state.cursor or '0')
    # This bot must already receive channel_post updates (typically bot admin in channel).
    r=httpx.get(f'https://api.telegram.org/bot{cfg.telegram_token}/getUpdates',
        params={'offset':offset,'limit':100,'timeout':0,'allowed_updates':json.dumps(['channel_post','edited_channel_post'])},timeout=20)
    r.raise_for_status()
    data=r.json()
    if not data.get('ok'):
        raise RuntimeError('Telegram API response not ok')
    count=0
    for u in data.get('result',[]):
        new_offset=max(offset,int(u['update_id'])+1)
        msg=u.get('channel_post') or u.get('edited_channel_post') or {}
        channel=str((msg.get('chat') or {}).get('id',''))
        if channel==cfg.telegram_channel:
            parsed=parse_telegram(msg.get('text') or msg.get('caption') or '')
            if parsed:
                edited=bool(u.get('edited_channel_post'))
                ext=f"{channel}:{msg.get('message_id')}:{msg.get('edit_date',msg.get('date'))}" if edited else f"{channel}:{msg.get('message_id')}:original"
                published=datetime.fromtimestamp(int(msg.get('edit_date', msg.get('date',0))),tz=timezone.utc)
                do_signal(db, exp,cfg,'telegram',ext,parsed['symbol'],parsed['action'],
                          'Telegram Bot API',published,None,msg)
                count+=1
        # cursor commits after event processing, avoiding lost events on crash.
        offset=new_offset
        _record(db,exp,'telegram','OBSERVING',f'{count} signaux détectés',cursor=offset)
    _record(db,exp,'telegram','OBSERVING',f'{count} signaux détectés',cursor=offset)
    return count


def sync_institutional(db, exp, cfg):
    """Authorized CSV import: event_id,symbol,action,published_at,source_url.
    NOT a full 13F parser and not automatically inferred from changed holdings.
    """
    if not cfg.institutional_csv_path:
        _record(db,exp,'institutional','NOT_CONFIGURED','Configurer INSTITUTIONAL_CSV_PATH (CSV vérifié et horodaté)')
        return 0
    p=Path(cfg.institutional_csv_path).resolve()
    if not p.is_file():
        _record(db,exp,'institutional','ERROR','Fichier institutionnel introuvable')
        return 0
    n=0
    with p.open(encoding='utf-8-sig',newline='') as fh:
        for row in csv.DictReader(fh):
            if not all(row.get(x) for x in ('event_id','symbol','action','published_at','source_url')):
                continue
            action=row['action'].upper()
            if action not in ('BUY','SELL'):
                continue
            pub=datetime.fromisoformat(row['published_at'].replace('Z','+00:00'))
            # Important: only process actual published signals since experiment start
            if pub.date()<exp.started_at.date():
                continue
            _,dup=do_signal(db,exp,cfg,'institutional',row['event_id'],row['symbol'],action,
                'CSV institutionnel fourni par administrateur',pub,row['source_url'],row)
            n+=int(not dup)
    _record(db,exp,'institutional','OBSERVING',f'{n} signal(aux) nouveau(x) traité(s)')
    return n


def sync_professional(db, exp, cfg):
    _record(db,exp,'professional','WEBHOOK_READY' if cfg.webhook_token else 'NOT_CONFIGURED',
        'Configurer SOURCE_WEBHOOK_TOKEN, puis envoyer les signaux au webhook sécurisé')
    return 0


def sync_polymarket(db, exp, cfg):
    # France: deliberately no Polymarket network connector or execution; optional
    # fixture/imports can be used only in DEMO. No geoblock bypass.
    _record(db,exp,'polymarket','READ_ONLY_DISABLED','Marché de prédiction : flux distant désactivé (restrictions locales)')
    return 0

CONNECTORS={
    'pelosi':sync_pelosi,
    'telegram':sync_telegram,
    'professional':sync_professional,
    'institutional':sync_institutional,
    'polymarket':sync_polymarket,
}


def sync_all(db, exp, cfg, slug=None):
    results={}
    for name,fn in CONNECTORS.items():
        if slug and name!=slug:
            continue
        try:
            results[name]={'count':fn(db,exp,cfg),'ok':True}
        except Exception as e:
            db.rollback()
            safe_error=str(e).replace(cfg.telegram_token,'[REDACTED]') if cfg.telegram_token else str(e)
            _record(db,exp,name,'ERROR',f'{type(e).__name__}: {safe_error[:150]}')
            results[name]={'count':0,'ok':False,'error':safe_error[:200]}
    return results
