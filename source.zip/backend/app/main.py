"""CopyTrading 50 API — simulation ONLY. Does not ship a live broker adapter."""
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import os
import secrets
import base64
from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from .config import STRATEGIES, Settings
from .models import Base, Experiment, Portfolio, Position, Quote, Signal, Order, Ledger, Snapshot, ConnectorState, utcnow
from .engine import current_experiment, start_experiment, process_signal, quote_upsert, value_portfolio, snapshot_all, D, money
from .connectors import sync_all, do_signal
from .prices import refresh_us_stock
from .top_traders import ranked_traders, import_history_csv
from .hour_simulation import hour_status, begin_hour, execute_accelerated, advance_realtime_hour

class StartInput(BaseModel):
    mode: str = 'DEMO'

class DemoPrice(BaseModel):
    symbol: str = Field(min_length=2,max_length=100)
    price_eur: Decimal = Field(gt=0,le=1000000)

class ManualDemoSignal(BaseModel):
    strategy: str
    symbol: str
    action: str

class WebhookSignal(BaseModel):
    external_id: str = Field(min_length=1,max_length=250)
    symbol: str = Field(min_length=2,max_length=100)
    action: str
    published_at: datetime
    source_reference: str | None = None

class TopTraderWebhookSignal(WebhookSignal):
    trader_id: str = Field(min_length=1,max_length=80)

DEMO_PRICES={'NVDA':102.00,'EURUSD':1.08,'AAPL':189.00,'MSFT':389.00,'PREDICTION:YES':0.55}
DEMO_SYMBOLS={'pelosi':'NVDA','telegram':'EURUSD','professional':'AAPL','institutional':'MSFT','polymarket':'PREDICTION:YES'}


def create_app(db_url=None, enable_scheduler=None):
    cfg=Settings()
    url=db_url or cfg.db_url
    connect_args={'check_same_thread':False} if url.startswith('sqlite:') else {}
    engine=create_engine(url,connect_args=connect_args, poolclass=StaticPool if url=='sqlite://' else None)
    Session=sessionmaker(bind=engine,expire_on_commit=False)

    @asynccontextmanager
    async def lifespan(app):
        Base.metadata.create_all(engine)
        task=None
        hour_task=None
        if enable_scheduler if enable_scheduler is not None else cfg.enable_scheduler:
            async def scheduler():
                while True:
                    await asyncio.sleep(cfg.poll_seconds)
                    with Session() as db:
                        e=current_experiment(db)
                        if not e or e.status!='RUNNING':
                            continue
                        if utcnow().replace(tzinfo=None)-e.started_at.replace(tzinfo=None)>timedelta(days=60):
                            snapshot_all(db,e.id)
                            e.status='COMPLETE'
                            e.ended_at=utcnow()
                            db.commit()
                            continue
                        if e.mode=='PAPER_LIVE_DATA':
                            def run_connectors():
                                with Session() as worker_db:
                                    worker_exp=current_experiment(worker_db)
                                    if worker_exp and worker_exp.status=='RUNNING':
                                        return sync_all(worker_db,worker_exp,cfg)
                            await asyncio.to_thread(run_connectors)
                        snapshot_all(db,e.id)
            task=asyncio.create_task(scheduler())
            async def hour_scheduler():
                while True:
                    await asyncio.sleep(10)
                    def update():
                        with Session() as db:
                            return advance_realtime_hour(db)
                    try:
                        await asyncio.to_thread(update)
                    except Exception as err:
                        # An error must not be silently interpreted as a completed checkpoint.
                        import logging
                        logging.getLogger(__name__).exception('Hour demo tick failed: %s',err)
            hour_task=asyncio.create_task(hour_scheduler())
        try:
            yield
        finally:
            if hour_task:
                hour_task.cancel()
                try: await hour_task
                except asyncio.CancelledError: pass
            if task:
                task.cancel()
                try: await task
                except asyncio.CancelledError: pass
            engine.dispose()

    app=FastAPI(title='CopyTrading 50 • Paper Only',version='0.2.1',lifespan=lifespan)

    # A browser-level password barrier protects the entire app on public hosts,
    # including read-only portfolio data and mutating endpoints.
    # Local development remains unauthenticated unless explicitly configured.
    require_auth = os.getenv('REQUIRE_AUTH', 'false').lower() == 'true'
    dashboard_user = os.getenv('DASHBOARD_USER', 'trader')
    dashboard_password = os.getenv('DASHBOARD_PASSWORD', '')
    if require_auth and (not dashboard_user or len(dashboard_password) < 12):
        raise RuntimeError('REQUIRE_AUTH=true nécessite DASHBOARD_USER et DASHBOARD_PASSWORD (12 caractères minimum).')

    @app.middleware('http')
    async def protect_public_app(request, call_next):
        if require_auth and request.url.path != '/api/health':
            header = request.headers.get('authorization', '')
            supplied_user, supplied_password = '', ''
            if header.startswith('Basic '):
                try:
                    decoded = base64.b64decode(header[6:], validate=True).decode('utf-8')
                    supplied_user, supplied_password = decoded.split(':', 1)
                except (ValueError, UnicodeDecodeError):
                    pass
            valid = (secrets.compare_digest(supplied_user, dashboard_user)
                     and secrets.compare_digest(supplied_password, dashboard_password))
            if not valid:
                return JSONResponse({'detail':'Authentification nécessaire'},status_code=401,
                                    headers={'WWW-Authenticate':'Basic realm=CopyTrading50'})
        return await call_next(request)

    app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_credentials=False,allow_methods=['*'],allow_headers=['*'])
    static_root=Path(__file__).parent / 'static'
    app.mount('/assets', StaticFiles(directory=str(static_root)), name='assets')

    @app.get('/', include_in_schema=False)
    def home():
        return FileResponse(str(static_root / 'index.html'))

    def get_db():
        with Session() as db: yield db

    def require_admin(x_admin_token: str | None=Header(default=None)):
        if cfg.admin_token and x_admin_token!=cfg.admin_token:
            raise HTTPException(401,'Token administrateur incorrect')

    def active(db):
        e=current_experiment(db)
        if not e:
            raise HTTPException(404,'Aucune expérience active : cliquer Démarrer')
        return e

    def signal_dict(s):
        return {'id':s.id,'strategy':s.strategy,'symbol':s.symbol,'action':s.action,'status':s.status,
                'reason':s.reason,'source':s.source,'published_at':s.published_at,'detected_at':s.detected_at,'reference':s.reference}

    @app.get('/api/health')
    def health():
        return {'ok':True,'paper_only':True,'live_trading_implemented':False}

    @app.get('/api/dashboard')
    def dashboard(db=Depends(get_db)):
        e=current_experiment(db)
        if not e:
            return {'experiment':None,'portfolios':[],'signals':[],'orders':[],'connectors':[],'snapshots':[]}
        portfolios=db.scalars(select(Portfolio).where(Portfolio.experiment_id==e.id).order_by(Portfolio.id)).all()
        signals=db.scalars(select(Signal).where(Signal.experiment_id==e.id).order_by(Signal.id.desc()).limit(30)).all()
        states=db.scalars(select(ConnectorState).where(ConnectorState.experiment_id==e.id)).all()
        orders=db.scalars(select(Order).join(Portfolio,Order.portfolio_id==Portfolio.id).where(Portfolio.experiment_id==e.id).order_by(Order.id.desc()).limit(30)).all()
        data=[value_portfolio(db,p) for p in portfolios]
        snaps=db.scalars(select(Snapshot).where(Snapshot.experiment_id==e.id).order_by(Snapshot.at.asc()).limit(1000)).all()
        # Forward-fill snapshots to compute a correct *total* curve, even when
        # only one portfolio changes in a minute.
        last_values={}
        total_curve={}
        for snap in snaps:
            last_values[snap.portfolio_id]=D(snap.equity_eur)
            if len(last_values)==len(portfolios):
                bucket=snap.at.isoformat()[:16]
                total_curve[bucket]=str(money(sum(last_values.values(),D('0'))))
        equity_curve=[{'at':k+':00','equity_eur':v} for k,v in sorted(total_curve.items())]
        # Expose only source-backed quotes, not secret config.
        quotes=db.scalars(select(Quote).where(Quote.experiment_id==e.id)).all()
        days=min(60,max(0,(utcnow().replace(tzinfo=None)-e.started_at.replace(tzinfo=None)).days))
        return {'experiment':{'id':e.id,'mode':e.mode,'status':e.status,'started_at':e.started_at,'days_elapsed':days,'duration_days':60},
                'portfolios':data,'signals':[signal_dict(s) for s in signals],
                'orders':[{'id':o.id,'symbol':o.symbol,'action':o.action,'quantity':str(o.quantity),'price_eur':str(o.price_eur),'fee_eur':str(o.fee_eur),'notional_eur':str(o.notional_eur),'at':o.created_at,'strategy':next((p.slug for p in portfolios if p.id==o.portfolio_id),'')} for o in orders],
                'connectors':[{'strategy':s.strategy,'status':s.status,'message':s.message,'last_sync_at':s.last_sync_at} for s in states],
                'snapshots':[{'portfolio_id':s.portfolio_id,'at':s.at,'equity_eur':str(s.equity_eur)} for s in snaps],
                'equity_curve':equity_curve,
                'quotes':[{'symbol':q.symbol,'price_eur':str(q.price_eur),'quality':q.quality,'source':q.source,'quoted_at':q.quoted_at} for q in quotes]}

    @app.post('/api/experiments/start',dependencies=[Depends(require_admin)])
    def start(body:StartInput,db=Depends(get_db)):
        try:
            e=start_experiment(db,body.mode)
        except ValueError as err:
            raise HTTPException(400,str(err))
        if body.mode=='DEMO':
            for sym,px in DEMO_PRICES.items(): quote_upsert(db,e.id,sym,px,source='Fixture locale (fictif)',quality='DEMO_FIXTURE')
            db.commit()
        return {'id':e.id,'mode':e.mode,'status':e.status,'capital_eur':'50.00'}

    @app.post('/api/experiments/{action}',dependencies=[Depends(require_admin)])
    def change_state(action:str,db=Depends(get_db)):
        e=active(db)
        if action=='pause' and e.status=='RUNNING':e.status='PAUSED'
        elif action=='resume' and e.status=='PAUSED':e.status='RUNNING'
        elif action=='complete' and e.status in ('RUNNING','PAUSED'):
            e.status='COMPLETE';e.ended_at=utcnow()
        else: raise HTTPException(400,'Transition impossible')
        db.commit()
        return {'status':e.status}

    @app.post('/api/demo/signal',dependencies=[Depends(require_admin)])
    def demo_signal(body:ManualDemoSignal,db=Depends(get_db)):
        e=active(db)
        if e.mode!='DEMO':raise HTTPException(403,'Réservé au mode DEMO')
        if body.strategy not in STRATEGIES:raise HTTPException(400,'Stratégie inconnue')
        sym=body.symbol.upper().strip()
        if not db.scalars(select(Quote).where(Quote.experiment_id==e.id,Quote.symbol==sym)).first():
            raise HTTPException(400,'Symbole sans prix de démonstration')
        try:
            s,duplicate=process_signal(db,e,body.strategy,str(uuid4()),sym,body.action,
             source='DEMO_FICTIF',raw={'demo':True},fee_rate=cfg.fee_rate,spread_rate=cfg.spread_rate)
        except ValueError as err:raise HTTPException(400,str(err))
        return {'signal':signal_dict(s),'duplicate':duplicate}

    @app.post('/api/demo/prices',dependencies=[Depends(require_admin)])
    def demo_price(body:DemoPrice,db=Depends(get_db)):
        e=active(db)
        if e.mode!='DEMO':raise HTTPException(403,'Réservé au mode DEMO')
        sym=body.symbol.upper().strip()
        if sym not in DEMO_PRICES:
            raise HTTPException(400,'Seules les cinq cotations fictives peuvent être modifiées')
        quote_upsert(db,e.id,sym,body.price_eur,source='DEMO_FICTIF',quality='DEMO_FIXTURE')
        snapshot_all(db,e.id)
        return {'ok':True,'symbol':sym,'price_eur':str(body.price_eur)}

    @app.post('/api/demo/example',dependencies=[Depends(require_admin)])
    def demo_example(db=Depends(get_db)):
        e=active(db)
        if e.mode!='DEMO':raise HTTPException(403,'Réservé à DEMO')
        res=[]
        for slug,sym in DEMO_SYMBOLS.items():
            s,_=process_signal(db,e,slug,'demo:'+str(uuid4()),sym,'BUY',source='DEMO_FICTIF',raw={'demo':True},fee_rate=cfg.fee_rate,spread_rate=cfg.spread_rate)
            res.append(signal_dict(s))
        return {'signals':res}

    @app.get('/api/top-traders')
    def top_traders(db=Depends(get_db)):
        e=current_experiment(db)
        return {'ranking':ranked_traders(db,e.id) if e else [],
                'warning':'Classement historique, non prédictif. FICTIF en DEMO ; fichiers utilisateur NON VÉRIFIÉS en PAPER. Aucun flux de traders professionnels validé automatiquement.',
                'portfolio':'professional','allocated_eur':'10.00'}

    @app.post('/api/top-traders/import',dependencies=[Depends(require_admin)])
    def import_top_traders(db=Depends(get_db)):
        e=active(db)
        if e.mode!='PAPER_LIVE_DATA':
            raise HTTPException(403,'Import réservé au mode PAPER_LIVE_DATA')
        if not cfg.top_traders_history_csv:
            raise HTTPException(400,'Configurer TOP_TRADERS_HISTORY_CSV (historique fourni, NON VÉRIFIÉ)')
        try:
            added=import_history_csv(db,e.id,cfg.top_traders_history_csv)
        except (OSError,ValueError) as err:
            raise HTTPException(400,str(err))
        return {'rows_imported':added,'verification':'USER_SUPPLIED_UNVERIFIED',
                'warning':'Un historique importé ne prouve pas la rentabilité ni un accès temps réel aux opérations.'}

    @app.post('/api/webhooks/top-trader')
    def top_trader_webhook(body:TopTraderWebhookSignal,x_source_token:str | None=Header(default=None),db=Depends(get_db)):
        # Explicitly opted-in trader IDs, not a magic auto-selection of a hypothetical winner.
        if not cfg.webhook_token or x_source_token!=cfg.webhook_token:
            raise HTTPException(401,'Token webhook manquant ou incorrect')
        e=active(db)
        if e.mode!='PAPER_LIVE_DATA' or e.status!='RUNNING':
            raise HTTPException(403,'Réservé au PAPER actif')
        allow={x.strip() for x in cfg.top_traders_approved_ids.split(',') if x.strip()}
        if not allow or body.trader_id not in allow:
            raise HTTPException(403,'Trader non approuvé dans TOP_TRADERS_APPROVED_IDS')
        candidates=[x for x in ranked_traders(db,e.id,as_of=body.published_at)
                    if x['eligible'] and x['provenance']=='USER_SUPPLIED_UNVERIFIED'][:2]
        if body.trader_id not in {x['trader_id'] for x in candidates}:
            raise HTTPException(403,'Trader absent du Top 2 éligible sur historique disponible à la date du signal')
        if not body.source_reference or not body.source_reference.startswith('https://'):
            raise HTTPException(400,'Preuve HTTPS du signal obligatoire')
        try:
            signal,duplicated=do_signal(db,e,cfg,'professional',
                'toptrader:'+body.trader_id+':'+body.external_id,body.symbol.upper(),body.action,
                'TOP TRADER — webhook autorisé, source non auditée',body.published_at,
                body.source_reference,body.model_dump(mode='json'))
        except ValueError as err: raise HTTPException(400,str(err))
        return {'signal':signal_dict(signal),'duplicate':duplicated,
                'warning':'Webhook autorisé mais fiabilité du trader et de son fournisseur non garantie.'}

    @app.get('/api/demo/hour')
    def get_hour(db=Depends(get_db)):
        e=current_experiment(db)
        return hour_status(db,e.id) if e else {'run':None,'checkpoints':[],'leaderboard':[]}

    @app.post('/api/demo/hour/start',dependencies=[Depends(require_admin)])
    def start_hour(db=Depends(get_db)):
        e=active(db)
        try: run=begin_hour(db,e,mode='REALTIME')
        except ValueError as err:raise HTTPException(400,str(err))
        return {'id':run.id,'mode':run.mode,'status':run.status,
                'message':'Suivi local pendant 1 heure : 12 points toutes les 5 minutes. Le serveur doit rester allumé.'}

    @app.post('/api/demo/hour/fast-forward',dependencies=[Depends(require_admin)])
    def fast_forward_hour(db=Depends(get_db)):
        e=active(db)
        try: return execute_accelerated(db,e)
        except ValueError as err:raise HTTPException(400,str(err))

    @app.post('/api/connectors/sync',dependencies=[Depends(require_admin)])
    def sync(db=Depends(get_db)):
        e=active(db)
        if e.mode!='PAPER_LIVE_DATA':raise HTTPException(403,'Connecteurs externes uniquement en PAPER_LIVE_DATA')
        if e.status!='RUNNING':raise HTTPException(409,'Expérience suspendue')
        return sync_all(db,e,cfg)

    @app.post('/api/quotes/us/{symbol}/refresh',dependencies=[Depends(require_admin)])
    def refresh_quote(symbol:str,db=Depends(get_db)):
        e=active(db)
        if e.mode!='PAPER_LIVE_DATA':raise HTTPException(403,'Réservé à PAPER_LIVE_DATA')
        try:
            q=refresh_us_stock(db,e.id,symbol.upper())
            snapshot_all(db,e.id)
        except Exception as err:
            raise HTTPException(503,f'Données externes indisponibles : {str(err)[:200]}')
        return {'symbol':q.symbol,'price_eur':str(q.price_eur),'quality':q.quality,'source':q.source,'quoted_at':q.quoted_at}

    @app.post('/api/webhooks/professional')
    def webhook(body:WebhookSignal,x_source_token:str | None=Header(default=None),db=Depends(get_db)):
        if not cfg.webhook_token or x_source_token!=cfg.webhook_token:
            raise HTTPException(401,'Webhook désactivé ou clé incorrecte')
        e=active(db)
        if e.mode!='PAPER_LIVE_DATA' or e.status!='RUNNING':
            raise HTTPException(403,'Webhook utilisable uniquement pendant PAPER_LIVE_DATA actif')
        try:
            s,duplicate=do_signal(db,e,cfg,'professional',body.external_id,body.symbol.upper(),body.action,
              'Webhook configuré (déclaration du fournisseur non vérifiée)',body.published_at,body.source_reference,body.model_dump(mode='json'))
        except ValueError as err:raise HTTPException(400,str(err))
        return {'signal':signal_dict(s),'duplicate':duplicate}

    @app.get('/api/strategies')
    def strategies(): return [{'id':s,'name':v} for s,v in STRATEGIES.items()]

    app.state.Session=Session
    return app

app=create_app()
