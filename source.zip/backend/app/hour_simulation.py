"""One-hour demo runner: 12 deterministic *fictional* 5-minute checkpoints.

REALTIME mode progresses only when the local FastAPI server remains running.
ACCELERATED mode replays 60 virtual minutes immediately. This code never
pulls live trader activity, never places broker orders and never predicts profits.
"""
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from sqlalchemy import select
from .config import STRATEGIES
from .models import HourRun, HourCheckpoint, Portfolio, Order, Experiment, utcnow
from .engine import D, money, value_portfolio, quote_upsert, process_signal
from .top_traders import seed_demo_history, ranked_traders

DEMO_BASE = {'NVDA':D('102'), 'EURUSD':D('1.08'), 'AAPL':D('189'), 'MSFT':D('389'), 'PREDICTION:YES':D('0.55')}
# Fictional paths, not real exchange quotes. Deliberately include gains and losses.
PRICE_CHANGES = {
    'NVDA': [0,0.4,-0.3,0.1,0.7,-0.8,-0.2,-0.5,0.6,0.1,-0.3,0.2],
    'EURUSD': [0,-0.2,0.1,-0.1,0.2,0.0,-0.2,0.1,0.3,-0.1,0.0,-0.2],
    'AAPL': [0,0.2,0.4,-0.6,-0.3,0.1,0.5,-0.2,-0.1,0.6,0.1,-0.4],
    'MSFT': [0,-0.3,0.1,0.1,-0.2,-0.4,0.2,0.3,-0.1,0.4,-0.2,0.1],
    'PREDICTION:YES':[0,-1.2,0.9,0.5,-0.5,1.0,-0.8,-1.2,1.6,-0.4,0.2,-0.6],
}
# Tick -> source, asset, action. A top-trader decision goes into the existing
# 10 EUR 'professional' portfolio (no sixth portfolio and no extra capital).
DEMO_EVENTS = {
    1: [('pelosi','NVDA','BUY'),('telegram','EURUSD','BUY'),('institutional','MSFT','BUY'),('polymarket','PREDICTION:YES','BUY'),('professional','AAPL','BUY')],
    3: [('telegram','EURUSD','SELL')],
    4: [('professional','AAPL','SELL')],
    5: [('professional','MSFT','BUY')],
    6: [('institutional','MSFT','SELL')],
    7: [('pelosi','NVDA','SELL')],
    8: [('professional','MSFT','SELL'),('telegram','EURUSD','BUY')],
    9: [('polymarket','PREDICTION:YES','SELL')],
    10:[('professional','AAPL','BUY')],
    11:[('telegram','EURUSD','SELL')],
    12:[('professional','AAPL','SELL')],
}


def hour_status(db, experiment_id):
    run=db.scalars(select(HourRun).where(HourRun.experiment_id==experiment_id).order_by(HourRun.id.desc())).first()
    if not run: return {'run':None,'checkpoints':[],'leaderboard':[]}
    cps=db.scalars(select(HourCheckpoint).where(HourCheckpoint.run_id==run.id).order_by(HourCheckpoint.tick)).all()
    leaderboard=ranked_traders(db,experiment_id,as_of=run.started_at)
    return {'run':{'id':run.id,'mode':run.mode,'status':run.status,'tick':run.tick,'total_ticks':12,
                   'started_at':run.started_at.isoformat(),'completed_at':run.completed_at.isoformat() if run.completed_at else None,
                   'initial_equity_eur':str(run.initial_equity_eur),
                   'warning':'Scénario fictif entièrement synthétique ; ne reflète aucune opération de véritables traders.'},
            'checkpoints':[{'minute':c.minute,'tick':c.tick,'virtual_at':(c.virtual_at.replace(tzinfo=timezone.utc) if c.virtual_at.tzinfo is None else c.virtual_at).isoformat(),
                           'equity_eur':str(c.equity_eur),'pnl_eur':str(c.pnl_eur),
                           'portfolios':json.loads(c.portfolios_json),'events':json.loads(c.events_json),
                           'selected_trader':c.leader_id} for c in cps],
            'leaderboard':leaderboard}


def begin_hour(db, exp, *, mode='REALTIME'):
    if exp.mode!='DEMO' or exp.status!='RUNNING':
        raise ValueError('Test une heure réservé à une expérience DEMO active')
    if mode not in ('REALTIME','ACCELERATED'): raise ValueError('Mode invalide')
    last=db.scalars(select(HourRun).where(HourRun.experiment_id==exp.id).order_by(HourRun.id.desc())).first()
    if last and last.status=='RUNNING':raise ValueError('Une simulation d’une heure est déjà active')
    seed_demo_history(db,exp.id,started_at=utcnow())
    portfolios=db.scalars(select(Portfolio).where(Portfolio.experiment_id==exp.id)).all()
    if len(portfolios)!=5:raise ValueError('Portefeuilles manquants')
    initial=sum((D(value_portfolio(db,p)['equity_eur']) for p in portfolios),D('0'))
    run=HourRun(experiment_id=exp.id,mode=mode,status='RUNNING',started_at=utcnow(),tick=0,initial_equity_eur=money(initial))
    db.add(run)
    db.commit()
    return run


def run_hour_tick(db, exp, run):
    """Atomic from the API caller's viewpoint; each checkpoint created once.
    Step uses deterministic fictional quote path, orders are genuine simulator fills.
    """
    if run.status!='RUNNING':return False
    if exp.status!='RUNNING':return False
    tick=run.tick+1
    if tick>12:return False
    for sym,base in DEMO_BASE.items():
        # Factors are percentage changes relative to the initial demo price.
        change=D(PRICE_CHANGES[sym][tick-1])/100
        quote_upsert(db,exp.id,sym,money(base*(1+change)),source='DEMO 1 heure (prix synthétiques)',quality='DEMO_FIXTURE')
    db.flush()
    leaderboard=ranked_traders(db,exp.id,as_of=run.started_at)
    leader=next((tr for tr in leaderboard if tr['eligible'] and tr['provenance']=='DEMO_FIXTURE'),None)
    events=[]
    for strategy,sym,action in DEMO_EVENTS.get(tick,[]):
        if strategy=='professional' and not leader:
            events.append({'strategy':strategy,'status':'SKIPPED','reason':'Aucun trader répondant au classement'})
            continue
        raw={'demo':True,'fictional_hour_tick':tick,'virtual_minute':tick*5,
             'fictional_trader_id':leader['trader_id'] if strategy=='professional' else None}
        s,duplicate=process_signal(db,exp,strategy,f'hour:{run.id}:tick:{tick}:{strategy}:{sym}:{action}',sym,action,
             source=('TOP TRADERS — PROFIL FICTIF '+leader['display_name'] if strategy=='professional'
                     else 'DEMO FICTIF — '+STRATEGIES[strategy]),raw=raw)
        events.append({'strategy':strategy,'symbol':sym,'action':action,'status':s.status,
                       'reason':s.reason,'trader_id':leader['trader_id'] if strategy=='professional' else None})
    portfolios=db.scalars(select(Portfolio).where(Portfolio.experiment_id==exp.id)).all()
    info=[value_portfolio(db,p) for p in portfolios]
    total=sum((D(p['equity_eur']) for p in info),D('0'))
    # Checkpoint time is the simulated timeline, not a claim that external market prices were observed then.
    started=run.started_at.replace(tzinfo=timezone.utc) if run.started_at.tzinfo is None else run.started_at
    db.add(HourCheckpoint(run_id=run.id,tick=tick,minute=tick*5,virtual_at=started+timedelta(minutes=tick*5),
        equity_eur=money(total),pnl_eur=money(total-D(run.initial_equity_eur)),
        portfolios_json=json.dumps([{k:v for k,v in p.items() if k in ('slug','label','equity_eur','cash_eur','pnl_eur')} for p in info],ensure_ascii=False),
        events_json=json.dumps(events,ensure_ascii=False),leader_id=leader['trader_id'] if leader else None))
    run.tick=tick
    if tick==12:
        run.status='COMPLETE'
        run.completed_at=utcnow()
    db.commit()
    return True


def execute_accelerated(db,exp):
    run=begin_hour(db,exp,mode='ACCELERATED')
    for _ in range(12):run_hour_tick(db,exp,run)
    return hour_status(db,exp.id)


def advance_realtime_hour(db):
    """Called by local FastAPI scheduler ~every 10 s. Never messages ChatGPT."""
    from .engine import current_experiment
    exp=current_experiment(db)
    if not exp or exp.mode!='DEMO' or exp.status!='RUNNING':return 0
    run=db.scalars(select(HourRun).where(HourRun.experiment_id==exp.id,HourRun.status=='RUNNING',HourRun.mode=='REALTIME').order_by(HourRun.id.desc())).first()
    if not run:return 0
    started=run.started_at.replace(tzinfo=timezone.utc) if run.started_at.tzinfo is None else run.started_at
    due=min(12,max(0,int((utcnow()-started).total_seconds()//300)))
    done=0
    if due-run.tick>1:
        # Interrupted server; never invent a sequence of real-time five-minute updates.
        run.status='INTERRUPTED'
        run.completed_at=utcnow()
        db.commit()
        return 0
    while run.tick<due:
        if not run_hour_tick(db,exp,run):break
        done+=1
    return done
