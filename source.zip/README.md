# CopyTrading 50 — laboratoire de copy trading (simulation uniquement)

Application utilisable **localement sans compte de courtage**, avec **50 € fictifs** répartis en **5 portefeuilles de 10 €** et une expérience de **60 jours**. Le backend est en Python/FastAPI et conserve toutes les opérations virtuelles dans SQLite. Une interface **immédiatement utilisable sans Node** est servie à `http://127.0.0.1:8000/`. Les sources d'un frontend React/TypeScript facultatif sont aussi incluses dans `frontend/` ; leur compilation nécessite npm (non vérifiée dans l'environnement de génération).

> **Aucune fonction d'ordre réel n'existe dans le code.** Ne pas utiliser cette application comme courtier ou comme système de trading réel. Les frais, fractions de titres, spreads et prix de clôture sont des hypothèses de simulation. Ce projet est éducatif et ne garantit aucun gain.

## Démarrage rapide

### Windows

Installer Python 3.12+, ouvrir l'archive extraite puis double-cliquer sur `start.bat`, ou l'exécuter dans un terminal. Ensuite ouvrir **http://127.0.0.1:8000**.

### macOS / Linux

```bash
cd copytrading-50
./start.sh
```

Ouvrir **http://127.0.0.1:8000**. Le premier démarrage peut installer les dépendances Python.

### Démarrage manuel

```bash
cd backend
python -m venv .venv
# Linux / macOS : source .venv/bin/activate
# Windows : .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Pour travailler avec les connecteurs, copier `.env.example` à `backend/.env` et remplir uniquement les valeurs appropriées. **Ne jamais utiliser de clés de trading réel.**

## Comment tester immédiatement

1. Cliquer **Démarrer la démo**.
2. Cliquer **Générer 5 achats fictifs**.
3. Voir les 5 portefeuilles, les positions et les ordres sur l'accueil.
4. Dans **Paramètres**, modifier le prix fictif de `NVDA` pour voir évoluer le portefeuille Pelosi.
5. Cliquer sur le portefeuille Pelosi, puis **Vendre virtuellement** pour observer le crédit de cash et le résultat.
6. Suspendre/reprendre via le bandeau de contrôle. Fermer le serveur et le relancer : l'état est conservé.

**Attention : toutes les transactions de cette procédure sont fictives**, n'ont pas été réalisées par de vrais traders et ne doivent jamais être présentées comme des performances de marché. Le simulateur utilise l'hypothèse optimiste de fractions arbitrairement petites, et non les minimums de commande d'un courtier particulier.

## Mode PAPER_LIVE_DATA (sources observées)

Démarrer une nouvelle expérience en **PAPER_LIVE_DATA**, séparée de la démo. Les paramètres externes restent à configurer. L'application **ne fait pas croire** que les sources sont branchées lorsqu'elles ne le sont pas.

| Stratégie | Module livré | Pour l'utiliser |
|---|---|---|
| Pelosi | Collecteur de CSV tiers public, détection et déduplication | Renseigner `PELOSI_CSV_URL` avec un flux CSV conforme ; première collecte initialise une référence et n'achète pas rétroactivement les transactions antérieures |
| Telegram | Telegram Bot API `getUpdates` (canal autorisé, messages `BUY/SELL SYMBOLE`) | Renseigner `TELEGRAM_BOT_TOKEN` et `TELEGRAM_CHANNEL_ID` ; bot autorisé à recevoir les publications. Les ordres complexes (SL/TP, modifications et signaux ambigus) ne sont **pas** encore automatisés |
| Trader professionnel | Webhook authentifié avec clé dédiée | Configurer `SOURCE_WEBHOOK_TOKEN` ; POST vers `/api/webhooks/professional` avec `X-Source-Token` ; doit être une source que vous contrôlez et dont vous connaissez la provenance |
| Fonds institutionnel | Import CSV d'événements explicites vérifiables | Configurer `INSTITUTIONAL_CSV_PATH`. Aucun calcul automatique des transactions à partir d'un rapport 13F n'a été implémenté |
| Polymarket | Carte, portefeuille fictif et module désactivé en externe | **Aucune collecte distante / exécution réelle**, en raison des restrictions locales ; disponible en mode DEMO uniquement |

### Format du webhook professionnel

```bash
curl -X POST http://127.0.0.1:8000/api/webhooks/professional \
  -H "Content-Type: application/json" \
  -H "X-Source-Token: VOTRE_CLE_SPECIFIQUE" \
  -d '{"external_id":"signal-123","symbol":"AAPL","action":"BUY","published_at":"2026-11-14T12:00:00Z","source_reference":"https://source.autorisee/exemple"}'
```

Dans `PAPER_LIVE_DATA`, **aucun signal n'est exécuté sans cotation EUR indépendante disponible.** Les cotations de démonstration sont interdites. Un fournisseur indicatif US Stooq + ECB est accessible via le dashboard Paramètres ou `POST /api/quotes/us/AAPL/refresh`. Ses cours sont des clôtures journalières potentiellement différées, avec spread/frais supposés : **ils ne représentent pas de véritables prix d'exécution**, encore moins des prix temps réel. Le fournisseur peut bloquer les requêtes ou être indisponible ; dans ce cas le bot doit refuser au lieu d'inventer un prix. Le programme ne gère pas encore les heures de marché, la liquidité réelle ou les minimums de titres par courtier.

### Source publique Pelosi (tierce)

L'intégration CSV prend en charge les colonnes de ce fournisseur tiers :

[CapitolStockWatch — GitHub et licence CC BY 4.0](https://github.com/MichaelBMiner/capitol-stock-watch-open-data)

URL publiée : `https://www.capitolstockwatch.com/data/open-data/congress_trades_latest.csv`.

Ce jeu de données est un **agrégateur tiers**, pas la base officielle de la House Clerk. Les déclarations officielles doivent être vérifiées séparément : https://disclosures-clerk.house.gov/. La première synchronisation constitue une base de référence ; seules les publications observées par la suite peuvent devenir des signaux. Aucun trade passé n'est backdaté.

### Prix indicatifs US

Stooq : https://stooq.com/ — séries de clôtures quotidiennes, accès susceptible d'être refusé. Taux ECB : https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml. Les cours ne sont pas en temps réel. Aucune exécution en argent réel n'est possible.

## API & sécurité

- OpenAPI : **http://127.0.0.1:8000/docs**
- Santé : `GET /api/health`
- Tableau de bord : `GET /api/dashboard`
- Démarrer : `POST /api/experiments/start` avec `{"mode":"DEMO"}` ou `{"mode":"PAPER_LIVE_DATA"}`
- Contrôles : `/api/experiments/pause`, `/api/experiments/resume`, `/api/experiments/complete`
- Signaux fictifs : `POST /api/demo/example`, `POST /api/demo/signal`
- Prix fictifs : `POST /api/demo/prices`
- Connecteurs : `POST /api/connectors/sync`

Le serveur écoute exclusivement **127.0.0.1** dans les scripts fournis. Pour une installation distante, mettre une authentification solide, HTTPS, filtrage réseau et un audit de sécurité avant exposition. `ADMIN_TOKEN` protège les endpoints mutables, mais le dashboard reste lisible en local ; n'exposez pas ce serveur directement sur Internet. Les secrets ne doivent pas être publiés.

## Tests

```bash
cd backend
python -m pytest -q
```

Les tests incluent : 5 × 10 €, achats/ventes virtuels, frais, persistance après redémarrage, duplication des signaux, signal périmé, suspension, rejet des prix DEMO en PAPER et authentification du webhook.

## Interface React facultative

Une interface React/TypeScript plus détaillée est disponible dans `frontend/`. Si npm a accès au registre :

```bash
cd frontend
npm install
npm run dev
```

Elle sera servie sur `http://127.0.0.1:5173` et transmettra `/api` au backend sur le port 8000. **Cette interface facultative n'a pas pu être compilée dans l'environnement de construction (installation npm bloquée par timeout).** L'interface autonome disponible au port 8000 ne nécessite aucune compilation.

## Limites connues — importantes

- Première version fonctionnelle, pas une copie exacte du code de la vidéo d'Aywen.
- Pas de téléchargement/extraction automatique de PDF Pelosi ou d'analyse complète des rapports 13F.
- Pas de catalogue de traders professionnels ; nécessite une source webhook autorisée.
- Signal Telegram simple uniquement ; pas d'interprétation avancée des stops / take-profits.
- Pas de Polymarket distant en raison des restrictions locales.
- Pas de système automatique de minimums de courtage, de données tick, de liquidité ou de carnet d'ordres ; fractions simulées potentiellement irréalistes.
- Frais/spread paramétrables arbitraires, résultats non comparables à des exécutions réelles.
- Aucune garantie de continuité si machine éteinte ; le scheduler local fonctionne seulement tant que le serveur tourne.
- Ne pas évaluer la rentabilité d'une stratégie à partir du mode DEMO.
- Les performances PAPER peuvent être incomplètes, car une source indisponible ou un prix absent entraîne un signal rejeté.

## Développement futur recommandé

Prix de marché licenciés et intrajournaliers, prise en charge des calendriers boursiers, minimas d'ordres par courtier, extracteurs officiels de déclarations, 13F complet, véritable analyse des mises à jour des signaux Telegram, tests de concurrence renforcés, snapshots/equity curve compressés et migration Alembic.

**Le mode réel est volontairement absent.**

---

## NOUVEAU v0.2 — Top Traders et simulation de 1 heure

Deux nouvelles pages existent dans l'**interface autonome FastAPI** :

- **Top Traders** : classement d'investisseurs sur historique *clôturé*, avec au moins 10 opérations, au moins 30 jours d'historique et drawdown maximal de 35 %. Score = rendement cumulé (borné) - 1,5 × drawdown max + bonus de régularité. Ce score est une règle de sélection **expérimentale**, pas une prédiction du prochain trade.
- **Suivi 1 heure** : un test **DEMO** de 12 étapes de 5 minutes, avec prix, signaux et profils entièrement fictifs. Deux modes : **accéléré** (les 12 étapes immédiatement) et **temps réel local** (12 contrôles toutes les 5 minutes, uniquement pendant que le serveur est lancé ; page rafraîchie automatiquement toutes les 10 secondes).

### Mode accéléré — exécution immédiate

1. Démarrer une expérience **DEMO**.
2. Ouvrir **Suivi 1 heure**.
3. Cliquer **Simuler 1 heure maintenant**.
4. Consulter les 12 points et le tableau des cinq portefeuilles.
5. Pour le classement fictif, ouvrir **Top Traders**.

Les événements Top Traders fictifs alimentent le portefeuille **Trader professionnel** existant (10 € virtuels). Il n'y a ni sixième portefeuille ni augmentation du capital de 50 €.

### Mode réel local — suivi à intervalle de 5 minutes

1. Démarrer une expérience **DEMO**.
2. Ouvrir **Suivi 1 heure**.
3. Cliquer **Démarrer 1 heure en temps réel (local)**.
4. **Laisser le serveur FastAPI allumé** pendant une heure. Le navigateur peut être fermé : les points sont enregistrés en SQLite.
5. Les nouvelles lignes apparaissent à +5, +10, ... +60 minutes, sous réserve du temps d'exécution (vérification toutes les ~10 s).

Si le serveur est éteint assez longtemps pour manquer plusieurs échéances, le test est marqué `INTERRUPTED` plutôt que de fabriquer rétrospectivement les points prétendument réalisés. Ce programme **n'envoie pas automatiquement de messages ChatGPT** toutes les cinq minutes ; le suivi se fait dans le tableau de bord local.

### Rapport de démonstration indépendant (sans lancer de serveur)

Après installation des dépendances Python :

```bash
python scripts/run_hour_demo.py
```

Cela produit `reports/simulation_1h_resultats.html`, `reports/simulation_1h_resultats.json` et une petite base `reports/simulation_demo.sqlite3`. Le script utilise un jeu de données **entièrement synthétique**, et ne contacte pas les bourses ni les traders.

### Copier des Top Traders à partir d'une source autorisée (PAPER uniquement)

Le module peut classer des **historiques fournis par l'administrateur**, mais ne prétend pas vérifier leur authenticité. Aucun annuaire automatisé de « personnes qui gagnent à chaque opération » n'existe dans ce projet.

Définir dans `backend/.env` :

```dotenv
TOP_TRADERS_HISTORY_CSV=/chemin/vers/historique.csv
TOP_TRADERS_APPROVED_IDS=trader_alpha,trader_beta
SOURCE_WEBHOOK_TOKEN=une_cle_longue_et_secrete
```

Le CSV doit contenir : `trader_id,display_name,trade_id,return_pct,closed_at,proof_url`. Les dates doivent comporter un fuseau (`Z` ou `+00:00`) et les trades être **clôturés**. L'import se fait dans une expérience `PAPER_LIVE_DATA` via `POST /api/top-traders/import` (avec `X-Admin-Token` si configuré). Ils sont toujours étiquetés `USER_SUPPLIED_UNVERIFIED` : **le classement ne certifie pas les résultats du fournisseur**.

Un adaptateur de source autorisée pourra envoyer les nouveaux achats et ventes à `POST /api/webhooks/top-trader` :

```bash
curl -X POST http://127.0.0.1:8000/api/webhooks/top-trader \
  -H 'Content-Type: application/json' \
  -H 'X-Source-Token: une_cle_longue_et_secrete' \
  -d '{"trader_id":"trader_alpha","external_id":"trade-001","symbol":"AAPL","action":"BUY","published_at":"2026-11-14T15:00:00Z","source_reference":"https://example.org/proof"}'
```

Un signal n'est accepté que si le trader est dans la liste approuvée **et** dans le Top 2 admissible calculé sur l'historique disponible à la date du signal, qu'une preuve HTTPS est fournie, et que le moteur de base accepte ses conditions financières. La présence d'un lien de preuve **ne constitue pas une validation automatique** de son contenu. Comme pour le reste du mode PAPER, sans cotation EUR indépendante le signal sera refusé. Le module utilise **uniquement** le portefeuille `professional` de 10 € virtuels. Il ne doit jamais servir pour exécuter des ordres réels.

### Limites importantes du nouveau module

- Les données de démonstration sont fictives ; le classement et les rendements ne désignent **aucun investisseur réel**.
- Un rendement historique élevé ne garantit pas de gagner sur les prochaines opérations. Même une stratégie célèbre peut perdre de l'argent.
- L'import CSV reste non vérifié par l'application ; la sélection est une méthode de filtrage expérimentale.
- Les vrais flux de transactions de traders nécessitent une source autorisée et un accès adapté, qui ne sont pas fournis dans l'archive.
- Le trading réel est toujours absent.

**Tests :** lancer `cd backend && python -m pytest -q`, y compris les contrôles du classement, des 12 points et des interruptions du serveur.
