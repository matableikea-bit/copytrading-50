# CopyTrading 50 V14.5 BRAIN — GitHub PAPER

La version V14.5 ajoute une vraie étape BRAIN (classement et taille
des entrées) et un contrôle EXECUTOR des coûts d’aller-retour aux
fonds de la V14.4. **Elle ne garantit ni gains ni rendement.**

## Rôles dans le code

- SCANNER / SCOUT : GeckoTerminal + DexScreener. Détecte et ordonne des tokens et pools Solana, sans couverture exhaustive.
- ANALYST : filtres de fraîcheur, liquidité, activité et FDV; vérifications RPC de la mint et des comptes concentrés.
- COPIER : récupère et déduplique les swaps des adresses publiques configurées via Helius.
- BRAIN : attribue un **score heuristique**, observant au plus trois variations historiques de 1/5/15 minutes quand elles existent. Classe les candidats et module la taille *dans* les plafonds RISK. **Ni IA prédictive ni probabilité de succès.**
- EXECUTOR / SNIPER : obtient deux devis Jupiter (aller/retour) et comptabilise les coûts estimés; ignore tout achat ne pouvant pas être chiffré.
- RISK : plafonds d’exposition, drawdown, limite journalière, pertes consécutives, protection des commandes incertaines.
- BANKER : stops, ventes partielles, trailing, clôture en fin de session quand une sortie est cotable.

## Comment installer sur ton GitHub

Méthode mobile (fichier autonome) : créer
`.github/workflows/copytrading-brain-v145.yml`
dans le dépôt GitHub puis copier le contenu de
`Copier-Dans-GitHub-V14.5-BRAIN-AUTONOME.yml`.
Il contient le code compressé et **ne télécharge aucune source à l’exécution**.
Ne remplace pas le workflow V14.4 déjà en cours.

Après l’enregistrement, ouvrir **Actions -> CopyTrading 50 V14.5 BRAIN -> Run workflow**
et choisir 2min pour valider les clés et la surveillance, puis 10h/12h.
Les variables GitHub utilisées sont :
`SIM_WALLETS_JSON` (JSON d’adresses publiques Solana),
`HELIUS_API_KEY` et `JUPITER_API_KEY` (GitHub Actions secrets).
**Aucune clé privée de wallet n’est demandée.**

### Vérifications locales

```sh
python3 -m unittest discover -s tests -q
python3 -m compileall -q bot
```

Le workflow bloque le mode LIVE. Il enregistre des checkpoints
`checkpoint-stage-1`, `checkpoint-stage-2`, `checkpoint-stage-3-final`,
avec `docs/resultats.html`, `docs/status.json`, `docs/performance.json`,
`docs/trades.csv` et la base SQLite. Les résultats sont **des simulations**.

Le fichier `docs/performance.json` contient désormais la moyenne des scores
BRAIN lors des entrées et l’estimation moyenne du coût aller-retour
EXECUTOR, en plus des performances et des transactions.

### Limites réelles

- Le score BRAIN n’est pas une probabilité de gains, ni un backtest.
- Pas de confirmation des gains affichés sur les vidéos promotionnelles.
- Les quatre wallets éventuellement sélectionnés n’ont pas été audités ici
  et peuvent fermer des positions avant l’échantillonnage de 60 secondes.
- Les entrées sont limitées au plus à 8 % du portefeuille (4 USDC
  sur 50 USDC), l’exposition simultanée à 24 % (12 USDC initialement).
- Un achat + une vente sont simulés avec 0,10 USDC chacun de coût réseau
  hypothétique, **en plus** des coûts et spreads du devis Jupiter.
  18 allers-retours à 0,20 USDC représenteraient déjà 3,60 USDC
  (7,2 % du capital de départ) de coûts hypothétiques; ces 18 opérations
  ne sont pas un pronostic de fréquence.
- La valeur de sortie calculée sur Jupiter est une estimation, pas un swap confirmé.
- Les sessions 10/12 h n’ont pas été validées en conditions réelles sur cette version.

**Le lancement GitHub V14.4 en cours doit terminer avant de tester V14.5.**
