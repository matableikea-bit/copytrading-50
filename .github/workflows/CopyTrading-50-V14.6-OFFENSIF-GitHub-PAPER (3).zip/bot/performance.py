"""Audit a completed or in-progress V14 session, without inventing gains."""
from __future__ import annotations
import argparse
import csv
from decimal import Decimal
import json
from pathlib import Path
from statistics import mean
import sys
from .settings import D
from .store import Store


def summarize(state,stats):
    groups={};completed=set();buy_count=0
    cost_paper=D(0)
    brain_entry_scores=[]
    executor_cost_estimates=[]
    for t in state['trades']:
        if t['side']=='BUY':
            buy_count+=1
            score=(t.get('brain') or {}).get('brain_score')
            if score is not None:brain_entry_scores.append(D(score))
            estimated_cost=(t.get('executor_preflight') or {}).get('all_in_roundtrip_cost_fraction')
            if estimated_cost is not None:executor_cost_estimates.append(D(estimated_cost))
        cost_paper+=D(t.get('paper_network_cost_usdc') or 0)
        if t['side']=='SELL':
            pid=t.get('position_id',t['mint'])
            x=groups.setdefault(pid,{'mint':t['mint'],'source':t.get('source','UNKNOWN'),
                                     'pnl':D(0),'sale_count':0})
            x['pnl']+=D(t['realized_pnl_usdc']);x['sale_count']+=1
            if t.get('position_fully_closed',True):completed.add(pid)
    closed=[v for k,v in groups.items() if k in completed]
    wins=[p['pnl'] for p in closed if p['pnl']>0]
    losses=[p['pnl'] for p in closed if p['pnl']<0]
    values=[p['pnl'] for p in closed]
    by_source={}
    for p in closed:
        key=p['source']
        if key not in by_source:by_source[key]={'closed_positions':0,'realized_pnl_usdc':D(0)}
        by_source[key]['closed_positions']+=1
        by_source[key]['realized_pnl_usdc']+=p['pnl']
    return {'mode':state['mode'],'start_capital_usdc':state['starting_usdc'],
            'session_start_unix':state['created_at'],'session_end_unix':state['expires_at'],
            'positions_fully_closed':len(closed),'current_open_positions':len(state['positions']),
            'buy_executions':buy_count,'sell_executions':sum(p['sale_count'] for p in groups.values()),
            'winning_positions':len(wins),'losing_positions':len(losses),
            'closed_position_win_rate_percent':str(D(len(wins))*100/D(len(closed))) if closed else None,
            'closed_position_average_net_pnl_usdc':str(sum(values,D(0))/D(len(values))) if values else None,
            'best_closed_position_net_usdc':str(max(values)) if values else None,
            'worst_closed_position_net_usdc':str(min(values)) if values else None,
            'realized_pnl_usdc':str(sum((p['pnl'] for p in groups.values()),D(0))),
            'paper_network_costs_assumed_usdc':str(cost_paper),
            'mean_brain_score_at_entry':str(sum(brain_entry_scores,D(0))/len(brain_entry_scores)) if brain_entry_scores else None,
            'mean_executor_estimated_roundtrip_cost_percent':str(sum(executor_cost_estimates,D(0))*100/len(executor_cost_estimates)) if executor_cost_estimates else None,
            'sources':{k:{'closed_positions':v['closed_positions'],
                          'realized_pnl_usdc':str(v['realized_pnl_usdc'])} for k,v in by_source.items()},
            'decisions':stats,
            'limitations':['No external historical backtest','LIVE P&L excludes SOL gas/rent',
                            'Win rate uses completed positions, not partial sales',
                            'BRAIN score is heuristic, not a forecast or win probability',
                            'USDC is USD-pegged, not EUR; dollar depeg risk not modeled']}


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--db',default='runtime/v14.sqlite')
    parser.add_argument('--out',default='docs/performance.json')
    parser.add_argument('--trades-csv',default='docs/trades.csv')
    args=parser.parse_args(argv)
    if not Path(args.db).exists():parser.error('No run database. Start the bot first.')
    store=Store(args.db)
    state=store.get('portfolio')
    if not state:parser.error('No portfolio in database')
    report=summarize(state,store.stats())
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    csvpath=Path(args.trades_csv);csvpath.parent.mkdir(parents=True,exist_ok=True)
    keys=['time','side','symbol','mint','position_id','source','source_wallet',
          'qty','spent_usdc','proceeds_usdc','realized_pnl_usdc',
          'reason','chain_tx_signature','mode','brain','executor_preflight']
    with csvpath.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore')
        writer.writeheader();writer.writerows(state['trades'])
    store.close()
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
