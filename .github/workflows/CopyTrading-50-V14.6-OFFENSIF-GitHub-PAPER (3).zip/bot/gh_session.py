"""Run a reproducible PAPER simulation in separate GitHub Actions jobs.

GitHub-hosted jobs have a 6 hour limit. A 10h/12h session is split
into three jobs with an SQLite checkpoint passed as an artifact.
Never sends real orders: refuses LIVE configuration and trading flags.
"""
from __future__ import annotations

import argparse
import hashlib
from dataclasses import asdict
import csv
import json
import os
from pathlib import Path
import signal
import sys
import time
from datetime import datetime, timezone

from .performance import summarize
from .runner import Bot, singleton, write_report
from .settings import Config
from .profiles import apply_profile
from .store import Store


SESSION_SECONDS = {'2min': 120, '10h': 10 * 3600, '12h': 12 * 3600}


def segment_seconds(session: str, stage: int) -> int:
    """Return the stage's execution budget, excluding a closing grace period."""
    if session not in SESSION_SECONDS:
        raise ValueError('session must be 2min, 10h or 12h')
    if not 1 <= stage <= (1 if session == '2min' else 3):
        raise ValueError('invalid stage for session')
    return SESSION_SECONDS[session] if session == '2min' else SESSION_SECONDS[session] // 3


def prepare_config(path: str, wallet_env: str | None = None) -> Config:
    """Use public-only, PAPER-only settings. Wallets are an optional JSON list."""
    cfg = Config.load(path)
    if cfg.mode != 'PAPER':
        raise ValueError('GitHub simulation only accepts mode=PAPER')
    if os.getenv('ENABLE_LIVE_TRADING') or os.getenv('LIVE_TRADING_CONFIRMATION'):
        raise ValueError('Remove all LIVE flags from the simulation job')
    if wallet_env and wallet_env.strip():
        wallets = json.loads(wallet_env)
        if not isinstance(wallets, list):
            raise ValueError('SIM_WALLETS_JSON must be a JSON list of Solana wallet addresses')
        cfg.trader_wallets = wallets
        cfg.validate()
    return apply_profile(cfg, os.getenv('PAPER_PROFILE', 'standard'),
                         os.getenv('PAPER_CAPITAL', str(cfg.starting_usdc)))


def append_summary(report: dict, stage: int, session: str, path: str | None = None) -> None:
    """Write a simple GitHub Actions summary without printing private secrets."""
    out = path or os.getenv('GITHUB_STEP_SUMMARY')
    if not out:
        return
    equity = report.get('equity_estimate_usdc')
    equity_text = str(equity) if equity is not None else 'indisponible (cotation manquante)'
    pnl = report.get('pnl_estimate_usdc')
    pnl_text = str(pnl) if pnl is not None else 'indisponible'
    data = (
        f'### CopyTrading 50 — simulation {session}, étape {stage}\n\n'
        f'- Mode : **PAPER uniquement**\n'
        f'- Capital initial : **{report.get("starting_balance_usdc")} USDC**\n'
        f'- Profil : **{report.get("strategy_profile", "standard")}**\n'
        f'- Équité estimée : **{equity_text} USDC**\n'
        f'- P&L estimé : **{pnl_text} USDC**\n'
        f'- Positions ouvertes : **{len(report.get("positions", []))}**\n'
        f'- Achats : **{report.get("session_buy_entries", 0)}**\n'
        f'- BRAIN actif : **{report.get("brain_enabled", False)}**\n'
        f'- Arrêt du moteur : **{report.get("halted", False)}**\n\n'
        'Ces résultats sont simulés : aucune rentabilité n’est garantie. '
        'Consulter les artifacts pour la base et les rapports.\n\n'
    )
    with open(out, 'a', encoding='utf-8') as fh:
        fh.write(data)


def write_performance(db: str, performance_path: str, trades_path: str) -> None:
    """Generate audited results and trade CSV from the last SQLite checkpoint."""
    store = Store(db)
    try:
        state = store.get('portfolio')
        if state is None:
            raise ValueError('missing saved portfolio')
        summary = summarize(state, store.stats())
        output = Path(performance_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        tmp = output.with_suffix(output.suffix + '.tmp')
        tmp.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
        tmp.replace(output)
        path = Path(trades_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        keys = ['time', 'side', 'symbol', 'mint', 'position_id', 'source',
                'source_wallet', 'qty', 'spent_usdc', 'proceeds_usdc',
                'realized_pnl_usdc', 'reason', 'chain_tx_signature', 'mode']
        with path.open('w', encoding='utf-8', newline='') as fd:
            writer = csv.DictWriter(fd, fieldnames=keys, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(state['trades'])
    finally:
        store.close()


def run_stage(cfg: Config, *, session: str, stage: int, db_path: str,
              report_path: str, run_id: str = '', max_ticks: int = 0,
              monotonic=time.monotonic, wall_clock=time.time, sleep=time.sleep,
              bot_factory=Bot) -> dict:
    """Run one time-bounded stage. A new stage always resumes the same portfolio.

    `max_ticks` is for deterministic local tests; not used by GitHub runs.
    """
    seconds = segment_seconds(session, stage)
    db_file = Path(db_path)
    if stage == 1 and db_file.exists():
        raise ValueError('stage 1 refuses an existing database; start a fresh run')
    if stage > 1 and not db_file.exists():
        raise ValueError('missing checkpoint from previous GitHub Actions job')

    config_signature = hashlib.sha256(json.dumps(asdict(cfg), sort_keys=True).encode()).hexdigest()
    report = None
    with singleton(str(db_file) + '.lock'):
        store = Store(str(db_file))
        try:
            meta = store.get('github_session_meta')
            if stage == 1:
                if meta is not None:
                    raise ValueError('session already initialized')
                meta = {'session': session, 'run_id': str(run_id), 'last_stage': 0,
                        'config_signature': config_signature}
                store.put('github_session_meta', meta)
            else:
                if not isinstance(meta, dict) or meta.get('session') != session:
                    raise ValueError('checkpoint session does not match selected duration')
                if meta.get('run_id') != str(run_id):
                    raise ValueError('checkpoint belongs to another GitHub Actions run')
                if meta.get('config_signature') != config_signature:
                    raise ValueError('configuration changed between GitHub stages')
                if meta.get('last_stage') != stage - 1:
                    raise ValueError('checkpoint stage order is invalid')
            bot = bot_factory(cfg, store)
            if stage == 1 and session == '2min':
                bot.state['expires_at'] = int(wall_clock()) + SESSION_SECONDS['2min']
                store.put('portfolio', bot.state)

            deadline = monotonic() + seconds
            # Last stage gets a brief chance to close PAPER positions once the
            # session has expired. Unquotable positions remain clearly open.
            last_stage = stage == (1 if session == '2min' else 3)
            if last_stage:
                deadline += 180
            count = 0
            while True:
                try:
                    report = bot.tick()
                    report['strategy_profile'] = cfg.strategy_profile
                    write_report(report, report_path)
                    print(json.dumps({
                        'stage': stage, 'session': session,
                        'time': report.get('timestamp_utc'),
                        'equity_usdc': report.get('equity_estimate_usdc'),
                        'pnl_usdc': report.get('pnl_estimate_usdc'),
                        'positions': len(report.get('positions', [])),
                        'buys': report.get('session_buy_entries', 0),
                        'halted': report.get('halted', False),
                        'reason': report.get('halt_reason', ''),
                    }), flush=True)
                except Exception:
                    # Never continue submitting decisions after an unknown fault;
                    # checkpoint state is preserved for inspection.
                    bot.state['halted'] = True
                    bot.state['halt_reason'] = 'github_stage_unhandled_error'
                    store.put('portfolio', bot.state)
                    raise
                count += 1
                if max_ticks and count >= max_ticks:
                    break
                if last_stage and bot.state.get('halt_reason') == 'session_complete' and not bot.state['positions']:
                    break
                remaining = deadline - monotonic()
                if remaining <= 0:
                    break
                sleep(min(cfg.poll_seconds, remaining))
            store.put('github_session_meta', {**meta, 'last_stage': stage})
            store.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        finally:
            store.close()
    if report is None:
        raise RuntimeError('simulation stage produced no report')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description='GitHub Actions staged PAPER simulation')
    parser.add_argument('--stage', type=int, required=True)
    parser.add_argument('--session', choices=SESSION_SECONDS, required=True)
    parser.add_argument('--config', default='config.json')
    parser.add_argument('--db', default='runtime/github-session.sqlite')
    parser.add_argument('--report', default='docs/status.json')
    parser.add_argument('--performance', default='docs/performance.json')
    parser.add_argument('--trades', default='docs/trades.csv')
    parser.add_argument('--max-ticks', type=int, default=0,
                        help='local tests only; not set by GitHub Actions')
    args = parser.parse_args(argv)
    cfg = prepare_config(args.config, os.getenv('SIM_WALLETS_JSON'))
    if args.session == '2min':
        cfg.session_hours = 1  # Bot will use the persisted 2-minute expiry
    else:
        cfg.session_hours = int(args.session[:-1])
    cfg.validate()
    try:
        report = run_stage(cfg, session=args.session, stage=args.stage,
                           db_path=args.db, report_path=args.report,
                           run_id=os.getenv('GITHUB_RUN_ID', 'local'),
                           max_ticks=args.max_ticks)
        write_performance(args.db, args.performance, args.trades)
        append_summary(report, args.stage, args.session)
        print(f'PAPER stage {args.stage} checkpoint saved: {args.db}', flush=True)
    except Exception as ex:
        print(f'SIMULATION FAILED CLOSED: {type(ex).__name__}: {ex}', file=sys.stderr, flush=True)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
