"""Auditable PAPER risk presets. A larger target is never a return forecast."""
from __future__ import annotations
from .settings import Config

OFFENSIF = {
    'strategy_profile': 'offensif',
    'max_trade_fraction': '0.18',
    'max_single_token_fraction': '0.18',
    'max_total_exposure_fraction': '0.50',
    'max_open_positions': 3,
    'max_daily_loss_fraction': '0.12',
    'max_drawdown_fraction': '0.20',
    'stop_loss_fraction': '0.15',
    'take_profit_fraction': '2.0',   # close a position at +200% net, if quoted
    'partial_take_profit_fraction': '0.60',
    'partial_take_profit_sell_fraction': '0.25',
    'trailing_activation_fraction': '0.45',
    'trailing_gap_fraction': '0.22',
    'max_hold_minutes': 180,
    'max_trades_per_session': 12,
    'min_liquidity_usd': '50000',
    'min_volume_5m_usd': '5000',
    'max_round_trip_loss_fraction': '0.05',
    'max_all_in_round_trip_loss_fraction': '0.06',
    'scout_signal_threshold': 82,
    'brain_enabled': True,
}


def apply_profile(cfg: Config, name: str, capital: str) -> Config:
    """Only PAPER supports experimental presets; never turns on real orders."""
    if name not in ('standard', 'offensif'):
        raise ValueError('unknown PAPER profile')
    if capital not in ('50', '100'):
        raise ValueError('PAPER capital must be 50 or 100 USDC')
    if cfg.mode != 'PAPER':
        raise ValueError('profiles are PAPER only')
    if name == 'offensif':
        for field, value in OFFENSIF.items():
            setattr(cfg, field, value)
    else:
        cfg.strategy_profile = 'standard'
    cfg.starting_usdc = capital
    cfg.validate()
    return cfg
