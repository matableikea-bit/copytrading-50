"""Build a standalone HTML dashboard from the PAPER report for GitHub artifacts."""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def build_snapshot(report: dict, template: str) -> str:
    """Embed a data snapshot safely; no server, keys or external JS needed."""
    marker = 'async function refresh(){'
    if marker not in template:
        raise ValueError('dashboard refresh function not found')
    header, _ = template.split(marker, 1)
    data = json.dumps(report, ensure_ascii=True, separators=(',', ':'))
    # JS string values could include </script> (e.g., malicious token symbol).
    # Encode HTML-significant chars before embedding as a JS object literal.
    data = data.replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    header = header.replace('V14.3', 'V14.5').replace(
        'Tableau de bord local : lecture de <code>status.json</code> toutes les 10 secondes.',
        'Rapport statique GitHub Actions : photographie à la fin de cette étape.')
    return (header + '\n// Snapshot of an actual PAPER run; never an invented performance.\n'
            'const SNAPSHOT_REPORT = ' + data + ';\n'
            'update(SNAPSHOT_REPORT);\n'
            '</script>\n</body></html>\n')


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--report', default='docs/status.json')
    p.add_argument('--template', default='docs/index.html')
    p.add_argument('--out', default='docs/resultats.html')
    args = p.parse_args(argv)
    path = Path(args.report)
    if not path.exists():
        print('No PAPER report yet; skipping static snapshot')
        return
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('mode') != 'PAPER':
        raise ValueError('cannot package a non-PAPER report')
    html = build_snapshot(data, Path(args.template).read_text(encoding='utf-8'))
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding='utf-8')
    print(f'Offline dashboard: {output}')


if __name__ == '__main__':
    main()
