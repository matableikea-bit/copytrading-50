"""BRAIN: rank the *observed* setup and size within existing RISK caps.

The score is a deterministic heuristic, not a calibrated probability or
expected return. Only historical observations at/before `now` may contribute.
Never increases an order beyond the existing per-position risk budget.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from .settings import D
from .risk import scout_score


@dataclass(frozen=True)
class Assessment:
    score: int
    fraction_of_risk_budget: Decimal
    source: str
    timeframe_returns: dict[str, str | None]
    comments: tuple[str, ...]

    def as_dict(self) -> dict:
        return {
            'brain_score': self.score,
            'fraction_of_risk_budget': str(self.fraction_of_risk_budget),
            'source': self.source,
            'timeframe_returns': self.timeframe_returns,
            'comments': list(self.comments),
            'is_return_prediction': False,
        }


def _timeframe_return(m, store, now: int, seconds: int):
    """Only compare a fresh market mark to a bounded, past observation."""
    if m.price_usd <= 0 or m.observed_at > now or now-m.observed_at > 120:
        return None
    snapshot = store.earlier(m.mint, now, seconds)
    if not snapshot or snapshot['price'] <= 0:
        return None
    # A quote that is far older than the requested horizon is not evidence
    # for that horizon (e.g. after a long API outage).
    if snapshot['ts'] < now-seconds-max(90, seconds//3):
        return None
    return m.price_usd/snapshot['price']-1


def assess(market, store, now: int, *, source='SCOUT', enabled=True) -> Assessment:
    base, _ = scout_score(market, now)
    if not enabled:
        return Assessment(base,D(1),source,{'1m':None,'5m':None,'15m':None},('brain_disabled_risk_only',))
    score=base
    comments=[]
    signals={}
    for label,seconds in (('1m',60),('5m',300),('15m',900)):
        pct=_timeframe_return(market,store,now,seconds)
        signals[label]=str(pct) if pct is not None else None
        if pct is None:
            comments.append(label+'_insufficient_history')
            continue
        if label=='1m':
            if D(0)<=pct<=D('.06'):score+=3
            elif pct < D('-.05') or pct>D('.15'):score-=6
        elif label=='5m':
            if D('.01')<=pct<=D('.12'):score+=5
            elif pct<D('-.10') or pct>D('.30'):score-=8
        else:
            if D('-.03')<=pct<=D('.25'):score+=4
            elif pct<D('-.12') or pct>D('.50'):score-=6
    # A score never overrides liquidity/RPC/fee filters. It only orders and
    # sizes eligible opportunities. Full confidence still caps at RISK budget.
    score=max(0,min(100,score))
    fraction=(D(1) if score>=90 else
              D('.90') if score>=75 else
              D('.75') if score>=60 else D('.60'))
    return Assessment(score,fraction,source,signals,tuple(comments))


def size_within_budget(risk_budget, assessment: Assessment, minimum):
    """Preserve a pre-approved risk cap and the venue's minimum notional."""
    allowed=D(risk_budget)
    if allowed<=0:return D(0)
    tentative=allowed*assessment.fraction_of_risk_budget
    if tentative<D(minimum):
        return D(minimum) if allowed>=D(minimum) else D(0)
    return min(tentative,allowed)
