"""EXECUTOR: check the quoted USDC round trip before any order.

This calculation checks costs but does not guarantee a future fill.
"""
from __future__ import annotations
from .settings import D
from .providers import DataUnavailable


def check_roundtrip(amount_usdc, token_amount, reverse_quote, buy_quote, cfg):
    amount=D(amount_usdc)
    if amount<=0 or int(token_amount)<=0:raise DataUnavailable('invalid_entry_notional')
    fee=max(int(buy_quote.get('feeBps') or 0),int(reverse_quote.get('feeBps') or 0))
    if fee>cfg.max_jupiter_fee_bps:raise DataUnavailable('swap_fees_too_high')
    back=D(reverse_quote['outAmount'])/D(1_000_000)
    if back<=0:raise DataUnavailable('exit_quote_nonpositive')
    loss=D(1)-back/amount
    if loss>D(cfg.max_round_trip_loss_fraction):
        raise DataUnavailable('roundtrip_slippage_or_fee_too_high')
    gas=D(cfg.paper_network_cost_usdc)
    total=amount+gas
    net=back*(D(1)-D(cfg.paper_extra_slippage_fraction))-gas
    full_loss=(total-net)/total
    if net<=0 or full_loss>D(cfg.max_all_in_round_trip_loss_fraction):
        raise DataUnavailable('all_in_roundtrip_cost_too_high')
    return {'quoted_return_usdc':str(back),
            'net_exit_quote_usdc':str(net),
            'all_in_roundtrip_cost_fraction':str(full_loss),
            'max_quote_fee_bps':fee,
            'quotes_are_not_fills':True}
