# CopyTrading 50 V14.6 OFFENSIF — PAPER ONLY

Version autonome de simulation Solana avec SCANNER/SCOUT, ANALYST, BRAIN, COPIER, EXECUTOR/SNIPER, RISK et BANKER.

La V14.6 ajoute un profil **OFFENSIF expérimental** avec une exposition plus importante et des objectifs de prise de bénéfice plus hauts. Ce réglage **n'augmente pas de manière démontrée la probabilité de bénéfice** ; les pertes peuvent être plus élevées. Les agents, Helius, DexScreener, GeckoTerminal, Jupiter, la comptabilité, les stops, les ventes partielles et les rapports sont conservés.

Les gains fictifs ne sont pas des résultats on-chain ni des résultats futurs. Aucun ordre réel n'est envoyé dans GitHub.

Voir [README_OFFENSIF.md](README_OFFENSIF.md) pour les paramètres et [GITHUB_INSTALL.md](GITHUB_INSTALL.md) pour l'installation. Tous les secrets restent dans les GitHub Actions Secrets.

Validation : `python3 -m unittest discover -s tests -q`.

---

# CopyTrading 50 V14.4 — Simulation GitHub Actions PAPER

**NOUVEAU :** lancer une session de **2 minutes (test), 10 heures ou 12 heures depuis l’onglet Actions de GitHub**. Source du bot et des tests dans ce dossier, workflow dans `.github/workflows/copytrading-paper.yml`. Lire **[GITHUB_INSTALL.md](GITHUB_INSTALL.md)** pour l’installation. Le workflow conserve le portefeuille SQLite entre trois étapes et exporte `resultats.html`, `performance.json`, `trades.csv`.

**PAPER uniquement : aucun ordre réel, aucune rentabilité garantie.** La session suppose des API publiques accessibles. Les 10/12 h n’ont pas été exécutées sur GitHub à la livraison.

---

# CopyTrading 50 V14.3 — Solana SCOUT / ANALYST / COPIER / SNIPER / RISK / BANKER

**Important : ce logiciel n'a pas démontré de rentabilité. Aucun rendement n'est garanti. Un memecoin peut perdre 100 % de sa valeur et un stop-loss peut ne pas s'exécuter.**

V14.3 est un **projet autonome**, distinct des premières itérations V12/V13. Il reproduit **la logique observée** dans les captures Grok Bot (copy.top / pump.fun), **pas les profits promotionnels affichés dans ces vidéos**.

## Mise à jour V14.3 — opportunités en priorité, moins d'arrêts inutiles

Cette version corrige des interruptions non nécessaires, sans rendre les achats aveugles :

1. **SCOUT classe d'abord les candidats** selon le score et le momentum observé ; une API ne décide plus de la priorité par son ordre de réponse. C'est une méthode de tri, **pas une prédiction de gain**.
2. Une panne de découverte ou de cotation **met l'entrée concernée en pause**, puis les cycles suivants réessayent automatiquement. Une valeur de portefeuille inconnue ne se transforme ni en zéro fictif ni en arrêt irréversible.
3. **COPIER reste indépendant du scanner** : un swap frais d'un wallet suivi peut être copié si une cotation de marché indépendante et tous les contrôles nécessaires sont disponibles, même pendant la panne du scanner.
4. Le quota `max_trades_per_session` compte les **achats uniquement**, afin que les ventes partielles ou les sorties défensives ne retirent pas artificiellement des opportunités futures.
5. Après une série de pertes, la stratégie concernée peut reprendre **après `strategy_cooldown_seconds`** (défaut : 1 800 secondes) plutôt que rester bloquée définitivement. Les limites de pertes globales et les ordres LIVE incertains conservent leur arrêt dur.
6. `docs/status.json` distingue maintenant `scout_paused`, `quote_data_ready` et `buying_paused` de `halted`. Le mode LIVE reste expérimental.

**Aucune nouvelle méthode de profit n'est démontrée** : le classement, les pauses et la reprise sont des améliorations logicielles. Le programme n'a pas été exécuté 12 heures sur les marchés dans cet environnement, et ses tests utilisent des fournisseurs simulés. Si le scanner ne détecte pas de signal valide, il ne faut pas fabriquer un trade.

**Pour vérifier cette livraison :**

```bash
python3 -m unittest discover -s tests -q
python3 -m compileall -q bot
python3 -m bot --config config.json --once
```

La troisième commande requiert une connexion aux API publiques et peut échouer proprement sans elle. Aucun compte Kraken ou clé privée n'est demandé pour les tests.

---

## V14.3 — copie des mécanismes vus dans les vidéos

Les vidéos montrent principalement : **Solana/pump.fun et les nouveaux memecoins**, **copy.top** avec six traders sélectionnés, **SCOUT, ANALYST, COPIER, SNIPER, RISK et BANKER**, des entrées très courtes et des ventes automatiques. **Ce sont des interfaces promotionnelles, pas des données de trades indépendamment vérifiées.** Les montants « +61 % » et « x10 » ne sont pas des gains reproductibles prouvés.

La V14.3 applique les mécanismes **observables et testables**, pas les soldes de l'interface :

- Découverte de tokens Solana (GeckoTerminal + DexScreener), analyse de liquidité/activité/mint et de plusieurs observations de prix.
- Copie des swaps confirmés de **wallets Solana explicitement configurés**, via Helius (pas de copie directe des pseudos des vidéos ; une adresse réelle est nécessaire).
- Achat limité à **8 % de l'équité** ; devis Jupiter achat et vente, rejet lorsque le coût d'aller-retour excède les limites.
- **BANKER V14.3 : prise de bénéfices partielle** quand la **valorisation de liquidation Jupiter nette estimée** dépasse le coût de 25 % ; vente de 50 % de la position, puis trailing et stop sur le reste. Le take-profit total à +60 % reste prioritaire. Ce sont des valeurs configurables dans `bot/settings.py`.
- Rattrapage des ventes de wallets après panne : les achats trop anciens sont ignorés, mais les ventes retardées peuvent protéger une position déjà copiée.
- Reprise SQLite robuste même si un wallet n'avait aucune transaction au tout premier relevé, et recalage des pics de liquidation après chaque vente partielle.
- Une **sortie Jupiter** peut encore être tentée si DexScreener perd la fiche du token, tant que Jupiter offre un devis valable.
- Interface de surveillance : rôles, positions, devis de liquidation, signalements des wallets suivis et journal des opérations. Aucun faux « top trader » n'est inséré par défaut.

**Différences avec les vidéos :** pas de copie directe de l'interface privée de copy.top, pas de classement de traders validé, pas de latence de 0,4 s (polling de 60 s), pas de flux confirmé en conditions réelles dans cet environnement, et **aucune rentabilité établie**. Le scanner ne couvre pas toutes les paires nouvelles ; une stratégie peut ne faire aucune opération.

**Pour lancer une session de 10 heures** (PAPER) :

```bash
python3 -m bot --config examples/config-10h.json --db runtime/session-10h.sqlite --report docs/status.json
```

**Pour lancer une session de 12 heures** (PAPER) :

```bash
python3 -m bot --config config.json --db runtime/session-12h.sqlite --report docs/status.json
```

Le bot fonctionne uniquement quand le processus tourne sur un ordinateur/VPS ; ce chat ne le lance pas à distance. Avec `trader_wallets: []`, il détecte des tokens mais **ne copie aucun wallet**. Le système PAPER ne prend jamais d'argent sur un compte. Le connecteur LIVE est expérimental, non audité et désactivé par défaut : il ne doit pas être considéré comme prêt pour des fonds réels.

---

## 1. Ce qui existe réellement dans V14.3

| Agent | Ce qu'il fait en code | Limite importante |
|---|---|---|
| SCOUT | Interroge les nouveaux pools Solana via GeckoTerminal **et** les dernières fiches DexScreener, puis suit leur prix en observations espacées | Ce n'est **pas** un scanner exhaustif de 5 000 paires ; les flux sont paginés ou limités, les fiches DexScreener peuvent être promotionnelles |
| ANALYST | Analyse volume 5 min, nombre d'achats/ventes, liquidité, ancienneté du pool, variations, capitalisation, autorités de mint/freeze et concentration par comptes | Ces tests ne garantissent pas que le token soit vendable ou qu'il ne soit pas malveillant |
| COPIER | Lit les **swaps réels** des adresses Solana explicitement sélectionnées via Helius, distingue BUY/SELL, refuse de copier l'historique lors de la première connexion, déduplique les signatures | Nécessite une clé Helius ; seulement les swaps non ambigus et initiés par le portefeuille ciblé sont retenus ; certaines opérations pump.fun peuvent ne pas être décodées |
| SNIPER | Interroge le Swap API V2 de Jupiter, vérifie l'aller-retour USDC/token et peut préparer et soumettre un swap si le mode LIVE est activé | **Pas de latence 235 ms :** polling de 60 s par défaut, API publiques et réseau variable |
| RISK | Limite taille, nombre de positions, drawdown, perte journalière et transactions ; arrête les achats en cas d'erreur de flux ou ordre incertain | Le risque zéro n'existe pas ; la liquidité peut disparaître avant l'ordre de sortie |
| BANKER | Stop-loss, trailing stop, objectif de vente, sortie par durée ou à la fin de la session ; vente PAPER via cotation Jupiter, LIVE via transaction | Ne garantit pas un prix de sortie, et les arrêts ne fonctionnent que si le bot et ses API fonctionnent |

**Autres marchés :** `python -m bot.monitors` interroge en lecture seule BTC/EUR sur Kraken, Coinbase et Binance. `monitor_base` peut vérifier des contrats Base fournis. Il n'y a **pas** de trading LIVE Base/CEX dans cette version. Les priorités sont les memecoins **Solana**, car c'est ce que montrent les vidéos.

## 2. Installation et lancement en simulation (aucun dépôt nécessaire)

Python **3.10+** ; en mode PAPER, seulement la bibliothèque standard Python.

```bash
unzip CopyTrading-50-V14.3-reprise-classement-PAPER.zip
cd copytrading-v14.3
python3 -m unittest discover -s tests -v
python3 -m bot --config config.json --db runtime/v14.sqlite --report docs/status.json
```

Le programme démarre une **session de 12 heures**, analyse automatiquement environ **une fois par minute**, puis ferme ses positions **quand les cotations le permettent**. Il reprend son portefeuille après redémarrage grâce à `runtime/v14.sqlite`. Pour un seul passage :

```bash
python3 -m bot --once
```

Les transactions **PAPER** utilisent de vraies cotations Jupiter lorsque l'accès réseau est disponible, mais les exécutions sont simulées avec un coût réseau paramétrable et une décote de slippage supplémentaire. Un **montant simulé de 50 USDC** est configuré ; **50 USDC ne signifie pas 50 €**. Aucune conversion EUR/USD fictive n'est effectuée.

La découverte fonctionne avec deux sources indépendantes : si une source échoue, l'autre peut continuer ; si les deux échouent, aucun nouvel achat n'est initié. Les nouvelles paires sont **toujours requalifiées** sur DexScreener, puis soumises aux contrôles on-chain et aux devis Jupiter. Les APIs doivent répondre, sinon le bot n'invente **aucune** transaction. La première observation d'un token ne déclenche jamais un achat automatique : il faut une deuxième observation séparée d'au moins 120 s. Plusieurs filtres peuvent rejeter toutes les opportunités — c'est normal.

### Tableau de bord

Dans un autre terminal, depuis le dossier racine :

```bash
python3 -m http.server 8765 --directory docs
```

Ouvrir http://localhost:8765/ . La page affiche le capital, le P&L **estimé avec une cotation de liquidation Jupiter** pour chaque position (ou « indisponible » si les devis manquent), les candidats, les rôles, les opérations et les rejets. **Un deuxième champ `dex_mark_equity_usdc` conserve le prix indicatif DexScreener, mais le tableau de bord montre les devis Jupiter nets estimés, y compris pour chaque position. Aucune courbe ni aucun rendement fictifs ne sont préchargés.**

### Surveillance complémentaire des exchanges

```bash
python3 -m bot.monitors --out docs/other-markets.json
```

Aucune clé d'exchange n'est nécessaire : ce module ne passe jamais d'ordre.

## 3. COPIER : suivre de véritables traders

Pour ajouter du copy trading :

1. Choisir des **adresses de portefeuille Solana vérifiées indépendamment**, plutôt que de copier une capture d'écran d'un classement.
2. Ajouter ces adresses à `trader_wallets` dans `config.json`. Ne pas confondre les noms d'utilisateurs de copy.top avec des adresses on-chain.
3. Configurer **localement** la clé Helius : `export HELIUS_API_KEY='...'`. Ne pas la communiquer dans un chat ni la committer.
4. Lancer le programme. Le premier passage fixe un **curseur initial** sans reproduire les positions historiques. Les nouveaux swaps non ambigus sont ensuite examinés.

Le robot copie les montants **selon vos règles de risque**, pas le montant du trader suivi. Un achat ou une vente est rejeté si la source est trop ancienne, la liquidité trop faible, les coûts trop élevés ou le token n'est pas admissible. Les ordres qui ne sont pas des swaps clairement décodés sont ignorés. Une rupture de pagination Helius **arrête les nouveaux achats**.

## 4. Gestion du risque par défaut

| Paramètre | Valeur |
|---|---:|
| Capital initial simulé | 50 USDC |
| Taille maximum d'un achat | 8 % de l'équité |
| Exposition totale maximale | 24 % |
| Positions simultanées | 3 |
| Stop-loss de référence | −10 % |
| Trailing activé après | +15 %, recul de 8 % |
| Prise de profit partielle | Dès +25 % estimés nets, vendre 50 % |
| Objectif de prise de profit | +60 % |
| Durée max de détention | 90 min |
| Perte journalière avant blocage | 5 % |
| Drawdown avant blocage | 10 % |
| Solde minimum d'un achat | 2 USDC |
| Liquidité minimum | 30 000 USD |
| Décote slippage PAPER additionnelle | 0,5 % |
| Coût réseau fictif par achat/vente PAPER | 0,10 USDC |
| Perte maximale estimée d'un aller-retour Jupiter | 8 % |

Les seuils sont **des hypothèses techniques**, pas une stratégie validée sur historiques indépendants. Ils peuvent changer les résultats positivement ou négativement ; les optimizer sur une démonstration TikTok serait de l'overfitting.

### Arrêt d'urgence

Créer un fichier vide `STOP_TRADING` dans le répertoire de travail. Le bot bloque alors **tous** les nouveaux ordres, y compris les sorties : les positions déjà ouvertes doivent être vérifiées et gérées manuellement. Le remettre en marche nécessite un examen du portefeuille et, si nécessaire, la création d'une nouvelle session isolée — pas seulement la suppression du fichier. Les kill switches ne peuvent pas annuler une transaction blockchain déjà diffusée.

## 5. Exécution LIVE (expérimentale, **non validée sur mainnet**)

L'intégration avec Jupiter V2 est implémentée mais **nous n'avons ni wallet réel dans cet environnement, ni accès aux API réseau du conteneur, ni test d'exécution mainnet.** Ne considérer cette passerelle **ni auditée, ni certifiée pour des fonds réels**.

Pour que le module puisse seulement envisager un ordre LIVE, il exige en même temps :

- `mode` = `LIVE` dans un **nouveau** `config.json` avec un `live_mint_allowlist` explicite ;
- un portefeuille Solana **dédié et doté d'un capital limité**, contenant des USDC et une réserve SOL pour le gas ;
- `pip install -r requirements-live.txt` pour le signataire `solders` ;
- `SOLANA_PRIVATE_KEY_BASE58`, `SOLANA_RPC_URL` et idéalement `JUPITER_API_KEY` en variables d'environnement du **serveur local seulement** ;
- `ENABLE_LIVE_TRADING=I_ACCEPT_THE_RISK_OF_LOSS` et `LIVE_TRADING_CONFIRMATION=MY_FUNDS_CAN_BE_LOST` ;
- l'absence du fichier `STOP_TRADING` et de tout ordre incertain dans le journal SQLite.

Le bot limite la dégradation d'un nouveau devis de 3 %, contraint le slippage Jupiter à 200 bps, exige le SOL réservé et vérifie la confirmation RPC d'une transaction exécutée. Les **signatures des transactions** et les demandes d'ordre sont journalisées. Une réponse de réseau ambiguë crée un ordre `UNKNOWN` et **bloque toute nouvelle exécution**, même après redémarrage. Il faut consulter la blockchain et réconcilier manuellement les soldes avant de reprendre ; **ne jamais supprimer la base pour contourner ce blocage**.

**Attention au calcul :** les cotations de vente Jupiter sont indicatives, pas des transactions exécutées. Un prix peut glisser ou la transaction échouer avant confirmation ; les estimations LIVE excluent le SOL de gas.

**Avertissement technique :** l'analyse du contenu de toutes les instructions d'une transaction Jupiter signée, les frais exacts en SOL, les rent exceptions, Token-2022, les webhooks/streaming ultra-rapides, le risque MEV et l'exactitude des soldes après chaque swap nécessitent encore une validation avant un usage en production. Le modèle LIVE enregistre un P&L estimé **hors coût du SOL gas**, ce qui peut surestimer les gains.

**Aucune clé privée, seed phrase ou identifiant d'exchange n'est nécessaire pour le mode PAPER et personne ne doit en envoyer dans le chat.**

## 6. Disponibilité, 12 heures et VPS

Le programme est autonome **tant que son processus est exécuté**. ChatGPT ne le lance pas en arrière-plan depuis la conversation. Un PC qui dort ou un GitHub Action qui se termine interrompt la surveillance. Pour une session réellement continue, utiliser un ordinateur allumé ou un petit VPS (service systemd facultatif dans `scripts/copytrading-v14.service`). Utiliser un stockage **persistant** pour `runtime/v14.sqlite`.

Ne pas lancer deux instances contre la même base : le bot utilise un verrou système. Après les 12 h, les nouvelles entrées s'arrêtent, et le bot **reste actif tant que des positions n'ont pas pu être liquidées**. Les limites de rate Helius/Jupiter et des clés peuvent engendrer un coût API supplémentaire.

## 7. Tests et limites de vérification

```bash
python3 -m unittest discover -s tests -q
python3 -m compileall -q bot
```

Les tests injectent de **fausses réponses d'API** pour couvrir les scénarios : parser, trades bidirectionnels, prix invalides, Helius non fiable, filtres de risque, stops, fin de session, coupure des données, redémarrage, doublons et commandes ambiguës. **Passer des tests logiciels ne signifie pas gagner de l'argent.**

Ces résultats ne sont pas un backtest historique ni un essai de 12 h avec de vrais prix live. Les données historiques individuelles de DexScreener ne sont pas offertes par les endpoints de découverte utilisés ici ; accumuler un historique de cotations en conditions réelles est une prochaine étape nécessaire pour mesurer l'espérance de gain nette, la variance, le drawdown et les frais.

**Contrairement aux publicités :** le portefeuille n'est jamais artificiellement augmenté ; une sortie sans cotation n'est pas enregistrée comme une victoire ; une position sans prix courant rend le total indisponible. Les tops traders suivis ne sont jamais présélectionnés à partir d'une image. Les clips promotionnels montrant +61 %, +1000 % ou « 3 wins, 0 losses » ne démontrent pas ces performances pour notre logiciel.

## Documentation des API utilisées

- [DexScreener API](https://docs.dexscreener.com/api/reference)
- [Helius Enhanced Transactions](https://www.helius.dev/docs/getting-data) (historique en mode maintenance ; disponibilité à vérifier)
- [Jupiter Swap API V2](https://developers.jup.ag/docs/swap/index)
- [Jupiter V2 order & execute](https://developers.jup.ag/docs/swap/order-and-execute)
- [copy.top, fonctionnement public](https://copy.top/help)

**État de livraison :** code et tests créés localement. Aucun déploiement GitHub, ordre mainnet ni rentabilité réelle n'a été vérifié.

## 8. Audit de performance après une session

```bash
python3 -m bot.performance --db runtime/v14.sqlite \
  --out docs/performance.json --trades-csv docs/trades.csv
```

Ce rapport calcule les gains réalisés, le nombre d'achats/ventes, le taux de réussite sur **positions complètement clôturées**, le meilleur/pire trade, le gain moyen après coûts PAPER et le résultat par origine (SCOUT ou COPIER). **Une vente partielle ne compte pas comme une position clôturée.** Des données manquantes ne sont jamais complétées par un profit imaginaire.
