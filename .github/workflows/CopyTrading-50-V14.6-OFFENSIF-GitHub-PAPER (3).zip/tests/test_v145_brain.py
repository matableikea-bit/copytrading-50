"""V14.5: deterministic BRAIN and EXECUTOR tests (no claims of profit)."""
from __future__ import annotations
from dataclasses import replace
import unittest
from pathlib import Path
import tempfile

from test_v14 import Setup, NOW, MINT, market
from bot.brain import assess, size_within_budget
from bot.executor import check_roundtrip
from bot.providers import DataUnavailable
from bot.settings import Config,D
from bot.store import Store
from bot.performance import summarize


class BrainLogic(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.tmp.name)/'a.db')
    def tearDown(self):
        self.store.close();self.tmp.cleanup()

    def test_score_is_not_future_return_and_never_overallocates(self):
        got=assess(market(),self.store,NOW)
        self.assertFalse(got.as_dict()['is_return_prediction'])
        self.assertLessEqual(got.score,100)
        self.assertLessEqual(size_within_budget('4',got,'2'),D(4))

    def test_brain_increases_score_on_positive_observed_windows(self):
        m=market(now=NOW,price='1.10')
        initial=assess(m,self.store,NOW).score
        # Multiple observations at timestamps located in the past only.
        for age,price in ((910,'1.05'),(310,'1.06'),(70,'1.08')):
            self.store.observe(market(now=NOW-age,price=price),80)
        got=assess(m,self.store,NOW)
        self.assertGreaterEqual(got.score,initial)
        self.assertIsNotNone(got.timeframe_returns['1m'])
        self.assertIsNotNone(got.timeframe_returns['5m'])
        self.assertIsNotNone(got.timeframe_returns['15m'])

    def test_stale_history_is_not_mislabeled_as_1m(self):
        self.store.observe(market(now=NOW-5000),75)
        got=assess(market(now=NOW),self.store,NOW)
        self.assertIsNone(got.timeframe_returns['1m'])
        self.assertIsNone(got.timeframe_returns['15m'])

    def test_future_market_or_history_does_not_change_score(self):
        future=market(now=NOW+100,price='2')
        self.store.observe(future,90)
        got=assess(market(now=NOW,price='1'),self.store,NOW)
        self.assertTrue(all(x is None for x in got.timeframe_returns.values()))

    def test_falling_momentum_reduces_score_and_position_size(self):
        weak=replace(market(now=NOW,price='0.70'), liquidity_usd=D('35000'),
                     volume_5m_usd=D('4000'),buys_5m=12,sells_5m=9)
        self.store.observe(replace(weak,observed_at=NOW-90,price_usd=D('1')),70)
        now=assess(weak,self.store,NOW)
        old=assess(weak,self.store,NOW,enabled=False)
        self.assertLess(now.score,old.score)
        self.assertLess(size_within_budget('4',now,'2'),D('4'))

    def test_minimum_does_not_exceed_risk_cap(self):
        got=assess(market(),self.store,NOW)
        self.assertEqual(size_within_budget('1.8',got,'2'),D(0))
        self.assertEqual(size_within_budget('2',got,'2'),D('2'))
        self.assertEqual(size_within_budget('4',got,'2'),D('4'))

    def test_disabled_brain_preserves_risk_budget(self):
        got=assess(market(),self.store,NOW,enabled=False)
        self.assertEqual(got.fraction_of_risk_budget,D('1'))
        self.assertEqual(size_within_budget('4',got,'2'),D('4'))


class ExecutorLogic(unittest.TestCase):
    def test_verified_roundtrip_audit_has_cost(self):
        cfg=Config()
        got=check_roundtrip('4',3000000,{'outAmount':'3910000','feeBps':100},
                            {'outAmount':'3000000','feeBps':120},cfg)
        self.assertTrue(got['quotes_are_not_fills'])
        self.assertGreater(D(got['all_in_roundtrip_cost_fraction']),D(0))

    def test_rejects_fee_and_cost(self):
        cfg=Config()
        with self.assertRaisesRegex(DataUnavailable,'swap_fees'):
            check_roundtrip('4',3000000,{'outAmount':'3900000','feeBps':301},
                            {'feeBps':0},cfg)
        with self.assertRaisesRegex(DataUnavailable,'roundtrip'):
            check_roundtrip('4',3000000,{'outAmount':'1500000','feeBps':0},
                            {'feeBps':0},cfg)

    def test_zero_exit_is_not_a_trade(self):
        with self.assertRaises(DataUnavailable):
            check_roundtrip('4',100,{'outAmount':'0'}, {}, Config())


class BrainIntegration(Setup):
    def test_entry_is_scored_audited_and_reported(self):
        self.buy()
        t=self.bot.state['trades'][0]
        self.assertIn('brain',t)
        self.assertIn('executor_preflight',t)
        self.assertLessEqual(D(t['spent_usdc']),D('4'))
        report=self.bot.tick()
        self.assertTrue(report['brain_enabled'])
        self.assertIn('executor_quote_audit',report)
        perf=summarize(self.bot.state,self.store.stats())
        self.assertIsNotNone(perf['mean_brain_score_at_entry'])
        self.assertIsNotNone(perf['mean_executor_estimated_roundtrip_cost_percent'])

    def test_brain_log_does_not_duplicate_buy_order(self):
        self.buy()
        self.assertEqual(len([x for x in self.bot.state['trades'] if x['side']=='BUY']),1)
        self.assertTrue(any(x['kind']=='BRAIN' for x in self.store.last_events()))
        self.assertEqual(self.bot.state['mode'],'PAPER')


if __name__=='__main__':unittest.main()
