"""Never call a simulated return a forecast; enforce preflight and paper-only presets."""
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
import json, os

from bot.settings import Config, D
from bot.profiles import apply_profile
from bot.gh_session import prepare_config, run_stage
from bot.risk import exit_reason, risk_budget
from bot.store import Store
from test_github_workflow import FakePaperBot

class OffensiveProfile(TestCase):
    def test_paper_only_capital_and_exposure(self):
        for capital in ('50', '100'):
            c=apply_profile(Config(), 'offensif', capital)
            self.assertEqual(c.mode, 'PAPER')
            self.assertEqual(c.starting_usdc, capital)
            self.assertEqual(c.strategy_profile, 'offensif')
            self.assertEqual(D(c.max_trade_fraction), D('.18'))
            self.assertEqual(D(c.take_profit_fraction), D('2'))
            self.assertLessEqual(D(c.max_single_token_fraction),D(c.max_total_exposure_fraction))
            self.assertTrue(c.brain_enabled)
            self.assertLess(D(c.max_total_exposure_fraction),D('1'))
    def test_no_live_no_weird_capital(self):
        with self.assertRaisesRegex(ValueError, 'PAPER only'):
            apply_profile(Config(mode='LIVE'),'offensif','50')
        with self.assertRaisesRegex(ValueError, '50 or 100'):
            apply_profile(Config(),'offensif','5000')
        with self.assertRaisesRegex(ValueError, 'unknown PAPER'):
            apply_profile(Config(),'fantasy','50')
        with self.assertRaisesRegex(ValueError, 'PAPER only'):
            Config(mode='LIVE',strategy_profile='offensif').validate()
    def test_capital_and_profile_transmitted_by_github_environment(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'cfg.json';p.write_text('{"mode":"PAPER"}')
            with patch.dict(os.environ,{'PAPER_PROFILE':'offensif','PAPER_CAPITAL':'100'}):
                c=prepare_config(str(p))
            self.assertEqual(c.starting_usdc,'100')
            self.assertEqual(c.strategy_profile,'offensif')
    def test_risk_budget_is_hard_capped_even_in_offensive_mode(self):
        c=apply_profile(Config(),'offensif','50')
        state={'halted':False, 'positions':{}, 'cash_usdc':'50',
               'trades':[], 'peak_equity_usdc':'50','day_start_equity_usdc':'50'}
        budget,why=risk_budget(state,c,{},{})
        self.assertEqual(why,'pass')
        self.assertEqual(budget,D('9'))
        self.assertLess(budget,D('50'))
    def test_large_take_profit_targets_and_partial_bank(self):
        c=apply_profile(Config(),'offensif','50')
        p={'cost_usdc':'9','peak_exit_value_usdc':'9','opened_at':100,
           'entry_price_usd':'1','peak_price_usd':'1'}
        self.assertIsNone(exit_reason(p,None,101,c,D('10')))
        self.assertEqual(exit_reason(p,None,101,c,D('27')),'take_profit')
        self.assertEqual(exit_reason({**p,'peak_exit_value_usdc':'18'},None,101,c,D('13')),'trailing_stop')
    def test_cross_stage_configuration_change_fails_closed(self):
        with TemporaryDirectory() as d:
            db=str(Path(d)/'session.sqlite')
            report=str(Path(d)/'report.json')
            c=apply_profile(Config(),'offensif','50');c.session_hours=10
            run_stage(c,session='10h',stage=1,db_path=db,report_path=report,
                      run_id='test',bot_factory=FakePaperBot,max_ticks=1)
            different=apply_profile(Config(),'standard','50');different.session_hours=10
            with self.assertRaisesRegex(ValueError, 'configuration changed'):
                run_stage(different,session='10h',stage=2,db_path=db,
                          report_path=report,run_id='test',bot_factory=FakePaperBot,max_ticks=1)
