# V14.6 OFFENSIF — simulation uniquement

Ce profil est **expérimental**. Il cherche des gains plus importants en acceptant des risques de perte plus élevés. **Aucun bénéfice n’est prévu ni garanti.** Il ne doit pas être confondu avec un résultat de backtest.

| Paramètre | Standard | OFFENSIF |
|---|---:|---:|
| Capital PAPER | 50 USDC | 50 ou 100 USDC |
| Exposition maximale d’une position | 8 % | 18 % |
| Exposition maximale simultanée | 24 % | 50 % |
| Limite de perte quotidienne | 5 % | 12 % |
| Perte maximale depuis le sommet | 10 % | 20 % |
| Stop indicatif par position | 10 % | 15 % |
| Première prise de profit | +25 %, 50 % vendu | +60 %, 25 % vendu |
| Clôture sur objectif net | +60 % | +200 % |
| Trailing après gain net | +15 % | +45 % |
| Réduction depuis le pic pour sortie | 8 % | 22 % |
| Temps max en position | 90 min | 180 min |
| Achats max par session | 18 | 12 |
| Liquidité minimale | 30 000 $ | 50 000 $ |

**Le stop ne garantit pas un prix d'exécution : le token peut devenir invendable.** Les scores ne prédisent pas les rendements. Les frais et quotes Jupiter restent calculés. Le bot peut perdre ses 50/100 USDC, même avec ces règles. Les contraintes de protection contre les ordres dupliqués, l'absence de liquidité, les APIs absentes, les wallets flippers et les coûts excessifs ne sont pas supprimées.

Workflow GitHub : `.github/workflows/copytrading-offensif-v146.yml`; choisissez `session=2min` puis `12h`, `capital=50` ou `100`, `profil=offensif` ou `standard`. **Ne remplacez pas le workflow V14.4 pendant sa simulation.** Secrets GitHub existants `HELIUS_API_KEY`, `JUPITER_API_KEY` et variable `SIM_WALLETS_JSON`.

Le résultat à comparer est le P&L net, le drawdown, les frais, la fréquence de trades, et l'activité de chaque agent, et non le score ou le nombre de tokens.
