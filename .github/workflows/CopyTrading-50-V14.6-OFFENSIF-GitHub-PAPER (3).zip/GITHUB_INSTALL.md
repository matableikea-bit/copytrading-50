# Installer V14.6 OFFENSIF sur GitHub (PAPER)

1. Ne modifiez pas le workflow V14.4 de la session 12h déjà en cours. Le nouveau fichier est distinct.
2. Dans votre dépôt `matableikea-bit/copytrading-50`, créez `.github/workflows/copytrading-offensif-v146.yml`.
3. Copiez **tout** le contenu de `Copier-Dans-GitHub-V14.6-OFFENSIF-AUTONOME.yml` (fichier inclus dans le ZIP), puis validez le commit.
4. GitHub → Actions → **CopyTrading 50 V14.6 OFFENSIF** → Run workflow.
5. Choisissez `session: 2min`, `capital: 50` ou `100`, `profil: offensif`. Vérifiez le test vert et les logs API, puis lancez une autre session `12h` seulement après la fin de l'ancienne session pour comparer.
6. Dans les artifacts, téléchargez `checkpoint-stage-3-final` → `docs/resultats.html`, `docs/status.json`, `docs/performance.json` et `docs/trades.csv`.

Le workflow conserve la variable GitHub `SIM_WALLETS_JSON` et les secrets `HELIUS_API_KEY`, `JUPITER_API_KEY`. Aucune clé privée, aucun ordre réel. Il utilise les mêmes protections anti-doublon et la reprise SQLite entre trois jobs. Les rapports décrivent une simulation ; des gains futurs ne peuvent pas être prévus.

**À noter :** un simple ajout de `config.json` dans le dépôt n'affecte pas un workflow autonome qui embarque déjà son propre programme ; il faut bien installer le nouveau fichier YAML complet.
