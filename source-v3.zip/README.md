# CopyTrading 50 · Actions US réelles / 50 € virtuels (V3)

**Statut : code fourni et testé localement avec des cotations simulées dans les tests, MAIS le service n'est PAS encore en cours sur GitHub.** Aucune simulation d'actions réelles ne démarre sans clés Alpaca et marché ouvert.

## Ce que fait cette version

- Observe **quatre vraies actions américaines** (AAPL, MSFT, NVDA et GOOGL) en utilisant **les cotations Alpaca/IEX**, obtenues avec une clé API gratuite de compte paper. Le prix bid/ask et son timestamp sont contrôlés. IEX n'est qu'une place boursière, pas l'ensemble du marché américain.
- Réserve cinq enveloppes de **10 € fictifs** : Pelosi → AAPL, Telegram → MSFT, Trader professionnel / Top Traders → NVDA, fonds → GOOGL, Polymarket → 10 € en cash inactif. Les associations sont uniquement des **portefeuilles d'observation**, pas des achats réels attribués à ces personnes ou institutions.
- Actualise les valorisations **toutes les 5 minutes** pendant une session choisie entre **5 et 330 minutes** (multiple de 5). Ne négocie pas réellement.
- Utilise le **taux de référence EUR/USD quotidien de la BCE** pour afficher des montants en euros (ce taux **n'est ni temps réel ni exécutable**).
- Applique un calcul de **risque adaptatif borné** sur la variation des capitaux ; il n'exécute aucun trade de sa propre initiative et n'apprend pas automatiquement des stratégies gagnantes.
- Publie **l'état courant et l'historique** dans `docs/data.json` puis un **dashboard web public** (`docs/index.html`) peut les afficher. Le navigateur vérifie le rapport source toutes les 30 secondes ; la donnée change environ toutes les 5 minutes, sous réserve du délai GitHub.
- Les signaux de vrais traders **ne sont pas encore connectés**. Pas de promesse de gains.

## Mise en ligne gratuite sur GitHub (à faire une fois)

1. Ouvrir un [compte Alpaca paper](https://alpaca.markets/) et récupérer les identifiants API market-data IEX. Ne pas partager de secrets en discussion, ni les coller dans un dépôt public.
2. Dans le dépôt GitHub `matableikea-bit/copytrading-50`, onglet **Settings → Secrets and variables → Actions**, créer deux secrets : `ALPACA_API_KEY` et `ALPACA_API_SECRET` (clés Alpaca *paper* seulement).
3. Envoyer le fichier `source-v3.zip` **à la racine du dépôt** (sans le décompresser).
4. Créer le fichier **`.github/workflows/live-stocks-on-demand.yml`**, en copiant celui du pack (GitHub → Add file → Create new file, nom avec le chemin complet). Les workflow files sont des fichiers texte, pas des archives.
5. Dans **Actions**, sélectionner **Actions réelles — simulation 50 € à la demande**, puis **Run workflow** ; saisir `duration_minutes` (ex. 60, 120 ou 300).
6. Activer **GitHub Pages** : Settings → Pages → Deploy from a branch → `main` → `/docs` (le workflow crée le dossier au premier lancement). Selon GitHub, le site peut mettre quelques minutes à publier.
7. Ouvrir le site à `https://matableikea-bit.github.io/copytrading-50/` quand Pages l'a réellement activé. Le site est public : on n'y publie aucun secret.

**À noter** : le connecteur GitHub présent dans cette conversation n'offre pas encore de déclenchement générique de workflow. Je ne peux donc pas promettre de lancer l'exécution directement à partir d'un message dans le chat : il faut appuyer sur **Run workflow** dans GitHub. Le travail est exécuté sur les machines GitHub, sans que le PC ou l'iPhone restent allumés. Un job GitHub Actions est limité à 6 h : le pack limite volontairement à 5 h 30.

## Limites à connaître

- **Ce n'est pas encore du copy trading de vrais investisseurs.** Pour cela il faudra connecter des sources de transactions horodatées et vérifiables, puis passer chacune dans un validateur. Les symboles ci-dessus sont des actions réelles, mais les associations de portefeuilles sont seulement une démonstration de suivi de marché.
- **Marché fermé = pas de nouvelles cotations live.** Le programme n'invente pas de cours. Les jours fériés de NYSE sont également bloqués par contrôle de fraîcheur du flux.
- Le test peut être interrompu ; le rapport final indique les points manquants. L'actualisation GitHub Pages n'est pas garantie à la seconde près, et le cache de `raw.githubusercontent.com` peut retarder l'affichage.
- La valeur initiale peut être **légèrement inférieure à 50 €** après une acquisition virtuelle à hauteur de 50 % au ask et valorisation au bid (spread). Les frais sont à 0 par défaut dans cette version, sans prétendre simuler les frais réels d'un courtier.
- Les fractions virtuelles peuvent ne pas être négociables chez tous les courtiers. Le simulateur ne constitue pas une validation de faisabilité du trading réel pour 10 €.

## Tests

```bash
python -m pytest -q tests
```

Tests de prix Alpaca avec données *mockées*, règles de budget, dates, marché fermé, risque adaptatif et simulation 15 min accélérée. Aucune requête Alpaca réelle n'est nécessaire pour ces tests.
