"""50 EUR paper observation of REAL US equities, with conservative adaptive risk.

This does not claim to copy traders until real externally-verified signals are connected.
All brokerage operations are local paper-accounting; API calls use READ-ONLY market-data.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import statistics
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from io import StringIO
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

TOTAL = Decimal('50.00')
CENTS = Decimal('0.01')
INTERVAL_SECONDS = 300
MAX_MINUTES = 330
STRATEGIES = [
    ('pelosi', 'Nancy Pelosi', 'AAPL'),
    ('telegram', 'Trader Telegram', 'MSFT'),
    ('top_traders', 'Trader pro / Top Traders', 'NVDA'),
    ('institutional', 'Fonds d’investissement', 'GOOGL'),
    ('polymarket', 'Polymarket (actions : inactif)', None),
]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso(t: datetime) -> str:
    return t.astimezone(timezone.utc).isoformat(timespec='seconds')


def money(x: Decimal) -> str:
    return str(x.quantize(CENTS, rounding=ROUND_HALF_UP))


def as_decimal(x) -> Decimal:
    d = Decimal(str(x))
    if not d.is_finite() or d <= 0:
        raise ValueError('Prix ou taux non valide')
    return d


def parse_time(value: str) -> datetime:
    # Alpaca timestamps sometimes have nanosecond precision beyond python's microsecond limit.
    if not isinstance(value, str) or not value:
        raise ValueError('Horodatage absent')
    raw = value.replace('Z', '+00:00')
    try:
        d = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValueError('Horodatage invalide') from exc
    if d.tzinfo is None:
        raise ValueError('Horodatage sans fuseau')
    return d.astimezone(timezone.utc)


def market_open(now: datetime) -> bool:
    """Regular NY trading window; holidays additionally caught by quote freshness."""
    ny = now.astimezone(ZoneInfo('America/New_York'))
    mins = ny.hour * 60 + ny.minute
    return ny.weekday() < 5 and 9 * 60 + 30 <= mins < 16 * 60


def validated_minutes(value: int) -> int:
    if not 5 <= value <= MAX_MINUTES or value % 5:
        raise ValueError('Durée: multiple de 5 entre 5 et 330 minutes')
    return value


def http_get(url: str, headers: dict | None = None, timeout: int = 20) -> bytes:
    req = Request(url, headers={
        'User-Agent': 'CopyTrading50-StockPaper/3.0',
        'Accept': 'application/json',
        **(headers or {}),
    })
    with urlopen(req, timeout=timeout) as response:
        return response.read(1_000_000)


def alpaca_quotes(symbols: list[str], now: datetime, api_key: str, api_secret: str, *, getter=http_get) -> dict:
    if not api_key or not api_secret:
        raise RuntimeError('ALPACA_API_KEY et ALPACA_API_SECRET requis (compte paper gratuit).')
    if not market_open(now):
        raise RuntimeError('Marché actions US fermé : aucun cours live disponible.')
    url = 'https://data.alpaca.markets/v2/stocks/quotes/latest?' + urlencode({'symbols': ','.join(symbols), 'feed': 'iex'})
    auth = {'APCA-API-KEY-ID': api_key, 'APCA-API-SECRET-KEY': api_secret}
    payload = json.loads(getter(url, auth).decode('utf-8'))
    result = {}
    for symbol in symbols:
        quote = payload.get('quotes', {}).get(symbol)
        if not quote:
            raise RuntimeError(f'Pas de cotation réelle IEX pour {symbol}')
        bid, ask = as_decimal(quote['bp']), as_decimal(quote['ap'])
        when = parse_time(quote['t'])
        age = (now - when).total_seconds()
        if bid > ask or age < -60 or age > 600:
            raise RuntimeError(f'{symbol}: bid/ask incohérent ou cotation IEX trop ancienne ({round(age)}s)')
        result[symbol] = {'bid': bid, 'ask': ask, 'time': iso(when), 'age_seconds': round(age), 'source': 'Alpaca/IEX'}
    return result


def ecb_usd_per_eur(*, getter=http_get) -> tuple[Decimal, str]:
    """EUR/USD daily reference (NOT live FX or executable FX price)."""
    url = 'https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A?lastNObservations=1&format=csvdata'
    csvdata = getter(url, {'Accept': 'text/csv'}).decode('utf-8-sig')
    rows = list(csv.DictReader(StringIO(csvdata)))
    rows = [x for x in rows if x.get('OBS_VALUE') and x.get('TIME_PERIOD')]
    if not rows:
        raise RuntimeError('Taux BCE EUR/USD indisponible')
    latest = max(rows, key=lambda x: x['TIME_PERIOD'])
    rate = as_decimal(latest['OBS_VALUE'])
    return rate, latest['TIME_PERIOD']


@dataclass
class Portfolio:
    key: str
    name: str
    ticker: str | None
    cash: Decimal = Decimal('10')
    quantity: Decimal = Decimal('0')
    entry_ask: Decimal | None = None
    last_valid_bid: Decimal | None = None
    last_valid_utc: str | None = None
    kind: str = 'OBSERVATION'

    def initial_observation_buy(self, quote: dict, usd_per_eur: Decimal) -> None:
        if self.ticker is None or self.quantity:
            return
        # 10 EUR becomes USD using the *documented daily reference* ECB rate.
        allocation_eur = self.cash * Decimal('0.50')  # 50% exposure cap for each observation wallet
        self.quantity = allocation_eur * usd_per_eur / quote['ask']
        self.entry_ask = quote['ask']
        self.last_valid_bid = quote['bid']
        self.last_valid_utc = quote['time']
        self.cash -= allocation_eur

    def mark(self, quote: dict | None, usd_per_eur: Decimal) -> Decimal:
        if quote is not None:
            self.last_valid_bid = quote['bid']
            self.last_valid_utc = quote['time']
        if not self.ticker:
            return self.cash
        if self.last_valid_bid is None:
            raise RuntimeError(f'{self.ticker}: pas de prix observé')
        return self.cash + self.quantity * self.last_valid_bid / usd_per_eur


def adaptive_risk(equities: list[Decimal]) -> dict:
    """Transparent, bounded adaptation. NEVER creates a trade on its own."""
    if len(equities) < 4:
        return {'max_new_position_fraction': '0.50', 'volatility': None,
                'reason': 'Historique trop court : limite par défaut', 'auto_trade': False}
    ratios = [float(b / a - 1) for a, b in zip(equities[:-1], equities[1:]) if a > 0]
    if len(ratios) < 3:
        return {'max_new_position_fraction': '0.50', 'volatility': None,
                'reason': 'Données insuffisantes', 'auto_trade': False}
    vol = statistics.pstdev(ratios[-12:])
    peak = max(equities)
    drawdown = float(equities[-1] / peak - 1) if peak else 0.0
    limit = Decimal('0.50')
    reason = 'Volatilité stable'
    if vol >= 0.01 or drawdown <= -0.03:
        limit, reason = Decimal('0.20'), 'Volatilité ou baisse importante : réduction du risque'
    elif vol >= 0.004 or drawdown <= -0.015:
        limit, reason = Decimal('0.35'), 'Volatilité accrue : prudence'
    return {'max_new_position_fraction': str(limit), 'volatility': round(vol, 6),
            'drawdown': round(drawdown, 6), 'reason': reason, 'auto_trade': False}


def snapshot(elapsed: int, portfolios: list[Portfolio], quotes: dict, fx: Decimal, fx_date: str,
             history: list[Decimal], *, status: str = 'EN_COURS') -> dict:
    points, equities = [], []
    for p in portfolios:
        eq = p.mark(quotes.get(p.ticker) if p.ticker else None, fx)
        equities.append(eq)
        points.append({'id': p.key, 'name': p.name, 'symbol': p.ticker, 'cash_eur': money(p.cash),
                       'value_eur': money(eq), 'pnl_eur': money(eq - Decimal('10')),
                       'quantity': str(p.quantity), 'status': ('OBSERVATION_RÉELLE' if p.ticker else 'INACTIF'),
                       'quote_time': p.last_valid_utc, 'data_mode': 'REAL_IEX' if p.ticker else 'CASH',
                       'is_copy_trading': False})
    total = sum(equities, Decimal('0'))
    policy = adaptive_risk(history + [total])
    return {'elapsed_minutes': elapsed, 'observed_at_utc': iso(utc_now()), 'status': status,
            'total_eur': money(total), 'pnl_eur': money(total - TOTAL), 'portfolios': points,
            'risk_policy': policy, 'fx_usd_per_eur': str(fx), 'fx_as_of': fx_date,
            'market_data_source': 'Alpaca/IEX live US equities (exchange only)',
            'quote_is_live': bool(quotes), 'true_copytrading_connected': False}


def write_json_atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def run(minutes: int, outdir: Path, *, api_key: str, api_secret: str, clock=time.monotonic,
        sleeper=time.sleep, quotes_getter=alpaca_quotes, fx_getter=ecb_usd_per_eur,
        on_publish=None) -> dict:
    validated_minutes(minutes)
    ports = [Portfolio(key, name, symbol) for key, name, symbol in STRATEGIES]
    symbols = [p.ticker for p in ports if p.ticker]
    report = {'status': 'INITIALISATION', 'mode': 'PAPER_REAL_STOCK_WATCHLIST',
              'stock_quotes': 'REAL_IEX', 'copy_trading': 'NOT_CONNECTED',
              'adaptation': 'RISK_ONLY_NO_AUTONOMOUS_TRADING', 'started_at_utc': iso(utc_now()),
              'duration_minutes': minutes, 'interval_minutes': 5,
              'capital_initial_eur': '50.00', 'samples': [], 'incidents': [],
              'disclosure': 'Quatre vraies actions observées, un portefeuille en cash; pas de copie de traders.',
              'fidelity': 'IEX temps réel pendant la séance; taux BCE quotidien non exécutable',
              'portfolios_initial': [{ 'id': p.key, 'label': p.name, 'budget_eur': '10.00'} for p in ports]}
    dest = outdir / 'data.json'

    def persist():
        write_json_atomic(dest, report)
        if on_publish:
            on_publish(report)

    if not api_key or not api_secret:
        report['status'] = 'CONFIGURATION_REQUISE'
        report['incidents'].append({'minute': 0, 'reason': 'Clés Alpaca IEX absentes ; aucun prix inventé'})
        persist()
        return report
    try:
        current = utc_now()
        fx, fx_date = fx_getter()
        quote_map = quotes_getter(symbols, current, api_key, api_secret)
        for p in ports:
            if p.ticker:
                p.initial_observation_buy(quote_map[p.ticker], fx)
        history = []
        snap = snapshot(0, ports, quote_map, fx, fx_date, history)
        history.append(Decimal(snap['total_eur']))
        report['samples'].append(snap)
        report['status'] = 'EN_COURS'
        persist()
        print(f'[0 min] Live IEX: total {snap["total_eur"]} EUR (four equities, no copy traders)', flush=True)
    except Exception as exc:
        report['status'] = 'MARCHE_FERME_OU_SOURCE_INDISPONIBLE'
        report['incidents'].append({'minute': 0, 'reason': str(exc)})
        persist()
        return report

    start = clock()
    try:
        for m in range(5, minutes + 1, 5):
            remaining = start + m * 60 - clock()
            if remaining > 0:
                sleeper(remaining)
            try:
                now = utc_now()
                quote_map = quotes_getter(symbols, now, api_key, api_secret)
                point = snapshot(m, ports, quote_map, fx, fx_date, history)
                history.append(Decimal(point['total_eur']))
                report['samples'].append(point)
                print(f'[{m} min] {point["total_eur"]} EUR, P&L {point["pnl_eur"]} EUR', flush=True)
            except Exception as exc:
                report['incidents'].append({'minute': m, 'reason': str(exc)})
                print(f'[{m} min] Cours NON disponibles : {exc}', file=sys.stderr, flush=True)
            persist()
    except KeyboardInterrupt:
        report['status'] = 'INTERROMPU'
    else:
        report['status'] = 'TERMINE' if len(report['samples']) == (minutes // 5 + 1) else 'INCOMPLET'
    report['finished_at_utc'] = iso(utc_now())
    persist()
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description='Observateur actions US en temps réel, 50 EUR virtuels')
    parser.add_argument('--minutes', type=int, default=60)
    parser.add_argument('--output-dir', type=Path, default=Path('docs'))
    args = parser.parse_args()
    try:
        report = run(args.minutes, args.output_dir, api_key=os.getenv('ALPACA_API_KEY', ''),
                     api_secret=os.getenv('ALPACA_API_SECRET', ''))
    except ValueError as exc:
        print(f'Erreur : {exc}', file=sys.stderr)
        return 2
    print('Session :', report['status'])
    return 0 if report['status'] == 'TERMINE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
