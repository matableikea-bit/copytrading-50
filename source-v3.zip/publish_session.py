"""Publishes sanitized live paper-data to a public GitHub repo at 5 minute checkpoints.
No credentials, no PII, no brokerage order submission.
"""
import argparse
import subprocess
from pathlib import Path
from stock_session import run
import os


def publish(_):
    subprocess.run(['git', 'add', 'docs/data.json'], check=True)
    status = subprocess.run(['git', 'diff', '--cached', '--quiet'], check=False)
    if status.returncode == 0:
        return
    subprocess.run(['git', 'commit', '-m', 'Update paper-trading stock snapshot'], check=True, capture_output=True)
    subprocess.run(['git', 'push'], check=True, capture_output=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--minutes', type=int, default=60)
    args = parser.parse_args()
    # If a publish fails, fail safely; show errors in workflow log, never invent results.
    result = run(args.minutes, Path('docs'), api_key=os.getenv('ALPACA_API_KEY', ''),
                 api_secret=os.getenv('ALPACA_API_SECRET', ''), on_publish=publish)
    if result['status'] != 'TERMINE':
        raise SystemExit(f"Simulation terminée sans résultat complet : {result['status']}")


if __name__ == '__main__':
    main()
